package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Students;
import vo.Teacheres;
import vo.TestQusertion;
import vo.ThePapers;

public class test {
	public static void main(String[] args) {
		add();
		//selectu();
	}
//	private static void selectu(){
////		Session session=HibernateSessionFactory.getSession();
////		Transaction transaction=session.beginTransaction();
////		Students students =(Students)session.get(Students.class,3);
//		System.out.println(students.getUserLogn().getUserPwd());
//		transaction.commit();
//	};
	private static void addsv(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		TestQusertion tempTestq=(TestQusertion) session.get(TestQusertion.class,1);
		ThePapers thePapers = (ThePapers) session.get(ThePapers.class, 1);
		thePapers.getThePaperQusertion().add(tempTestq);
		session.save(thePapers);
		transaction.commit();
	}
	private static void add(){
		Teacheres t = new Teacheres();
		t.setZhanghao(123);
		t.setMima("123");
//		Students s = new Students();
//		s.setStuedetId(456);
//		//s.setUserLogn(u);
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		session.save(t);
		transaction.commit();
		
	}
}
