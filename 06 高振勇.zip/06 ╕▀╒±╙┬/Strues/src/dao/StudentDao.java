package dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Students;

public class StudentDao {
	//查询学生
	public List<Students> selectStudent(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		List<Students> studentList = new ArrayList<Students>();
		studentList=session.createQuery("from Students").list();
		
		transaction.commit();
		return studentList;
	}
}
