package vo;

/**
 * 成绩表
 * @author gao
 *
 */
public class Achievement {
	private int id;
	private int achievement;//成绩
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAchievement() {
		return achievement;
	}
	public void setAchievement(int achievement) {
		this.achievement = achievement;
	}
	 
}
