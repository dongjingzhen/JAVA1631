package vo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 题库试题表
 * @author gao
 *
 */ 
public class TestQusertion {
	private int id;
	private String keMu;
	private String content;//试题的题目
	private int diJiQi;//第几期
	private String testType;//试题的类型单选OR多选
	private String optionA;//选项A
	private String optionB;//选项B
	private String optionC;//选项C
	private String optionD;//选项D
	private String ansWer;//答案
	private String difficuLty;//难度
	private String testTypeJOrB;//机试OR笔试
	private String chaPter;//章节
	private Questiones questiones;
	private Set<ThePapers> ThePapersList = new HashSet<ThePapers>();
	public String getKeMu() {
		return keMu;
	}
	public void setKeMu(String keMu) {
		this.keMu = keMu;
	}
	public int getDiJiQi() {
		return diJiQi;
	}
	public void setDiJiQi(int diJiQi) {
		this.diJiQi = diJiQi;
	}
	public String getTestTypeJOrB() {
		return testTypeJOrB;
	}
	public void setTestTypeJOrB(String testTypeJOrB) {
		this.testTypeJOrB = testTypeJOrB;
	}
	public String getTestType() {
		return testType;
	}
	public void setTestType(String testType) {
		this.testType = testType;
	}

	
	public Set<ThePapers> getThePapersList() {
		return ThePapersList;
	}
	public void setThePapersList(Set<ThePapers> thePapersList) {
		ThePapersList = thePapersList;
	}
	public Questiones getQuestiones() {
		return questiones;
	}
	public void setQuestiones(Questiones questiones) {
		this.questiones = questiones;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getAnsWer() {
		return ansWer;
	}
	public void setAnsWer(String ansWer) {
		this.ansWer = ansWer;
	}
	public String getDifficuLty() {
		return difficuLty;
	}
	public void setDifficuLty(String difficuLty) {
		this.difficuLty = difficuLty;
	}
	public String getChaPter() {
		return chaPter;
	}
	public void setChaPter(String chaPter) {
		this.chaPter = chaPter;
	}
	
}
