package vo;

import java.util.Date;
/**
 * 学生表
 * @author gao
 *
 */ 
public class Students {
	private int id;
	private int stuedetId;//学生ID
	private String mima;
	private String stuName;//学生姓名
	private	Date ruXue;//入学时间
	private	Date shengri;//生日
	private String shenFen;//身份证
	private String sheng;//省份
	private String zhuanYeJC;//专业简称
	private String number;//联系电话
	private String jiaNumber;//家长联系电话
	private FangXiang fangXiang;
	private Teacheres teacheres;
	private Classes classes;
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public Teacheres getTeacheres() {
		return teacheres;
	}
	public void setTeacheres(Teacheres teacheres) {
		this.teacheres = teacheres;
	}
	public FangXiang getFangXiang() {
		return fangXiang;
	}
	public void setFangXiang(FangXiang fangXiang) {
		this.fangXiang = fangXiang;
	}
	public String getMima() {
		return mima;
	}
	public void setMima(String mima) {
		this.mima = mima;
	}
	public int getStuedetId() {
		return stuedetId;
	}
	public void setStuedetId(int stuedetId) {
		this.stuedetId = stuedetId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public Date getRuXue() {
		return ruXue;
	}
	public void setRuXue(Date ruXue) {
		this.ruXue = ruXue;
	}
	public Date getShengri() {
		return shengri;
	}
	public void setShengri(Date shengri) {
		this.shengri = shengri;
	}
	public String getShenFen() {
		return shenFen;
	}
	public void setShenFen(String shenFen) {
		this.shenFen = shenFen;
	}
	public String getSheng() {
		return sheng;
	}
	public void setSheng(String sheng) {
		this.sheng = sheng;
	}
	public String getZhuanYeJC() {
		return zhuanYeJC;
	}
	public void setZhuanYeJC(String zhuanYeJC) {
		this.zhuanYeJC = zhuanYeJC;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getJiaNumber() {
		return jiaNumber;
	}
	public void setJiaNumber(String jiaNumber) {
		this.jiaNumber = jiaNumber;
	}
	

}
