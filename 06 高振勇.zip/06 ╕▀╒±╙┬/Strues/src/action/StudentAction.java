package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;


import vo.Students;

import com.opensymphony.xwork2.Action;

import dao.StudentDao;

public class StudentAction implements Action{

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String seleRem(){
		StudentDao dao = new StudentDao();
		List<Students> studentList=dao.selectStudent();
		ServletActionContext.getRequest().setAttribute("studentList", studentList);
		return "seleRem";
		
	}
}
