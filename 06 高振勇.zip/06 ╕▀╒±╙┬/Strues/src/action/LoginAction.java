package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Students;
import vo.Teacheres;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class LoginAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//查询账号密码
	public String selectM(){
		String Success=null;
		//得到账号密码以及角色
		int userName=new Integer(ServletActionContext.getRequest().getParameter("userName"));
		String userPwd=ServletActionContext.getRequest().getParameter("userPwd");
		int quanxian= new Integer(ServletActionContext.getRequest().getParameter("userRole"));
		//判断角色
		if (quanxian==1) {
			//学生
		//准备开始判断账号及密码
			Session session=HibernateSessionFactory.getSession();
			Transaction transaction=session.beginTransaction();
			List<Students> studentList = new ArrayList<Students>();
			studentList=session.createQuery("from Students").list();
			for (Students students : studentList) {
				//有此账号存在
				System.out.println(students.getStuedetId());
				System.out.println(userName);
				if (students.getStuedetId()==userName) {
					//密码也想通
					if (students.getMima().equals(userPwd)) {
						ServletActionContext.getRequest().getSession().setAttribute("userName", students.getStuName());
						ServletActionContext.getRequest().getSession().setAttribute("userSF",1);
						return "selectM";
					}else {
						return "select";
					}
				}else {
					return "select";
				}
			
			}
			
			transaction.commit();
		}//老师
		else if (quanxian==2) {
			//准备开始判断账号及密码
			Session session=HibernateSessionFactory.getSession();
			Transaction transaction=session.beginTransaction();
			List<Teacheres> teacheres = new ArrayList<Teacheres>();
			teacheres=session.createQuery("from Teacheres").list();
		
			for (Teacheres students : teacheres) {
				//有此账号存在
				if (students.getZhanghao()==userName) {
					//密码也想通
					if (students.getMima().equals(userPwd)) {
						ServletActionContext.getRequest().getSession().setAttribute("userName", students.getTeacheName());
						ServletActionContext.getRequest().getSession().setAttribute("userSF",2);
						return "selectM";
					}else {
						return "select";
					}
				}else {
					return "select";
				}
			
			}
			
			transaction.commit();
		}
		else if(quanxian==3){
			System.out.println("管理员");
			ServletActionContext.getRequest().getSession().setAttribute("userSF",3);
			return "selectM";
		}
		return "select";
	}
}
