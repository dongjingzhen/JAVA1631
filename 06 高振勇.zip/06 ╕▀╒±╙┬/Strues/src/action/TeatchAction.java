package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Teacheres;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class TeatchAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String selectTeach(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		List<Teacheres> teacheresList = new ArrayList<Teacheres>();
		teacheresList=session.createQuery("from Teacheres").list();
		ServletActionContext.getRequest().setAttribute("teacheresList", teacheresList);
		transaction.commit();
		return "selectTeach";
	}

}
