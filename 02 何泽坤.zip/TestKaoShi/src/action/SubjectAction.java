package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Paper;
import vo.Question;

import com.opensymphony.xwork2.Action;

import dao.Dao;
import dao.HibernateSessionFactory;

public class SubjectAction implements Action{
@Override public String execute() throws Exception {return null;}
	private List<Object[]> slist;
	private List<Question> qList;
	private String kemu;
	private String jieduan;
	private Question q;
	private List<Paper> paperList;
	private int paperId;
	private Paper paper;
	private List<Classes> classeslist;
	private List<Classes> clist;
	private String[] className;
	List<Question> qlist;
	
	
	
	
	
	public List<Question> getQlist() {
		return qlist;
	}
	public void setQlist(List<Question> qlist) {
		this.qlist = qlist;
	}
	public String[] getClassName() {
		return className;
	}
	public void setClassName(String[] className) {
		this.className = className;
	}
	public List<Classes> getClist() {
		return clist;
	}
	public void setClist(List<Classes> clist) {
		this.clist = clist;
	}
	public List<Classes> getClasseslist() {return classeslist;}
	public void setClasseslist(List<Classes> classeslist) {this.classeslist = classeslist;}
	public Paper getPaper() {return paper;}
	public void setPaper(Paper paper) {this.paper = paper;}
	public int getPaperId() {return paperId;}
	public void setPaperId(int paperId) {this.paperId = paperId;}
	public List<Paper> getPaperList() {return paperList;}
	public void setPaperList(List<Paper> paperList) {this.paperList = paperList;}
	public Question getQ() {return q;}
	public void setQ(Question q) {this.q = q;}
	public String getKemu() {return kemu;}
	public void setKemu(String kemu) {this.kemu = kemu;}
	public String getJieduan() {return jieduan;}
	public void setJieduan(String jieduan) {this.jieduan = jieduan;}
	public List<Object[]> getSlist() {return slist;}
	public void setSlist(List<Object[]> slist) {this.slist = slist;}
	public List<Question> getqList() {return qList;}
	public void setqList(List<Question> qList) {this.qList = qList;}
	
	
	/*
	 * ��ѯ���
	 * ��Ŀ ��      �׶Σ�
	 * ���ԣ�0
	 * ���ԣ�0
	 */
	public String selectTiKu(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String hql = "select count(q.q_testType) as num,p.p_kemu,p.p_jieduan from Question q left join q.paperList p " +
//		"where q_testType="+testType+" and p.p_kemu="+keMu+" and p.p_jieduan="+jieDuan+
		"group by p_kemu,p_jieduan";
		slist =  session.createQuery(hql).list();
		ServletActionContext.getRequest().setAttribute("sList", "sList");
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "selectTi";
	}
	
	
	/*
	 * ��ѯ����
	 */
	public String selectQuestion(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		qList = session.createCriteria(Question.class)
													.setFetchMode("paperList",FetchMode.JOIN)
													.createAlias("paperList", "p")
													.add(Restrictions.eq("p.p_kemu",kemu))
													.add(Restrictions.eq("p.p_jieduan", jieduan))
													.list();
		ServletActionContext.getRequest().getSession().setAttribute("kemu",kemu);
		ServletActionContext.getRequest().getSession().setAttribute("jieduan",jieduan);
		ServletActionContext.getRequest().getSession().setAttribute("qList", qList);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "selectquestion";
	}
	
	
	
	
	/*
	 *	�������� 
	 */
	public String questionAdd(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Paper.class)
															.add(Restrictions.eq("p_kemu", kemu))
															.add(Restrictions.eq("p_jieduan", jieduan));
		ProjectionList projectionList = Projections.projectionList().add(Projections.property("p_id"));
		List<Object> list =(List<Object>) criteria.setProjection(projectionList).list();
		int i = (Integer)list.get(0);
		Paper p = (Paper)session.get(Paper.class, i);
		session.save(q);
		p.getQuestionList().add(q);
		session.saveOrUpdate(p);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "add";
	}
	
	
	
	
	/*
	 * ��ѯ�Ծ�
	 */
	public String selectPaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paperList = session.createCriteria(Paper.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "pap";
	}
	
	
	
	/*
	 *	�鿴������Ϣ
	 */
	public String selectTest(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		//�жϿ���״̬
		paper = (Paper)session.get(Paper.class, paperId);
		//���԰༶
		classeslist = session.createCriteria(Classes.class)
													.setFetchMode("paperList", FetchMode.JOIN)
													.createAlias("paperList", "p")
													.add(Restrictions.eq("p.p_title",kemu))
													.add(Restrictions.eq("p.p_jieduan",jieduan))
													.list();
		clist = session.createCriteria(Classes.class).list();
		ServletActionContext.getRequest().getSession().setAttribute("paperId",paperId);
		ServletActionContext.getRequest().getSession().setAttribute("paper",paper);
		ServletActionContext.getRequest().getSession().setAttribute("classeslist",classeslist);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "selTest";
	}
	
	
	
	
	/*
	 * ���ӿ��԰༶ 
	 */
	public String addClasses(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Paper pa = (Paper)session.get(Paper.class, paperId);
		for (int i = 0; i < className.length; i++) {
			System.out.println(className[i].toString()); 
			Criteria criteria = session.createCriteria(Classes.class).add(Restrictions.eq("c_className", className[i].toString()));
			ProjectionList projectionList = Projections.projectionList().add(Projections.property("c_id"));
			List list =criteria.setProjection(projectionList).list();
			int a = 0;
			for (Object object : list) {
				String s = object.toString();
				a = Integer.parseInt(s);
				System.out.println(a);
			}
			
			Classes c = (Classes)session.get(Classes.class, a);
			pa.getClassesList().add(c);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "addclass";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	 * ��ʼ����
	 */
	public String beginTests(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Paper p = (Paper)session.get(Paper.class, paperId);
		System.out.println(paper.getBeginTime()+paper.getEndTime()+paper.getP_testType());
		p.setBeginTime(paper.getBeginTime());
		p.setEndTime(paper.getEndTime());
		p.setP_testType(paper.getP_testType());
		session.update(p);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "begintest";
	}
	
	
	/*
	 * �����Ծ�
	 */
	public String addPaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Paper pap = new Paper();
		pap.setP_testType("δ����");
		pap.setP_fangxiang(paper.getP_fangxiang());
		pap.setP_jieduan(paper.getP_jieduan());
		pap.setP_kemu(paper.getP_kemu());
		pap.setP_title(paper.getP_title());
		session.save(pap);
		Question que = new Question();
		que.setQ_question("aaaaaaaaaaaaaaaaa");
		que.setQ_nandu("��");
		que.setAnsA("a2");
		que.setAnsB("a3");
		que.setAnsC("a4");
		que.setAnsD("a1");
		que.setQ_type("��ѡ");
		que.setAnswer("D");
		que.setQ_testType("����");
		session.save(que);
		pap.getQuestionList().add(que);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "addpaper";
	}
	
	
	public String selectTy(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		qlist = session.createCriteria(Question.class)
											.setFetchMode("paperList", FetchMode.JOIN)
											.createAlias("paperList", "p")
											.add(Restrictions.eq("p.p_id",paperId))
											.list();
		for (Question q : qlist) {
			System.out.println(q.getQ_question());
			System.out.println(q.getAnsA());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "selectty";
	}
	
	
	
	
}
