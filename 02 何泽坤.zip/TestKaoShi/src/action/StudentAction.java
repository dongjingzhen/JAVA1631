package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.mapping.Fetchable;

import vo.Classes;
import vo.Paper;
import vo.Question;
import vo.Student;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class StudentAction implements Action{
@Override public String execute() throws Exception {return null;}
	private int stuId;
	private Student student;
	private String className;
	private String pwd;
	private String err;
	private String upPwd;
	private String up2Pwd;
	private List<Paper> paperslist;
	private String title;
	private List<Question> tlist;
	
	
	
	
	
	public List<Question> getTlist() {
		return tlist;
	}
	public void setTlist(List<Question> tlist) {
		this.tlist = tlist;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<Paper> getPaperslist() {
		return paperslist;
	}
	public void setPaperslist(List<Paper> paperslist) {
		this.paperslist = paperslist;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getErr() {
		return err;
	}
	public void setErr(String err) {
		this.err = err;
	}
	public String getUpPwd() {
		return upPwd;
	}
	public void setUpPwd(String upPwd) {
		this.upPwd = upPwd;
	}
	public String getUp2Pwd() {
		return up2Pwd;
	}
	public void setUp2Pwd(String up2Pwd) {
		this.up2Pwd = up2Pwd;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public int getStuId() {return stuId;}
	public void setStuId(int stuId) {this.stuId = stuId;}
	public Student getStudent() {return student;}
	public void setStudent(Student student) {this.student = student;}



	public String selectStu(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();		
		student = (Student) session.get(Student.class,stuId);
		className = student.getS_classesId().getC_className();
		ServletActionContext.getRequest().getSession().setAttribute("className", className);
		transaction.commit();
		HibernateSessionFactory.closeSession();		
		return "selectstu";
	} 	
	
	public String updateStu(){
		String  result = "";
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();		
		student = (Student) session.get(Student.class,stuId);
		if (pwd.equals(student.getS_pwd())) {
			if (upPwd!=null && upPwd.equals(up2Pwd) && up2Pwd!=null) {
				student.setS_pwd(upPwd);
				session.update(student);
				result = "ok";
			}
		}else {
			err ="�����������������";
			result = "err";
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();		
		
		return result;
	}										
	
	
	
	
	public String beginTest(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Student s = (Student)session.get(Student.class, stuId);
		String classNames = s.getS_classesId().getC_className();
		System.out.println(classNames);
		paperslist = session.createCriteria(Paper.class).createAlias("classesList", "c").add(Restrictions.eq("c.c_className", classNames)).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();		
		return "begintest";
	}
	
	
	public String test(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		tlist = session.createCriteria(Question.class)
											.setFetchMode("paperList",FetchMode.JOIN)
											.createAlias("paperList", "p")
											.add(Restrictions.eq("p.p_title",title))
											.list();
		for (Question question : tlist) {
			System.out.println(question.getQ_question());
			System.out.println(question.getAnsA());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();	
		return "test";
	}
	
	
	
	
	
		
}
