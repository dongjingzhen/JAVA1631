package dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.sun.org.apache.bcel.internal.generic.Select;

import vo.Admin;
import vo.Classes;
import vo.Paper;
import vo.Question;
import vo.Student;
import vo.Teacher;

/**
 * @author 98707
 */
public class testDao {
	public static void main(String[] args) {
		add();
		init();
//		test();
//		select();
//		sel();
//		selec();
//		testClasses();
//		testAddClasses();
	}
	
	private static void testAddClasses() {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		
		
		Criteria criteria = session.createCriteria(Classes.class).add(Restrictions.eq("c_className", "java1631"));
		ProjectionList projectionList = Projections.projectionList().add(Projections.property("c_id"));
		List list =criteria.setProjection(projectionList).list();
		
		for (Object object : list) {
			String s = object.toString();
			int a = Integer.parseInt(s);
			System.out.println(a);
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}

	private static void testClasses(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Classes> clist = session.createCriteria(Classes.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();		
	}
	
	
	
	
	private static void selec() {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Paper> paperslist = session.createCriteria(Paper.class).createAlias("classesList", "c").add(Restrictions.eq("c.c_className", "java1631")).list();
		for (Paper paper : paperslist) {
			System.out.println(paper.getP_title()+" "+paper.getP_testType()+" "+paper.getBeginTime()+" "+paper.getEndTime());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();		
		
	}





















	private static void sel(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Paper.class);
		ProjectionList projectionList = Projections.projectionList().add(Projections.property("p_id"))
																	.add(Projections.property("p_kemu"))
																	.add(Projections.property("p_title"));		
		List<Object[]> list =(List<Object[]>) criteria.setProjection(projectionList).list();
		
		for (Object[] s : list) {
			System.out.println(s[0]+" "+s[1]+" "+s[2]);
		}
		
		
//		for (Students stu : list) {
//			System.out.println(stu);
//		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		
	}
	
	
	
	
	private static void select() {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Classes> clist = session.createCriteria(Classes.class)
																.setFetchMode("paperList", FetchMode.JOIN)
																.createAlias("paperList", "p")
																.add(Restrictions.eq("p.p_kemu","sturuts"))
																.add(Restrictions.eq("p.p_title","sturts2����"))
																.list();
		for (Classes classes : clist) {
			System.out.println(classes.getC_className());
		}
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}





	public static void test(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	
	
	public static void test1(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		List<Paper> list=session.createCriteria(Paper.class)
														.setFetchMode("questionList", FetchMode.JOIN)
														.createAlias("questionList", "s")
														.list();
		
//		String hql = "select count(q.q_testType) bum,p_kemu,p_jieduan"+
//		"from Question q"+
//		"left join  t_paper_question t"+
//		"on q.q_id=t.q_id"+
//		"left join Paper p"+
//		"on p.p_id = t.p_id"+
//		"where q_testType="+testType+" and p.p_kemu="+keMu+" and p.p_jieduan="+jieDuan+
//		"group by p_kemu,p_jieduan";
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	
	
	
	public static void add(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		//���ӹ���Ա
		Admin admin = new Admin();
		admin.setA_acc("admin");
		admin.setA_pwd("123456");
		session.save(admin);
		
		
		//���Ӱ༶����
		Classes classes1 = new Classes();
		classes1.setC_className("java1632");
		classes1.setC_classNo("java1632");
		classes1.setC_fangxiang("java����ʦ");
		session.save(classes1);
		
		Classes classes2= new Classes();
		classes2.setC_className("java1631");
		classes2.setC_classNo("java1631");
		classes2.setC_fangxiang("java����ʦ");
		session.save(classes2);
		
		
		//����ѧ�� ʮ��������������
		Student student1 = new Student();
		student1.setS_stuNo("10001");
		student1.setS_pwd("123456");
		student1.setS_name("����");
		student1.setSex("��");
		student1.setS_tell("111111111111");
		student1.setS_classesId(classes1);
		session.save(student1);
		
		
		
		Student student2 = new Student();
		student2.setS_stuNo("10002");
		student2.setS_pwd("123456");
		student2.setS_name("����");
		student2.setSex("��");
		student2.setS_tell("222222222222");
		student2.setS_classesId(classes1);
		session.save(student2);
		
		
		
		Student student3 = new Student();
		student3.setS_stuNo("10003");
		student3.setS_pwd("123456");
		student3.setS_name("����");
		student3.setSex("��");
		student3.setS_tell("333333333333");
		student3.setS_classesId(classes1);
		session.save(student3);
		
		Student student4 = new Student();
		student4.setS_stuNo("10004");
		student4.setS_pwd("123456");
		student4.setS_name("����");
		student4.setSex("��");
		student4.setS_tell("444444444444");
		student4.setS_classesId(classes1);
		session.save(student4);
		
		
		
		Student student5 = new Student();
		student5.setS_stuNo("10005");
		student5.setS_pwd("123456");
		student5.setS_name("����");
		student5.setSex("��");
		student5.setS_tell("555555555555");
		student5.setS_classesId(classes1);
		session.save(student5);
		
		Student student6 = new Student();
		student6.setS_stuNo("20001");
		student6.setS_pwd("123456");
		student6.setS_name("�Ϻ�");
		student6.setSex("��");
		student6.setS_tell("211111111111");
		student6.setS_classesId(classes2);
		session.save(student6);
		
		Student student7 = new Student();
		student7.setS_stuNo("20002");
		student7.setS_pwd("123456");
		student7.setS_name("Сǿ");
		student7.setSex("��");
		student7.setS_tell("122222222222");
		student7.setS_classesId(classes2);
		session.save(student7);
		
		Student student8 = new Student();
		student8.setS_stuNo("20003");
		student8.setS_pwd("123456");
		student8.setS_name("�غ�");
		student8.setSex("��");
		student8.setS_tell("2333333333333");
		student8.setS_classesId(classes2);
		session.save(student8);
		
		
		Student student9 = new Student();
		student9.setS_stuNo("20004");
		student9.setS_pwd("123456");
		student9.setS_name("С��");
		student9.setSex("��");
		student9.setS_tell("2444444444444");
		student9.setS_classesId(classes2);
		session.save(student9);
		
		
		
		Student student10 = new Student();
		student10.setS_stuNo("20005");
		student10.setS_pwd("123456");
		student10.setS_name("ɧ��");
		student10.setSex("��");
		student10.setS_tell("255555555555");
		student10.setS_classesId(classes2);
		session.save(student10);
		
		
		
		//������ʦ
		Teacher teacher1 = new Teacher();
		teacher1.setT_accNo("0001");
		teacher1.setT_pwd("123456");
		teacher1.setT_name("����ʦ");
		teacher1.setSex("Ů");
		teacher1.setT_tell("9999999999999");
		teacher1.setT_job("������");
		session.save(teacher1);
		
		
		Teacher teacher2 = new Teacher();
		teacher2.setT_accNo("0002");
		teacher2.setT_pwd("123456");
		teacher2.setT_name("����ʦ");
		teacher2.setSex("��");
		teacher2.setT_tell("888888888888");
		teacher2.setT_job("��ʦ");
		session.save(teacher2);
		
		
		//�������� ������  ��������  �����׶� 
		Paper paper1 = new Paper();
		paper1.setP_testType("δ����");
		paper1.setP_fangxiang("java����ʦ");
		paper1.setP_jieduan("G1");
		paper1.setP_kemu("sturuts");
		paper1.setP_title("sturts2����");
		
		Paper paper2 = new Paper();
		paper2.setP_testType("δ����");
		paper2.setP_fangxiang("java����ʦ");
		paper2.setP_jieduan("G2");
		paper2.setP_kemu("hibernate");
		paper2.setP_title("hibernate����");
		
		Paper paper3 = new Paper();
		paper3.setP_testType("δ����");
		paper3.setP_fangxiang("java����ʦ");
		paper3.setP_jieduan("G3");
		paper3.setP_kemu("sturuts");
		paper3.setP_title("sturts2����");
		
		Paper paper4 = new Paper();
		paper4.setP_testType("δ����");
		paper4.setP_fangxiang("����Ӫ��");
		paper4.setP_jieduan("G1");
		paper4.setP_kemu("ps���");
		paper4.setP_title("ps��Ʋ���");
		
		
		
		Paper paper5 = new Paper();
		paper5.setP_testType("δ����");
		paper5.setP_fangxiang("����Ӫ��");
		paper5.setP_jieduan("G2");
		paper5.setP_kemu("ps���");
		paper5.setP_title("ps��Ʋ���");
		
		
		Paper paper6 = new Paper();
		paper6.setP_testType("δ����");
		paper6.setP_fangxiang("����Ӫ��");
		paper6.setP_jieduan("G3");
		paper6.setP_kemu("UI");
		paper6.setP_title("UI����");
		
		
		session.save(paper1);
		session.save(paper2);
		session.save(paper3);
		session.save(paper4);
		session.save(paper5);
		session.save(paper6);
		
		
		//������Ŀ 20��
		
		
		Question question1 = new Question();
		question1.setQ_question("1+1��ʲô����²�����2");
		question1.setQ_nandu("��");
		question1.setAnsA("������ȷʱ");
		question1.setAnsB("�������ʱ");
		question1.setAnsC("���ۺ�ʱ");
		question1.setAnsD("��֪��");
		question1.setQ_type("��ѡ");
		question1.setAnswer("A");
		question1.setQ_testType("����");
		
		Question question2 = new Question();
		question2.setQ_question("������Լ�˧��");
		question2.setQ_nandu("��");
		question2.setAnsA("��˧");
		question2.setAnsB("˧");
		question2.setAnsC("������");
		question2.setAnsD("̫����");
		question2.setQ_type("��ѡ");
		question2.setAnswer("A,C,D");
		question2.setQ_testType("����");
		
		
		Question question3 = new Question();
		question3.setQ_question("xxxxxxxxxxx");
		question3.setQ_nandu("��");
		question3.setAnsA("x2");
		question3.setAnsB("x3");
		question3.setAnsC("x4");
		question3.setAnsD("x1");
		question3.setQ_type("��ѡ");
		question3.setAnswer("C");
		question3.setQ_testType("����");
		
		Question question4 = new Question();
		question4.setQ_question("aaaaaaaaaaaaaaaaa");
		question4.setQ_nandu("��");
		question4.setAnsA("a2");
		question4.setAnsB("a3");
		question4.setAnsC("a4");
		question4.setAnsD("a1");
		question4.setQ_type("��ѡ");
		question4.setAnswer("D");
		question4.setQ_testType("����");
		
		Question question5 = new Question();
		question5.setQ_question("1+1��ʲô����²�����2");
		question5.setQ_nandu("��");
		question5.setAnsA("������ȷʱ");
		question5.setAnsB("�������ʱ");
		question5.setAnsC("���ۺ�ʱ");
		question5.setAnsD("��֪��");
		question5.setQ_type("��ѡ");
		question5.setAnswer("A");
		question5.setQ_testType("����");
		
		Question question6 = new Question();
		question6.setQ_question("������Լ�˧��");
		question6.setQ_nandu("��");
		question6.setAnsA("��˧");
		question6.setAnsB("˧");
		question6.setAnsC("������");
		question6.setAnsD("̫����");
		question6.setQ_type("��ѡ");
		question6.setAnswer("A,C,D");
		question6.setQ_testType("����");
		
		
		Question question7 = new Question();
		question7.setQ_question("xxxxxxxxxxx");
		question7.setQ_nandu("��");
		question7.setAnsA("x2");
		question7.setAnsB("x3");
		question7.setAnsC("x4");
		question7.setAnsD("x1");
		question7.setQ_type("��ѡ");
		question7.setAnswer("C");
		question7.setQ_testType("����");
		
		Question question8 = new Question();
		question8.setQ_question("aaaaaaaaaaaaaaaaa");
		question8.setQ_nandu("��");
		question8.setAnsA("a2");
		question8.setAnsB("a3");
		question8.setAnsC("a4");
		question8.setAnsD("a1");
		question8.setQ_type("��ѡ");
		question8.setAnswer("D");
		question8.setQ_testType("����");
		
		Question question9 = new Question();
		question9.setQ_question("1+1��ʲô����²�����2");
		question9.setQ_nandu("��");
		question9.setAnsA("������ȷʱ");
		question9.setAnsB("�������ʱ");
		question9.setAnsC("���ۺ�ʱ");
		question9.setAnsD("��֪��");
		question9.setQ_type("��ѡ");
		question9.setAnswer("A");
		question9.setQ_testType("����");
		
		Question question10 = new Question();
		question10.setQ_question("������Լ�˧��");
		question10.setQ_nandu("��");
		question10.setAnsA("��˧");
		question10.setAnsB("˧");
		question10.setAnsC("������");
		question10.setAnsD("̫����");
		question10.setQ_type("��ѡ");
		question10.setAnswer("A,C,D");
		question10.setQ_testType("����");
		
		
		Question question11 = new Question();
		question11.setQ_question("xxxxxxxxxxx");
		question11.setQ_nandu("��");
		question11.setAnsA("x2");
		question11.setAnsB("x3");
		question11.setAnsC("x4");
		question11.setAnsD("x1");
		question11.setQ_type("��ѡ");
		question11.setAnswer("C");
		question11.setQ_testType("����");
		
		Question question12 = new Question();
		question12.setQ_question("aaaaaaaaaaaaaaaaa");
		question12.setQ_nandu("��");
		question12.setAnsA("a2");
		question12.setAnsB("a3");
		question12.setAnsC("a4");
		question12.setAnsD("a1");
		question12.setQ_type("��ѡ");
		question12.setAnswer("D");
		question12.setQ_testType("����");
		
		
		
		
		Question question13 = new Question();
		question13.setQ_question("1+1��ʲô����²�����2");
		question13.setQ_nandu("��");
		question13.setAnsA("������ȷʱ");
		question13.setAnsB("�������ʱ");
		question13.setAnsC("���ۺ�ʱ");
		question13.setAnsD("��֪��");
		question13.setQ_type("��ѡ");
		question13.setAnswer("A");
		question13.setQ_testType("����");
		
		Question question14 = new Question();
		question14.setQ_question("������Լ�˧��");
		question14.setQ_nandu("��");
		question14.setAnsA("��˧");
		question14.setAnsB("˧");
		question14.setAnsC("������");
		question14.setAnsD("̫����");
		question14.setQ_type("��ѡ");
		question14.setAnswer("A,C,D");
		question14.setQ_testType("����");
		
		
		Question question15 = new Question();
		question15.setQ_question("xxxxxxxxxxx");
		question15.setQ_nandu("��");
		question15.setAnsA("x2");
		question15.setAnsB("x3");
		question15.setAnsC("x4");
		question15.setAnsD("x1");
		question15.setQ_type("��ѡ");
		question15.setAnswer("C");
		question15.setQ_testType("����");
		
		Question question16 = new Question();
		question16.setQ_question("aaaaaaaaaaaaaaaaa");
		question16.setQ_nandu("��");
		question16.setAnsA("a2");
		question16.setAnsB("a3");
		question16.setAnsC("a4");
		question16.setAnsD("a1");
		question16.setQ_type("��ѡ");
		question16.setAnswer("D");
		question16.setQ_testType("����");
		
		
		
		
		
		Question question17 = new Question();
		question17.setQ_question("1+1��ʲô����²�����2");
		question17.setQ_nandu("��");
		question17.setAnsA("������ȷʱ");
		question17.setAnsB("�������ʱ");
		question17.setAnsC("���ۺ�ʱ");
		question17.setAnsD("��֪��");
		question17.setQ_type("��ѡ");
		question17.setAnswer("A");
		question17.setQ_testType("����");
		
		
		Question question18 = new Question();
		question18.setQ_question("������Լ�˧��");
		question18.setQ_nandu("��");
		question18.setAnsA("��˧");
		question18.setAnsB("˧");
		question18.setAnsC("������");
		question18.setAnsD("̫����");
		question18.setQ_type("��ѡ");
		question18.setAnswer("A,C,D");
		question18.setQ_testType("����");
		
		
		Question question19 = new Question();
		question19.setQ_question("xxxxxxxxxxx");
		question19.setQ_nandu("��");
		question19.setAnsA("x2");
		question19.setAnsB("x3");
		question19.setAnsC("x4");
		question19.setAnsD("x1");
		question19.setQ_type("��ѡ");
		question19.setAnswer("C");
		question19.setQ_testType("����");
		
		Question question20 = new Question();
		question20.setQ_question("aaaaaaaaaaaaaaaaa");
		question20.setQ_nandu("��");
		question20.setAnsA("a2");
		question20.setAnsB("a3");
		question20.setAnsC("a4");
		question20.setAnsD("a1");
		question20.setQ_type("��ѡ");
		question20.setAnswer("D");
		question20.setQ_testType("����");
		
		
		session.save(question1);
		session.save(question2);
		session.save(question3);
		session.save(question4);
		session.save(question5);
		session.save(question6);
		session.save(question7);
		session.save(question8);
		session.save(question9);
		session.save(question10);
		session.save(question11);
		session.save(question12);
		session.save(question13);
		session.save(question14);
		session.save(question15);
		session.save(question16);
		session.save(question17);
		session.save(question18);
		session.save(question19);
		session.save(question20);
		
		
		
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public static void init(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Paper paper1 = (Paper)session.get(Paper.class, 1);
		Question stu1 = (Question) session.get(Question.class, 1);
		Question stu2 = (Question) session.get(Question.class, 2);
		Question stu3 = (Question) session.get(Question.class, 3);
		Question stu4 = (Question) session.get(Question.class, 4);
		Question stu5 = (Question) session.get(Question.class, 5);
		Question stu6 = (Question) session.get(Question.class, 6);
		Classes classes1 = (Classes)session.get(Classes.class, 1);
		paper1.getQuestionList().add(stu1);
		paper1.getQuestionList().add(stu2);
		paper1.getQuestionList().add(stu3);
		paper1.getQuestionList().add(stu4);
		paper1.getQuestionList().add(stu5);
		paper1.getQuestionList().add(stu6);
		paper1.getClassesList().add(classes1);
		session.saveOrUpdate(paper1);
		
		Paper paper2 = (Paper)session.get(Paper.class, 2);
		Question stu7 = (Question) session.get(Question.class, 7);
		Question stu8 = (Question) session.get(Question.class, 8);
		Question stu9 = (Question) session.get(Question.class, 9);
		Question stu10= (Question) session.get(Question.class,10);
		Question stu11= (Question) session.get(Question.class,11);
		Question stu12= (Question) session.get(Question.class,12);
		Question stu13= (Question) session.get(Question.class,13);
		Question stu14 = (Question) session.get(Question.class,14);
		Question stu15 = (Question) session.get(Question.class,15);
		Question stu16 = (Question) session.get(Question.class,16);
		Classes classes2 = (Classes)session.get(Classes.class, 2);
		paper2.getQuestionList().add(stu7);
		paper2.getQuestionList().add(stu8);
		paper2.getQuestionList().add(stu9);
		paper2.getQuestionList().add(stu10);
		paper2.getQuestionList().add(stu11);
		paper2.getQuestionList().add(stu12);
		paper2.getQuestionList().add(stu13);
		paper2.getQuestionList().add(stu14);
		paper2.getQuestionList().add(stu15);
		paper2.getQuestionList().add(stu16);
		paper2.getClassesList().add(classes2);
		session.saveOrUpdate(paper2);
		
		
		Paper paper3 = (Paper)session.get(Paper.class, 3);
		Question stu17 = (Question) session.get(Question.class,17);
		Question stu18 = (Question) session.get(Question.class,18);
		Question stu19 = (Question) session.get(Question.class,19);
		Question stu20= (Question) session.get(Question.class,20);
		paper3.getQuestionList().add(stu17);
		paper3.getQuestionList().add(stu18);
		paper3.getQuestionList().add(stu19);
		paper3.getQuestionList().add(stu20);
		session.saveOrUpdate(paper3);
		
		Paper paper4 = (Paper)session.get(Paper.class, 4);
		Question stu04 = (Question) session.get(Question.class,17);
		paper4.getQuestionList().add(stu04);
		
		Paper paper5 = (Paper)session.get(Paper.class, 5);
		Question stu05 = (Question) session.get(Question.class,11);
		paper5.getQuestionList().add(stu05);
		
		Paper paper6 = (Paper)session.get(Paper.class, 6);
		Question stu06 = (Question) session.get(Question.class,12);
		paper6.getQuestionList().add(stu06);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	
	
	
	
	
}
