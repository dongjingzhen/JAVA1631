package vo;

import java.util.ArrayList;
import java.util.List;

public class Classes {
	private int c_id;
	private String c_classNo;
	private String c_className;
	private String c_fangxiang;
	private String c_bteacher;
	private String c_jteacher;
	private List<Student> studentsList=new ArrayList<Student>();
	private List<Paper> paperList = new ArrayList<Paper>();
	
	
	@Override
	public String toString() {
		return "Classes [c_bteacher=" + c_bteacher + ", c_className="
				+ c_className + ", c_classNo=" + c_classNo + ", c_fangxiang="
				+ c_fangxiang + ", c_id=" + c_id + ", c_jteacher=" + c_jteacher
				+ ", paperList=" + paperList + ", studentsList=" + studentsList
				+ "]";
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	public List<Student> getStudentsList() {
		return studentsList;
	}
	public void setStudentsList(List<Student> studentsList) {
		this.studentsList = studentsList;
	}
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int cId) {
		c_id = cId;
	}
	public String getC_classNo() {
		return c_classNo;
	}
	public void setC_classNo(String cClassNo) {
		c_classNo = cClassNo;
	}
	public String getC_className() {
		return c_className;
	}
	public void setC_className(String cClassName) {
		c_className = cClassName;
	}
	public String getC_fangxiang() {
		return c_fangxiang;
	}
	public void setC_fangxiang(String cFangxiang) {
		c_fangxiang = cFangxiang;
	}
	public String getC_bteacher() {
		return c_bteacher;
	}
	public void setC_bteacher(String cBteacher) {
		c_bteacher = cBteacher;
	}
	public String getC_jteacher() {
		return c_jteacher;
	}
	public void setC_jteacher(String cJteacher) {
		c_jteacher = cJteacher;
	}
	
	
}
