package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Question;
import vo.Subject;
import vo.Teacher;

public class QuestionDao {
	public List<Subject> allsubject(){
		//���� �������෵�ؿ�Ŀ
		List<Subject> subject = new ArrayList<Subject>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		subject = session.createCriteria(Subject.class).list();
		
		String sql = "select kind,count(kind),subjectId from question  group by kind,subjectId";
		List<Object[]> strings = session.createSQLQuery(sql).list();
		for (Object[] strings2 : strings) {
			for (Subject s : subject) {
				String a = (String) strings2[2];
				
				if (a.equals(s.getSubjectId())) {
					s.getObject().add(strings2);
				}
			}
		}
		for (Subject s : subject) {
			Object[] o = {"����",0,s.getSubjectId()};
			Object[] oo = {"����",0,s.getSubjectId()};
			if (s.getObject().size()==1) {
				Object[] ooo = s.getObject().get(0);
				String a = (String) ooo[2];	
				if (a.equals("����")) {
					
					s.getObject().add(oo);
				}else {
					s.getObject().add(o);
				}
			}else if (s.getObject().size()==0) {
				
				s.getObject().add(o);
				s.getObject().add(oo);
			}
		}
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		
		return subject;
	}
	
	public List<Question> SubjectQuestion(Question question){
		//ĳ��Ŀ�µ�����
		List<Question> questions = new ArrayList<Question>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		questions = session.createCriteria(Question.class)
			.add(Restrictions.eq("kind", question.getKind()))
			.add(Restrictions.eq("subjectId", question.getSubjectId()))
			.list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return questions;
	}
	
}
