package dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Num;
import vo.Paper;
import vo.Question;
import vo.Subject;

public class PaperDao {
	
	public List<Paper> allPaper(){
		//��ѯ�����Ծ�
		List<Paper> papers = new ArrayList<Paper>();
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		papers = session.createCriteria(Paper.class).list();
		for (Paper paper : papers) {
		Set<Classes> s =paper.getClasses();
		for (Classes classes : s) {
			System.out.println(classes.getClassName());
		}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return papers;
		
	}
	public List<Subject> allSubject(Subject  s){
		//��ѯ���� ��Ŀ
		List<Subject> subject = new ArrayList<Subject>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria =session.createCriteria(Subject.class);
		System.out.println(s);
		if(s!=null){
			if(s.getDirection()!=null && !s.getDirection().equals("0")){
				criteria.add(Restrictions.eq("direction", s.getDirection()));
			}
			if(s.getStage()!=null && !s.getStage().equals("0")){
				criteria.add(Restrictions.eq("stage", s.getStage()));
			}
		}
		
		
		subject=criteria.list();
		System.out.println(subject.size());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return subject;
	}
	
	public void random(Num num,Paper paper){
		//������ �������׳̶�
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String sql = "select qid from("+
					"select top "+num.getDanj()+" qid from question where difficulty='��' and type='��ѡ' and subjectId = 'GTB' order by newId() union "+
				" select top "+num.getDany()+" qid from question where difficulty='�е�' and type='��ѡ' and subjectId = 'GTB' order by newId() union "+
				"select top "+num.getDank()+" qid from question where difficulty='����' and type='��ѡ' and subjectId = 'GTB' order by newId() union "+
				"select top "+num.getDanj()+" qid from question where difficulty='��' and type='��ѡ' and subjectId = 'GTB' order by newId() union "+
				"select top "+num.getDany()+" qid from question where difficulty='�е�' and type='��ѡ' and subjectId = 'GTB'  order by newId() union "+
				" select top "+num.getDank()+" qid from question where difficulty='����' and type='��ѡ' and subjectId = 'GTB' order by newId() "+
				")  as a ";
		System.out.println(paper.getQnumber());
		System.out.println(sql);
		List<Object[]> questions=session.createSQLQuery(sql).list();
			
			for (Object[] paper2 : questions) {
				Question question = (Question) session.get(Question.class,(Serializable)paper2[0]);
				paper.getQuestions().add(question);
			}
		paper.setQnumber(paper.getQuestions().size());
		session.save(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public Paper searchPaper(Paper paper){
		 //��ȡid  ��ѯ
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		paper = (Paper) session.get(Paper.class, paper.getPid());
		Set<Question> q = paper.getQuestions();
		for (Question question : q) {
			System.out.println(question.getType());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paper;
	}
	
	public List<Question> anotherQuestion(Paper paper){
		//�滻����
		List<Question> questions = new ArrayList<Question>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper) session.get(Paper.class, paper.getPid());
		Criteria criteria=session.createCriteria(Question.class);
		for (Question question : paper.getQuestions()) {
			criteria.add(Restrictions.ne("qid", question.getQid()));
		}
			criteria.add(Restrictions.eq("kind", paper.getKind()));
			criteria.add(Restrictions.eq("subjectId", paper.getSubjectName()));
			questions = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return questions;
	}
	
	public void tiQuestion(Paper paper,Question q,Question tq){
		//�滻����
		List<Question> questions = new ArrayList<Question>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper) session.get(Paper.class, paper.getPid());
		q = (Question) session.get(Question.class, q.getQid());
		tq = (Question) session.get(Question.class, tq.getQid());
		paper.getQuestions().remove(q);
		session.flush();
		paper.getQuestions().add(tq);
		session.saveOrUpdate(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public List<Classes> allClasses(){
		//��ѯ���а༶
		List<Classes> classes = new ArrayList<Classes>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		classes = session.createCriteria(Classes.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return classes;
	}
	public void ready(Paper paper,int[] className,Date time){
		//��ʼ���� ���Ӱ༶
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		paper = (Paper) session.get(Paper.class, paper.getPid());
		for (int cid : className) {
			if(cid!=0){
				Classes classe = (Classes) session.get(Classes.class, cid);
				paper.getClasses().add(classe);
			}
		}
		paper.setTestTime(time);
		paper.setState("0");
		session.saveOrUpdate(paper);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
}
