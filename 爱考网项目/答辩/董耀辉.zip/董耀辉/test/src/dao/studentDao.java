package dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Paper;
import vo.Score;
import vo.Student;
import vo.Teacher;
import vo.Users;

public class studentDao {
	public List<Student> allStudent(){
		//��������ѧ��
		List<Student> students = new ArrayList<Student>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		students = session.createCriteria(Student.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return students;
	}
	public List<Paper> studentPaper(){
		//ÿ��ѧ���������Ծ�
		List<Paper> papers = new ArrayList<Paper>();
		Users user = (Users)ServletActionContext.getRequest().getSession().getAttribute("loginUser");
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		List<Student> students= session.createCriteria(Student.class)
				.add(Restrictions.eq("stuNo", user.getUserNo())).list();
		Student stu = students.get(0);
		List<Score> scores= session.createCriteria(Score.class).add(Restrictions.eq("student", stu)).list();
		Criteria criteria=session.createCriteria(Paper.class)
		.setFetchMode("classes", FetchMode.JOIN)
								.createAlias("classes", "c")
								.add(Restrictions.eq("c.id", stu.getClasses().getId()));
		for (Score score : scores) {
			criteria.add(Restrictions.ne("pid", score.getPaper().getPid()));
		}
		criteria.add(Restrictions.eq("state", "0"));
		papers = criteria.list();
		for (Paper p : papers) {
			System.out.println(p.getTitle());
			Set<Classes> c = p.getClasses();
			for (Classes classes : c) {
				System.out.println(classes.getClassName());
			}
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return papers;
	}
	public List<Score> ScorePaper(Student stu){
		List<Score> score = new ArrayList<Score>();
		Users user = (Users)ServletActionContext.getRequest().getSession().getAttribute("loginUser");
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		stu =(Student) session.get(Student.class, stu.getId());
		score= session.createCriteria(Score.class).add(Restrictions.eq("student", stu)).list();
		for (Score score2 : score) {
			System.out.println(score2.getPaper().getTitle());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return score;
	}
	public Student getstu(){
		//ѧ����Ż�ȡѧ��
		Users user = (Users)ServletActionContext.getRequest().getSession().getAttribute("loginUser");
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		List<Student> students= session.createCriteria(Student.class)
				.add(Restrictions.eq("stuNo", user.getUserNo())).list();
		Student stu = students.get(0);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return stu;
	}
	
	
}
