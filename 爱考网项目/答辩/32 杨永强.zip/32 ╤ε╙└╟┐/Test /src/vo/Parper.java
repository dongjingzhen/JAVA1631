package vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Parper {
	private int id;
	private String title;// ����
	private String direction;//����
	private String subjectID;// ��Ŀ
	private int count;// �ܷ�
	private int counttitle;// ������
	private int score;// ÿ����ٷ�
	private Date datetime;// ����ʱ��
	private int statime;// ����ʱ��
	private String state;// �Ƿ񿪿�
	private Set<Classes> classes = new HashSet<Classes>();
	private Set<Users> users = new HashSet<Users>();
	
	public Set<Users> getUsers() {
		return users;
	}

	public void setUsers(Set<Users> users) {
		this.users = users;
	}

	public Set<Classes> getClasses() {
		return classes;
	}

	public void setClasses(Set<Classes> classes) {
		this.classes = classes;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getCounttitle() {
		return counttitle;
	}

	public void setCounttitle(int counttitle) {
		this.counttitle = counttitle;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}



	public int getStatime() {
		return statime;
	}

	public void setStatime(int statime) {
		this.statime = statime;
	}



	private Set<Title> titles = new HashSet<Title>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getSubjectID() {
		return subjectID;
	}

	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Set<Title> getTitles() {
		return titles;
	}

	public void setTitles(Set<Title> titles) {
		this.titles = titles;
	}

}
