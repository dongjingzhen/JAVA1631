package vo;

import java.util.HashSet;
import java.util.Set;

public class Classes {
	private int id;
	private String classname;
	private Set<Users> userstudent =new HashSet<Users>();
	private Set<Parper> parpers = new HashSet<Parper>();
 
	public Set<Parper> getParpers() {
		return parpers;
	}
	public void setParpers(Set<Parper> parpers) {
		this.parpers = parpers;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public Set<Users> getUserstudent() {
		return userstudent;
	}
	public void setUserstudent(Set<Users> userstudent) {
		this.userstudent = userstudent;
	}
	
}
