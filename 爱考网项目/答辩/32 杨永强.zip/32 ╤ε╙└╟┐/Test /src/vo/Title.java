package vo;

import java.util.HashSet;
import java.util.Set;

import javax.print.DocFlavor.STRING;

/*
 * ����
 * */
public class Title {
	private int id;
	private String name;//��Ŀ
	private String kind;//ѡ������  ��ѡ/��ѡ

	private int level;//���׳̶�
	private String attr;//��
	private String attrA;//ѡ��A
	private String attrB;//ѡ��B
	private String attrC;//ѡ��C
	private String attrD;//ѡ��D
	private String subjectID;
	private String test;//���Է�ʽ  ����/����
	private QuestionBank bank;//�����
	private Set<Parper> parpers = new HashSet<Parper>();
	private String attrs;
	public String getAttrs() {
		return attrs;
	}
	public void setAttrs(String attrs) {
		this.attrs = attrs;
	}
	public Set<Parper> getParpers() {
		return parpers;
	}
	public void setParpers(Set<Parper> parpers) {
		this.parpers = parpers;
	}
	public String getTest() {
		return test;
	}
	public void setTest(String test) {
		this.test = test;
	}
	
	public QuestionBank getBank() {
		return bank;
	}
	public void setBank(QuestionBank bank) {
		this.bank = bank;
	}
	public String getAttrA() {
		return attrA;
	}
	public void setAttrA(String attrA) {
		this.attrA = attrA;
	}
	public String getAttrB() {
		return attrB;
	}
	public void setAttrB(String attrB) {
		this.attrB = attrB;
	}
	public String getAttrC() {
		return attrC;
	}
	public void setAttrC(String attrC) {
		this.attrC = attrC;
	}
	public String getAttrD() {
		return attrD;
	}
	public void setAttrD(String attrD) {
		this.attrD = attrD;
	}
	public String getSubjectID() {
		return subjectID;
	}
	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}
	public void setAttr(String attr) {
		this.attr = attr;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getAttr() {
		return attr;
	}
	
	@Override
	public String toString() {
		return "Title [attr=" + attr + ", attrA=" + attrA + ", attrB=" + attrB
				+ ", attrC=" + attrC + ", attrD=" + attrD + ", bank=" + bank
				+ ", id=" + id + ", kind=" + kind + ", level=" + level
				+ ", name=" + name + ", parpers=" + parpers + ", subjectID="
				+ subjectID + ", test=" + test + "]";
	}
}
