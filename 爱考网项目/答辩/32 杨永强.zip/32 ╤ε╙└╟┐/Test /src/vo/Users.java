package vo;

import java.util.HashSet;
import java.util.Set;

public class Users {
	private int id;
	private String name;
	private String pwd;
	private Role role;
	private Classes classes;
	private Set<Parper> parpers = new HashSet<Parper>();

	public Set<Parper> getParpers() {
		return parpers;
	}
	public void setParpers(Set<Parper> parpers) {
		this.parpers = parpers;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	@Override
	public String toString() {
		return "Users [id=" + id + ", name=" + name + ", pwd=" + pwd
				+ ", role=" + role + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}

	
}
