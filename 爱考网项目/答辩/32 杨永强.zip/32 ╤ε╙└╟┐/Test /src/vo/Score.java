package vo;

import java.util.HashSet;
import java.util.Set;

public class Score {
	private int id;
	private String name;
	private int parperid;
	private int count;//�ܷ�
	private Set<Studentscore> studentscores = new HashSet<Studentscore>();
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getParperid() {
		return parperid;
	}
	public void setParperid(int parperid) {
		this.parperid = parperid;
	}
	public Set<Studentscore> getStudentscores() {
		return studentscores;
	}
	public void setStudentscores(Set<Studentscore> studentscores) {
		this.studentscores = studentscores;
	}
	

}
