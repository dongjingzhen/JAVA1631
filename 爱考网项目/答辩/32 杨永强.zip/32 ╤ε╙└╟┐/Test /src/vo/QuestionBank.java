package vo;

import java.util.HashSet;
import java.util.Set;

/*
 * ���
 * */
public class QuestionBank {
	@Override
	public String toString() {
		return "QuestionBank [direction=" + direction + ", id=" + id
				+ ", stage=" + stage + ", subjectID=" + subjectID + ", title="
				+ title + ", titles=" + titles + "]";
	}
	private int id;
	private String title;//����
	private String direction;//����
	private String stage;//�׶�
	private String subjectID;//��Ŀ
	private Set<Title> titles = new HashSet<Title>();


	public Set<Title> getTitles() {
		return titles;
	}
	public void setTitles(Set<Title> titles) {
		this.titles = titles;
	}
	public String getSubjectID() {
		return subjectID;
	}
	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	
}
