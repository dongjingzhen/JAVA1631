package action;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Parper;
import vo.QuestionBank;
import vo.Title;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class Parperaction implements Action {
	private Parper parper;
	private Title title;
	private String q1;
	private String q2;
	private String q3;
	private String q4;
	private String q5;
	private String q6;
	private String classes;
	private List<Parper> list;
	private List<QuestionBank> lists;
	private List<Object[]> objects;
	private int[] date;
	

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Criteria criteria = session.createCriteria(Parper.class);
		list = criteria.list();
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return "parper";
	}

	public String Pselect() {
		Session session = HibernateSessionFactory.getSession();
		Criteria criteria = session.createCriteria(Title.class).setFetchMode(
				"parpers", FetchMode.SELECT).createAlias("parpers", "p").add(
				Restrictions.eq("p.id", parper.getId()));
		list = criteria.list();
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return "parperselect";

	}
	public String Paddselect(){
		Session session = HibernateSessionFactory.getSession();
		Criteria criteria = session.createCriteria(QuestionBank.class);
		lists=criteria.list();
		
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return "addselect";
	}
	public String Addparper(){
		Session session = HibernateSessionFactory.getSession();
		String sql = "select top "+q1+" id, newid()  from t_title where kind='��ѡ' and level =1";
		String sql2 = "select top "+q2+" id, newid()  from t_title where kind='��ѡ' and level =2";
		String sql3 = "select top "+q3+" id, newid()  from t_title where kind='��ѡ' and level =3";
		String sql4 = "select top "+q4+" id, newid()  from t_title where kind='��ѡ' and level =1";
		String sql5 = "select top "+q5+" id, newid()  from t_title where kind='��ѡ' and level =2";
		String sql6 = "select top "+q6+" id, newid()  from t_title where kind='��ѡ' and level =3 order by newid()";
		List id=session.createSQLQuery(sql+"union all "+sql2+"union all "+sql3+"union all "+sql4+"union all "+sql5+"union all "+sql6).list();
		for (Object[] o : (List<Object[]>)id) {
			System.out.println(o[0].toString());
			parper.getTitles().add((Title) session.get(Title.class, Integer.parseInt(o[0].toString())));
		}
		parper.setState("δ����");
		session.save(parper);
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return "addparper";
	}
	public String SelectClass(){
		Session session = HibernateSessionFactory.getSession();
		Criteria criteria = session.createCriteria(Classes.class);
		objects= criteria.list();
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return "SClass";
	}
	public String StartTest(){
		Session session = HibernateSessionFactory.getSession();
		Classes c=(Classes)session.get(Classes.class, Integer.parseInt(classes));
		Parper p=(Parper)session.get(Parper.class, parper.getId());
		c.getParpers().add(parper); 
		System.out.println(parper.getId()+"  "+date[0]+" "+date[1]);
		Date data = new Date(date[0]-1990,date[1]-1,date[2],date[3],date[4],00);
		System.out.println(data);
		p.setId(parper.getId());
		p.setDatetime(data);
		p.setState("������");
		session.update(p);
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return "starts";
		
	}


	public String getClasses() {
		return classes;
	}

	public void setClasses(String classes) {
		this.classes = classes;
	}

	public List<Object[]> getObjects() {
		return objects;
	}

	public void setObjects(List<Object[]> objects) {
		this.objects = objects;
	}

	public String getQ1() {
		return q1;
	}

	public void setQ1(String q1) {
		this.q1 = q1;
	}



	public int[] getDate() {
		return date;
	}

	public void setDate(int[] date) {
		this.date = date;
	}

	public String getQ2() {
		return q2;
	}

	public void setQ2(String q2) {
		this.q2 = q2;
	}

	public String getQ3() {
		return q3;
	}

	public void setQ3(String q3) {
		this.q3 = q3;
	}

	public String getQ4() {
		return q4;
	}

	public void setQ4(String q4) {
		this.q4 = q4;
	}

	public String getQ5() {
		return q5;
	}

	public void setQ5(String q5) {
		this.q5 = q5;
	}

	public String getQ6() {
		return q6;
	}

	public void setQ6(String q6) {
		this.q6 = q6;
	}

	public Parper getParper() {
		return parper;
	}

	public void setParper(Parper parper) {
		this.parper = parper;
	}

	public Title getTitle() {
		return title;
	}

	public void setTitle(Title title) {
		this.title = title;
	}



	public List<QuestionBank> getLists() {
		return lists;
	}

	public void setLists(List<QuestionBank> lists) {
		this.lists = lists;
	}

	
	public List<Parper> getList() {
		return list;
	}

	public void setList(List<Parper> list) {
		this.list = list;
	}
}
