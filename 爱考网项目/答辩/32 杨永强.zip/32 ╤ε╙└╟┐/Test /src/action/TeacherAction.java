package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;



public class TeacherAction implements Action{
private List<Users> list;
	public List<Users> getList() {
	return list;
}
public void setList(List<Users> list) {
	this.list = list;
}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Criteria criteria= session.createCriteria(Users.class).setFetchMode("role", FetchMode.SELECT).createAlias("role", "r").add(Restrictions.eq("r.rolename", "��ʦ"));
		System.out.println("1111111111111");
		list = criteria.list();
		System.out.println(list.size());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		
		return "list";
	}

}
