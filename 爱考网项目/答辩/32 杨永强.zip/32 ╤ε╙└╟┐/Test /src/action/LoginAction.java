package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class LoginAction implements Action{
private Users users;
private List<Object[]> list;

	public Users getUsers() {
	return users;
}

public void setUsers(Users users) {
	this.users = users;
}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		String sess =null;
//		if (users.getRole().getRolename().equals("����Ա")) {
			System.out.println(111111);
			Session session = HibernateSessionFactory.getSession();
			Criteria criteria= session.createCriteria(Users.class).setFetchMode("role", FetchMode.SELECT).createAlias("role", "r").add(Restrictions.eq("r.rolename", users.getRole().getRolename()));
			ProjectionList projectionList = Projections.projectionList()
			.add(Projections.groupProperty("name"))
			.add(Projections.groupProperty("pwd"))
			.add(Projections.groupProperty("r.rolename"));
			criteria.setProjection(projectionList);
			list=criteria.list();
			for (Object[] object : (List<Object[]>)list) {
				System.out.println(object[1]+" "+object[0]+" "+object[2]);
				System.out.println(users.getName());
				if (object[0].equals(users.getName())&&object[1].equals(users.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("user", users.getName());
					sess="index";
				}else {
					sess="login";
				}
			}
			session.beginTransaction().commit();
			HibernateSessionFactory.closeSession();
//		}
		return sess;
	}

	public List<Object[]> getList() {
		return list;
	}

	public void setList(List<Object[]> list) {
		this.list = list;
	}

}
