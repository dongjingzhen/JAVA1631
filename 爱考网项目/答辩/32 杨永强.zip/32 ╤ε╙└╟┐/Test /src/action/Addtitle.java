package action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.QuestionBank;
import vo.Title;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
public class Addtitle implements Action{
	private QuestionBank bank;
	private Title titles;
	
	public QuestionBank getBank() {
		return bank;
	}

	public void setBank(QuestionBank bank) {
		this.bank = bank;
	}

	public Title getTitles() {
		return titles;
	}

	public void setTitles(Title titles) {
		this.titles = titles;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		System.out.println(bank.getId());
//		session.createSQLQuery("insert  intot_title ([name], kind, [level], attr, attrA, attrB, attrC, attrD, subjectID, test,bank_id)  values ("+titles.getName()+", ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		titles.setBank((QuestionBank)session.get(QuestionBank.class, bank.getId()));
		session.save(titles);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "addtitle";
	}
	
}
