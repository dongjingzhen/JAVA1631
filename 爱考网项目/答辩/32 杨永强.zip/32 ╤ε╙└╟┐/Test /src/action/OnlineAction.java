package action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;



import org.apache.struts2.ServletActionContext;

import org.hibernate.FetchMode;
import org.hibernate.Session;

import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Parper;
import vo.Score;
import vo.Studentscore;
import vo.Title;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class OnlineAction implements Action {
private List<Object> list;
private Parper parper;
private  Integer questionIndex=1;
private Integer questionReadyIndex;
private Title title;
private int count=0;
private Score scores;
//private Score score;
//private Studentscore studentscore;
//
//	public Score getScore() {
//	return score;
//}
//
//public void setScore(Score score) {
//	this.score = score;
//}
//
//public Studentscore getStudentscore() {
//	return studentscore;
//}
//
//public void setStudentscore(Studentscore studentscore) {
//	this.studentscore = studentscore;
//}

	public Title getTitle() {
	return title;
}



public Score getScores() {
		return scores;
	}



	public void setScores(Score scores) {
		this.scores = scores;
	}



public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

public void setTitle(Title title) {
	this.title = title;
}

	public Integer getQuestionReadyIndex() {
	return questionReadyIndex;
}

public void setQuestionReadyIndex(Integer questionReadyIndex) {
	this.questionReadyIndex = questionReadyIndex;
}

	public Integer getQuestionIndex() {
	return questionIndex;
}

public void setQuestionIndex(Integer questionIndex) {
	this.questionIndex = questionIndex;
}

	public Parper getParper() {
	return parper;
}

public void setParper(Parper parper) {
	this.parper = parper;
}



	public List<Object> getList() {
	return list;
}

public void setList(List<Object> list) {
	this.list = list;
}

	@Override
	public String execute() throws Exception {
		String sess=null;
		Session session = HibernateSessionFactory.getSession();
		String name=(String) ServletActionContext.getRequest().getSession().getAttribute("user");
		if (name==null) {
			sess="login";
		}else{
	
		List<Object> id=session.createSQLQuery("select classes_id from t_users where name= '"+name+"'").list();
		for (Object object : id) {
			int a = Integer.parseInt(object.toString());
			System.out.println(a);
			list=session.createCriteria(Parper.class).setFetchMode("classes",
					FetchMode.SELECT).createAlias("classes", "c").add(
					Restrictions.eq("c.id", Integer.parseInt(object.toString()))).add(
					Restrictions.eq("state", "������")).list();
			
		}
		sess="onlineparper";
		}
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return sess;
	}
	public String Pselect() {
		Session session = HibernateSessionFactory.getSession();
//		Criteria criteria = session.createCriteria(Title.class).setFetchMode(
//				"parpers", FetchMode.SELECT).createAlias("parpers", "p").add(
//				Restrictions.eq("p.id", parper.getId()));
	
//		list = criteria.list();
		Integer i = 1;

		  Map<Integer, Title> titles= (Map<Integer, Title>) ServletActionContext.getRequest().getSession().getAttribute("titles");

		  if (titles==null) {
				list=session.createSQLQuery("select titles_id from parbank where parper_id="+parper.getId()).list();
			  titles= new HashMap<Integer, Title>();
				for (Object object : list) {
					Title title=(Title) session.get(Title.class, Integer.parseInt(object.toString()));
					titles.put(i, title);
					i++;
				}
				  ServletActionContext.getRequest().getSession().setAttribute("titles", titles);
		}else {
			// �ȸ���ѧ������Ż��ԭ��������û�д�
			//����𰸷ǿ�
			if(title!= null)
			{	
				
				titles.put(questionIndex, title);
				 questionIndex =questionReadyIndex;
				
					
			}
		}
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return "parperselect";

	}
	public String addscore(){
		Session session = HibernateSessionFactory.getSession();
		String name=(String) ServletActionContext.getRequest().getSession().getAttribute("user");
		 Map<Integer, Title> titles= (Map<Integer, Title>) ServletActionContext.getRequest().getSession().getAttribute("titles");
		 Score score = new Score();

		 score.setName(name);
		 score.setParperid(1);
		for (Entry<Integer, Title> t : titles.entrySet()) {
			Studentscore studentscore = new Studentscore();
			studentscore.setName(t.getValue().getName());
			studentscore.setAttrA(t.getValue().getAttrA());
			studentscore.setAttrB(t.getValue().getAttrB());
			studentscore.setAttrC(t.getValue().getAttrC());
			studentscore.setAttrD(t.getValue().getAttrD());
			studentscore.setAttr(t.getValue().getAttr());
			studentscore.setAttrs(t.getValue().getAttrs());
			if (t.getValue().getAttr().equals(t.getValue().getAttrs())) {
				studentscore.setScore(5);
				count=count+5;
			}else {
				studentscore.setScore(0);
			}
			session.save(studentscore);
			score.getStudentscores().add(studentscore);
		}
		score.setCount(count);
		session.save(score);
		List<Object> l=session.createSQLQuery("select count(id) from t_score").list();
		int a =Integer.parseInt(l.get(0).toString());
		scores=(Score)session.get(Score.class, a);
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
		return "score";
		
	}
	
}
