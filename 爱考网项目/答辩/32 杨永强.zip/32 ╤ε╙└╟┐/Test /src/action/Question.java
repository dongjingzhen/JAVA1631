package action;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.QuestionBank;
import vo.Title;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class Question implements Action {
	private QuestionBank bank;
	private Title title;
	private List<Object[]> list;
	private List<Object[]> list2;

	public List<Object[]> getList2() {
		return list2;
	}

	public void setList2(List<Object[]> list2) {
		this.list2 = list2;
	}

	public Title getTitle() {
		return title;
	}

	public void setTitle(Title title) {
		this.title = title;
	}

	public QuestionBank getBank() {
		return bank;
	}

	public void setBank(QuestionBank bank) {
		this.bank = bank;
	}



	public List<Object[]> getList() {
		return list;
	}

	public void setList(List<Object[]> list) {
		this.list = list;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
//		Criteria criteri = session.createCriteria(QuestionBank.class);
		Criteria criteria = session.createCriteria(QuestionBank.class)
				.setFetchMode("titles", FetchMode.SELECT).createAlias("titles","t");
		ProjectionList projectionList = Projections.projectionList().add(
				Projections.groupProperty("title")).add(
				Projections.groupProperty("subjectID")).add(
				Projections.count("t.id")).add(
				Projections.groupProperty("id"));
		criteria.setProjection(projectionList);
		list=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
	}

	public String TitleSelect() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Title.class).setFetchMode(
				"bank", FetchMode.SELECT).createAlias("bank", "b").add(
				Restrictions.eq("b.id", bank.getId()));
		list = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "titlelist";
	}
	public String TitleDelete(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Title title1 = (Title) session.get(Title.class, title.getId());
		session.delete(title1);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "deletetitle";
		
	}
	public String TitleUpdates(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		title=(Title) session.get(Title.class, title.getId());
		Criteria criteria= session.createCriteria(QuestionBank.class);
		list=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "updateselect";
	}
	public String Updatetitle(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		System.out.println(title.getId());
		Title title1 = (Title) session.get(Title.class, title.getId());
		title1.setAttr(title.getAttr());
		title1.setAttrA(title.getAttrA());
		title1.setAttrB(title.getAttrB());
		title1.setAttrC(title.getAttrC());
		title1.setAttrD(title.getAttrD());
		title1.setKind(title.getKind());
		title1.setLevel(title.getLevel());

		title1.setName(title.getName());
		title1.setSubjectID(title.getSubjectID());
		title1.setTest(title.getTest());
		
		title1.setBank((QuestionBank)session.get(QuestionBank.class, bank.getId()));
		
		session.update(title1);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "updatetitle";
		
	}
}
