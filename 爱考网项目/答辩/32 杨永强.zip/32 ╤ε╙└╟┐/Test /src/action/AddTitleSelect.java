package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.QuestionBank;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class AddTitleSelect implements Action{
	private List<QuestionBank> list = new ArrayList<QuestionBank>();
	public List<QuestionBank> getList() {
		return list;
	}
	public void setList(List<QuestionBank> list) {
		this.list = list;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Criteria criteria= session.createCriteria(QuestionBank.class);
		list=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "selecttitle";
	}

}
