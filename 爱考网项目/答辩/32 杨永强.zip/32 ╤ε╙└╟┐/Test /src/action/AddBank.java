package action;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.QuestionBank;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class AddBank implements Action {
	private QuestionBank bank;

	public QuestionBank getBank() {
		return bank;
	}

	public void setBank(QuestionBank bank) {
		this.bank = bank;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		session.save(bank);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "addbank";
	}

}
