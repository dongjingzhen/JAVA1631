package dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Parper;
import vo.QuestionBank;
import vo.Role;
import vo.Title;
import vo.Users;

public class TestDao {
	public static void main(String[] args) {
//		title();
		innt();
//		parbank();
		addstudent();
//		aa();
//		update();
	}
	
	public static void addstudents(){
		
		
	}
	public static void update(){
		Session session = HibernateSessionFactory.getSession();
		Parper parper=(Parper)session.get(Parper.class, 1);
		parper.setState("δ����");
		parper.setTitle("����ģ��");
		parper.setDirection("SCCE");
		parper.setSubjectID("JAVA");
		parper.setState("δ����");
		parper.setCount(2);
		parper.setCounttitle(1);
		parper.setScore(2);
		parper.setStatime(60);
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
	}
public static void aa(){
	
	Session session = HibernateSessionFactory.getSession();
	Parper parper = new Parper();
	Classes classes = new Classes();
	parper.setTitle("����ģ��");
	parper.setDirection("SCCE");
	parper.setSubjectID("JAVA");
	parper.setState("δ����");
	parper.setCount(2);
	parper.setCounttitle(1);
	parper.setScore(2);
	parper.getClasses().add(classes);
	session.save(parper);
	session.save(classes);
	session.beginTransaction().commit();
	HibernateSessionFactory.closeSession();
}
	public static void addstudent() {
		Session session = HibernateSessionFactory.getSession();
		Classes classes = new Classes();
		classes.setClassname("java-1631");
//		Classes classes=(Classes)session.get(Classes.class, 1);
		List list=session.createSQLQuery("select id from t_users where role_id=2").list();
		for (Object object : list) {
			Users users=(Users) session.get(Users.class, Integer.parseInt(object.toString()));
			users.setClasses(classes);
			session.update(users);
		}
//		session.createCriteria(Role.class).add(Restrictions.eq("rolename", "ѧ��"));
//		Users users = new Users();
//		users.setName("����");
//		users.setPwd("123");
//		users.setRole((Role)session.get(Role.class, 2));
//		classes.getUserstudent().add(users);
//		users.setClasses(classes);
//		session.save(users);

		session.save(classes);
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
	}

	public static void parbank() {
		Session session = HibernateSessionFactory.getSession();
//		Parper parper = new Parper();
//		parper.setTitle("����ģ��");
//		parper.setDirection("SCCE");
//		parper.setSubjectID("JAVA");
//		parper.setState("δ����");
//		parper.setCount(2);
//		parper.setCounttitle(1);
//		parper.setScore(2);
//		QuestionBank bank = new QuestionBank();
//		Classes classes = new Classes();
//		classes.setClassname("java-1631");
//		parper.getClasses().add(classes);
//		bank.setTitle("T01");
//		bank.setDirection("SCCE");
//		bank.setStage("G1");
//		bank.setSubjectID("GTB");
		Title title = new Title();
		Title title1 = new Title();
//		parper.getTitles().add(title);
		QuestionBank bank=(QuestionBank)session.get(QuestionBank.class, 1);
		title.setAttr("A");
		title.setAttrA("A:NISHI");
		title.setAttrB("B:NISHI");
		title.setAttrC("C:NISAI");
		title.setAttrD("D:NISHI");
		title.setBank(bank);
		title.setKind("��ѡ");
		title.setLevel(1);
		title.setName("A ,B , C, D ��ѡ�Ǹ�");
		title.setSubjectID("GTB");
		title.setTest("����");
		title1.setAttr("A");
		title1.setAttrA("A:NISHI");
		title1.setAttrB("B:NISHI");
		title1.setAttrC("C:NISAI");
		title1.setAttrD("D:NISHI");
		title1.setBank(bank);
		title1.setKind("��ѡ");
		title1.setLevel(1);
		title1.setName("A ,B , C, D ��ѡ�Ǹ�");
		title1.setSubjectID("GTB");
		title1.setTest("����");
//		session.save(parper);
//		session.save(bank);
		session.save(title);
		session.save(title1);
//		session.save(classes);
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
	}

	public static void title() {
		Session session = HibernateSessionFactory.getSession();
		QuestionBank bank = new QuestionBank();
		bank.setTitle("T01");
		bank.setDirection("SCCE");
		bank.setStage("G1");
		bank.setSubjectID("GTB");
		Title title = new Title();
		title.setAttr("A");
		title.setAttrA("A:NISHI");
		title.setAttrB("B:NISHI");
		title.setAttrC("C:NISAI");
		title.setAttrD("D:NISHI");
		title.setBank(bank);
		title.setKind("��ѡ");
		title.setLevel(1);
		title.setName("A ,B , C, D ��ѡ�Ǹ�");
		title.setSubjectID("GTB");
		title.setTest("����");
		session.save(bank);
		session.save(title);
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();

	}

	public static void innt() {
		Session session = HibernateSessionFactory.getSession();
		Role role = new Role();
		role.setRolename("����Ա");
		Role role1 = new Role();
		role1.setRolename("ѧ��");
		Role role2 = new Role();
		role2.setRolename("��ʦ");
		Users users = new Users();
		Users users4 = new Users();
		users4.setName("xu");
		users4.setPwd("123");
		users4.setRole(role2);
		users.setName("yang");
		users.setPwd("123");
		users.setRole(role);
		Users users1 = new Users();
		users1.setName("qdmmn");
		users1.setPwd("123");
		users1.setRole(role1);
		Users users2 = new Users();
		users2.setName("admian");
		users2.setPwd("123");
		users2.setRole(role2);
		session.save(users);
		session.save(users1);
		session.save(users2);
		session.save(users4);
		session.save(role);
		session.save(role1);
		session.save(role2);
		session.beginTransaction().commit();
		HibernateSessionFactory.closeSession();
	}
}
