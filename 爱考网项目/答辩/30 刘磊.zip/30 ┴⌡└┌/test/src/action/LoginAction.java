package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Admin;
import vo.Student;
import vo.Teacher;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.loginDao;

public class LoginAction implements Action {
	private loginDao ldao = new loginDao();
	private Users user;
	private String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String login(){//��¼
		message = ldao.login(user);
		return message;
	}
	public String tui(){
		ServletActionContext.getRequest().getSession().invalidate();
		return "next";
		
	}
}
