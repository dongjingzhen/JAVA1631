package vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Score {
	
	private  int id;	
	private Classes classes;	
	private Student student;
	
	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	private Subject subject;
	
	private Paper paper;
	
	private Date beginTime;
	
	private Date endTime;
	
	private Float score;
	
	private Set<Scoredetails> scoredetailss = new HashSet<Scoredetails>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Float getScore() {
		return score;
	}

	public void setScore(Float score) {
		this.score = score;
	}

	public Set<Scoredetails> getScoredetailss() {
		return scoredetailss;
	}

	public void setScoredetailss(Set<Scoredetails> scoredetailss) {
		this.scoredetailss = scoredetailss;
	}

}
