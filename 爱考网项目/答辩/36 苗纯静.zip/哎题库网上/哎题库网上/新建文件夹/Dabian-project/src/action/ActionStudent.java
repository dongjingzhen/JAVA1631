package action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Class;
import vo.Paper;
import vo.Question;
import vo.Score;
import vo.Scoredetails;
import vo.Student;
import vo.Subject;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class ActionStudent implements Action {
    private Student student;
    private Paper paper;
    private String stuNo;
    private Question question; 
    private Class classe;
    private List<Class> classList= new  ArrayList<Class>();
    private List<Subject> subjectList=new ArrayList<Subject>();
    private List<Paper> paperList= new ArrayList<Paper>();
    private List<Question> questionList = new ArrayList<Question>();
    private List<Student> studentList = new ArrayList<Student>();
    private Set<Question> questionSet = new HashSet<Question>();
    private int id;
    private Scoredetails scoredetails;
    private List<Scoredetails> scoredetailsList = new ArrayList<Scoredetails>();
    private Score score;
    private List<Score> scoreList= new ArrayList<Score>();
    private Set<Paper> paperSet= new HashSet<Paper>();


    //��ѯ��ϸ��Ŀ
    public String chakanxiangzi() {
    	Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
//		Users user = (Users)ServletActionContext.getRequest().getSession().getAttribute("loginUser");
//		id = (Integer)ServletActionContext.getRequest().getSession().getAttribute("id");
//		user.setStuid(id);
//
//		List<Student> students= session.createCriteria(Student.class)
//				.add(Restrictions.eq("stuId", user.getStuid())).list();
//		Student stu = students.get(0);
//		List<Score> scores= session.createCriteria(Score.class).add(Restrictions.eq("student", stu)).list();
//		Criteria criteria=session.createCriteria(Paper.class)
//		.setFetchMode("Student", FetchMode.JOIN)
//								.createAlias("studentSet", "s")
//								.add(Restrictions.eq("s.id",stu.getId()));
//		for (Score score : scores) {
//			criteria.add(Restrictions.ne("pid", score.getPaperId()));
//		}
//		criteria.add(Restrictions.eq("state", "0"));
//		paperList = criteria.list();
//		for (Paper p : paperList) {
//			System.out.println(p.getTitle());
//			Set<Class> c = p.getClassset();
//			for (Class classes : c) {
//				System.out.println(classes.getClassName());
//			}
//		}
    	paper=(Paper)session.get(Paper.class, paper.getPid());
    	classe = (Class) session.get(Class.class, classe.getId());
		Set<Question> ques= paper.getQuestionSet();
		for (Question question : ques) {
			 System.out.println(question.getType());
			 
		}
		 transaction.commit();
		
		return "xiangxi";
	}
    
    //ѧ����ѯ�Ծ�
    public String StuPaper(){
    	
    	Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		id = (Integer)ServletActionContext.getRequest().getSession().getAttribute("id");
		student=(Student) session.get(Student.class, id);
		paperSet=student.getPaperSet();
		for ( Paper s : paperSet) {
			System.out.println(s.getClassName());
		}
		
		transaction.commit();
		return "stupaper";
	}

	//������Ϣ
	public String Person1() {
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		id = (Integer)ServletActionContext.getRequest().getSession().getAttribute("id");
		student = (Student) session.get(Student.class, id);
		return "person1";
		
	}
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public List<Student> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public List<Class> getClassList() {
		return classList;
	}
	public void setClassList(List<Class> classList) {
		this.classList = classList;
	}
	public List<Subject> getSubjectList() {
		return subjectList;
	}
	
	public String getStuNo() {
		return stuNo;
	}

	public Set<Paper> getPaperSet() {
		return paperSet;
	}

	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}

	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}


	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	public List<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	public int getId() {
		return id;
	}

	public Class getClasse() {
		return classe;
	}

	public void setClasse(Class classe) {
		this.classe = classe;
	}

	public void setId(int id) {
		this.id = id;
	}
	public Set<Question> getQuestionSet() {
		return questionSet;
	}
	public void setQuestionSet(Set<Question> questionSet) {
		this.questionSet = questionSet;
	}

	public Scoredetails getScoredetails() {
		return scoredetails;
	}

	public void setScoredetails(Scoredetails scoredetails) {
		this.scoredetails = scoredetails;
	}

	public List<Scoredetails> getScoredetailsList() {
		return scoredetailsList;
	}

	public void setScoredetailsList(List<Scoredetails> scoredetailsList) {
		this.scoredetailsList = scoredetailsList;
	}

	public Score getScore() {
		return score;
	}

	public void setScore(Score score) {
		this.score = score;
	}

	public List<Score> getScoreList() {
		return scoreList;
	}

	public void setScoreList(List<Score> scoreList) {
		this.scoreList = scoreList;
	}

}
