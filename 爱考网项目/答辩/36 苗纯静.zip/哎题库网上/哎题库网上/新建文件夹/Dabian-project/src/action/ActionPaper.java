package action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Class;
import vo.Paper;
import vo.Question;
import vo.Student;
import vo.Subject;

import com.opensymphony.xwork2.Action;
import com.sun.corba.se.spi.activation.Server;
import com.sun.org.apache.bcel.internal.generic.NEW;

import dao.HibernateSessionFactory;
//�Ծ�
public class ActionPaper implements Action{
	private int paperId;
	
    private Paper paper;
    private Subject subject;
    private int jiandan ;
    private Question question;
    private int kunnan;
    private int classid;
    private Class classe;
    private Student student;
    private Question q;
    private Question tq;
    private List<Student> studentList = new ArrayList<Student>();
    private List<Class> classList= new  ArrayList<Class>();
    private List<Subject> subjectList=new ArrayList<Subject>();
    private List<Paper> paperList= new ArrayList<Paper>();
    private List<Question> questionList = new ArrayList<Question>();
    
    

	//��ѯ����ʼ�滻
    public String tiQuestion(){
    	Session session=HibernateSessionFactory.getSession();
		Transaction traqnsaction = session.beginTransaction();
		paper=(Paper)session.get(Paper.class, paper.getPid());
		question=(Question)session.get(Question.class, question.getQid());
		
		tq=(Question)session.get(Question.class, tq.getQid());
		paper.getQuestionSet().remove(question);
		session.flush();
		paper.getQuestionSet().add(tq);
		session.saveOrUpdate(paper);
		traqnsaction.commit();
		return "tihuanok";
    }
    
    
    
    
    
    
    
    
    //�滻�Ծ�
    public String tihuan(){
    	
    	Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper=(Paper)session.get(Paper.class, paper.getPid());
    	Criteria criteria = session.createCriteria(Question.class);
    	for (Question question : paper.getQuestionSet()) {
			criteria.add(Restrictions.ne("qid", question.getQid()));
			System.out.println(question.toString());
			
		}
    	criteria.add(Restrictions.eq("kind", paper.getKind()));
    	criteria.add(Restrictions.eq("subjectId", paper.getSubjectName()));
    	
    	questionList=criteria.list();
    	System.out.println("����"+questionList.size());
    	transaction.commit();
 		
    	return "tihuan";
    }
    
    //��ѯ��ϸ��Ŀ
    public String chakanshujuan() {
    	Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
    	paper=(Paper)session.get(Paper.class, paper.getPid());
		Set<Question> ques= paper.getQuestionSet();
		for (Question question : ques) {
			 System.out.println(question.getType());
			 
		}
		 transaction.commit();
		
		return "chakan";
	}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
     * �������ʼ���� ��ʱ�����Ӱ༶ ����״̬�ı�
     * ���ʱ��û�е� ��״̬����
     * ���ʱ����� ��״̬����
     */
                
    public String BeginTime(){
    	  Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   Paper p = (Paper) session.get(Paper.class,paper.getPid());
		   
		  String  hql="select s from Student s where s.classId="+classid;
		  studentList = session.createQuery(hql).list();
		    for (Student stu : studentList) {
		    	System.out.println(stu.toString());
				p.getStudentSet().add(stu);
				
		    }
		    classe = (Class)session.get(Class.class, classid);
			//classe.getStudentSet().add(student);
			p.setClassName(classe.getClassName());
		    p.setTestTime(paper.getTestTime());
		    session.update(p);
		    session.save(classe);
		    transaction.commit();
    	return "Begin";
    }
    
    
    //��ѯsubject
    
    public String Subject(){
    	   Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   subjectList=session.createCriteria(Subject.class).list();
		   classList = session.createCriteria(Class.class).list();
		   
    	return "selectSub";
    }
    
    
    //���
    public String Random(){
    	

		   Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   Paper pa = new Paper();
		   pa.setTitle(paper.getTitle());
		   pa.setTestHour(paper.getTestHour());
		   pa.setQnumber(paper.getQnumber());
		   pa.setTotalScore(paper.getTotalScore());
		   pa.setState("0");
		   pa.setKind("��");
		   pa.setSubjectName(subject.getSubjectId()+""+subject.getStage()+""+subject.getDirection());
		   
		   
    	   String Sql ="select top "+jiandan+" qid, newId() from question where difficulty='��'" +
			    	   		" union all select top "+kunnan+" qid, newId() from" +
			    	   		" question where difficulty='����'" +
			    	   		" order by newId()";
    	
    	    paperList=session.createSQLQuery(Sql).list();
    	    classList = session.createCriteria(Class.class).list();
    	
    	   for (Paper p  : paperList) {
			question = (Question) session.get(Question.class, (Serializable) p);
			paper.getQuestionSet().add(question);
		}
    	session.save(pa);
    	//�������ӿ�Ŀ�������Ķ����� session.save(paper);
    	transaction.commit();
    	return "random";
    }
    
    
    //��ѯ
	public String SelectPaper(){
		
		   Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   //��ѯ���е�object
		   paperList=session.createCriteria(Paper.class).list();
		   classList = session.createCriteria(Class.class).list();
		   
		   for (Paper q : paperList) {
			System.out.println("״̬"+q.getState());
			
		}
		   
		   
		return "paperSelect";
	}
	
	
	
	
	
	public int getPaperId() {
		return paperId;
	}








	public void setPaperId(int paperId) {
		this.paperId = paperId;
	}








	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
	public List<Student> getStudentList() {
		return studentList;
	}

	



	public int getClassid() {
		return classid;
	}








	public void setClassid(int classid) {
		this.classid = classid;
	}








	public Question getTq() {
		return tq;
	}

	public void setTq(Question tq) {
		this.tq = tq;
	}

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}

	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}

	public Question getQuestion() {
		return question;
	}

	public Class getClasse() {
		return classe;
	}

	public List<Class> getClassList() {
		return classList;
	}

	public void setClassList(List<Class> classList) {
		this.classList = classList;
	}

	public void setClasse(Class classe) {
		this.classe = classe;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public List<Subject> getSubjectList() {
		return subjectList;
	}

	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}

	public int getJiandan() {
		return jiandan;
	}

	public void setJiandan(int jiandan) {
		this.jiandan = jiandan;
	}

	public int getKunnan() {
		return kunnan;
	}

	public void setKunnan(int kunnan) {
		this.kunnan = kunnan;
	}








	public Question getQ() {
		return q;
	}


	public void setQ(Question q) {
		this.q = q;
	}

}
