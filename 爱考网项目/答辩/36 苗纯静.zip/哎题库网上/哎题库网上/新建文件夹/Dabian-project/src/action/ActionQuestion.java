package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.derby.tools.sysinfo;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import sun.reflect.ReflectionFactory.GetReflectionFactoryAction;
import vo.Question;

import vo.Subject;
import vo.Teacher;
import vo.Users;

import DBManger.HibernateUtils;

import com.opensymphony.xwork2.Action;
import com.sun.org.apache.regexp.internal.recompile;

import dao.HibernateSessionFactory;

public class ActionQuestion implements Action{

	private Question question;
	private Users user;
	private List<Question> questionList= new ArrayList<Question>();
	private List<Subject> subjectList = new ArrayList<Subject>();
	private List<Object[]> object = new ArrayList<Object[]>();
	
	//��ѯ�޸�
	public String updateSelect(){
		
    	 question =(Question) HibernateUtils.get(Question.class, question.getQid());
		
		return "updateSelect";
		
	}
	//�޸�
	public String updataQuestion(){
		HibernateUtils.update(question);
//		System.out.println(question.toString());
		List();
		return "update";
		
	}
	/**
	 * ɾ��
	 */
	public String Delete(){
		HibernateUtils.delete(question);
		return "delecte";
	}
	/**
	 * ��������
	 */
	
	public String Add(){
		
		 HibernateUtils.add(question);		   
	     List();
		return "AddQuestion";
	}
	public String SelectAdd(){
		
		return "SelectAdd";
	}
	/**
	 * ��ѯ�����Ա���
	 * @return
	 */
	public String Lift(){
		
		   Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   String hql=" from Question where kind='"+question.getKind()+ "' and subjectid='"+question.getSubjectId()+"'";
		   String kind ="";
		   
		   questionList = session.createQuery(hql).list(); 
		   for (Question q : questionList) {
			 kind=q.getKind();
			 System.out.println(kind);
		}
		   System.out.println(hql);
		   ServletActionContext.getRequest().setAttribute("kind", kind);
		return  "left";
	}
	
	///��ѯ����һҳ
  	public String Question() {
	 	       Session session=HibernateSessionFactory.getSession();
			   Transaction transaction = session.beginTransaction();
			   //��ѯ���е�object
			   subjectList=session.createCriteria(Subject.class).list();
			   
			   String sql="select kind,count(kind),subjectid from question group by kind, subjectid";
			   System.out.println();
			   List<Object[]> questionObj= session.createSQLQuery(sql).list(); 
			   for (Object[] obj : questionObj) {
				 for (Subject sub : subjectList) {
					String a= (String)obj[2];
					
					if (a.equals(sub.getSubjectId())) {
						sub.getObjsub().add(obj);
					}
					
				}
				 System.out.println(questionObj.toString());
			}
			   for (Subject sub : subjectList) {
				Object[] ob = {"��",0,sub.getSubjectId()};
				Object[] obj= {"��",0,sub.getSubjectId()};
				if (sub.getObjsub().size()==1) {
					Object[] ct = sub.getObjsub().get(0);
					String a = (String)ct[2];
					if (a.equals("��")) {
						sub.getObjsub().add(obj);
						
					}else {
						sub.getObjsub().add(ob);
						
					}
					
				}else if (sub.getObjsub().size()==0) {
					sub.getObjsub().add(ob);
					sub.getObjsub().add(obj);
					
				}
				System.out.println(sub);
			}
			   for (Subject s : subjectList) {
//				stem.out.println(s.getSubjectId()+""+s.getDirection()+""+s.getStage());
				for (int i = 0; i < s.getObjsub().size(); i++) {
					System.out.println(s.getObjsub().get(i)[0]+"  "+s.getObjsub().get(i)[1]+"  "+s.getObjsub().get(i)[2]);
				}
				System.out.println();
				
			}
//			   System.out.println("QQQ");
//			   System.out.println(sql);
			   transaction.commit();
			   HibernateSessionFactory.closeSession();
	        return "question";
		
		
	}
	public static void main(String[] args) {
//          
//	       Session session=HibernateSessionFactory.getSession();
//		   Transaction transaction = session.beginTransaction();
//		   String sql=" kind,subjectid,count(subjectid) from Question group by kind, subjectid";
//		   List<Question>questionList= session.createQuery(sql).list(); 
//		   System.out.println("QQQ");
//		   System.out.println(sql);
//		   transaction.commit();
	   
	}
	/**
	 * ��ѯ���е�����
	 * @return
	 */
	
	//
	public void List() {
		 Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   //��ѯ���е�object
		   subjectList=session.createCriteria(Subject.class).list();
		   
		   String sql="select kind,count(kind),subjectid from question group by kind, subjectid";
		   System.out.println();
		   List<Object[]> questionObj= session.createSQLQuery(sql).list(); 
		   for (Object[] obj : questionObj) {
			 for (Subject sub : subjectList) {
				String a= (String)obj[2];
				
				if (a.equals(sub.getSubjectId())) {
					sub.getObjsub().add(obj);
				}
				
			}
			 System.out.println(questionObj.toString());
		}
		   for (Subject sub : subjectList) {
			Object[] ob = {"��",0,sub.getSubjectId()};
			Object[] obj= {"��",0,sub.getSubjectId()};
			if (sub.getObjsub().size()==1) {
				Object[] ct = sub.getObjsub().get(0);
				String a = (String)ct[2];
				if (a.equals("��")) {
					sub.getObjsub().add(obj);
					
				}else {
					sub.getObjsub().add(ob);
					
				}
				
			}else if (sub.getObjsub().size()==0) {
				sub.getObjsub().add(ob);
				sub.getObjsub().add(obj);
				
			}
			System.out.println(sub);
		}
		   for (Subject s : subjectList) {
//			stem.out.println(s.getSubjectId()+""+s.getDirection()+""+s.getStage());
			for (int i = 0; i < s.getObjsub().size(); i++) {
				System.out.println(s.getObjsub().get(i)[0]+"  "+s.getObjsub().get(i)[1]+"  "+s.getObjsub().get(i)[2]);
			}
			System.out.println();
			
		}
//		   System.out.println("QQQ");
//		   System.out.println(sql);
		   transaction.commit();
		   HibernateSessionFactory.closeSession();
      
	}
	
	
	
	
	

	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}
	public List<Object[]> getObject() {
		return object;
	}

	public void setObject(List<Object[]> object) {
		this.object = object;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	public List<Subject> getSubjectList() {
		return subjectList;
	}
	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}
	public List<Question> getQuestionList() {
		return questionList;
	}










	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}










	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}

}
