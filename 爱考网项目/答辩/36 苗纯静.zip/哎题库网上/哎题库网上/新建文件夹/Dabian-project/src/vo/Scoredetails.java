package vo;

import java.util.Set;

public class Scoredetails {
	private int id;
	
    private Score score;
	
	private Question question;
	
	private String answer;
	
	private String result;
	private Set<Scoredetails> scoredetailsSet;
	public Set<Scoredetails> getScoredetailsSet() {
		return scoredetailsSet;
	}
	public void setScoredetailsSet(Set<Scoredetails> scoredetailsSet) {
		this.scoredetailsSet = scoredetailsSet;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Score getScore() {
		return score;
	}
	public void setScore(Score score) {
		this.score = score;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}

}
