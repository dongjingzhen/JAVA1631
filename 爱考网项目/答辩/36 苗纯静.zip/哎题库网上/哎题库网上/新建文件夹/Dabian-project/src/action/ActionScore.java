package action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Class;
import vo.Paper;
import vo.Question;
import vo.Score;
import vo.Scoredetails;
import vo.Student;
import vo.Subject;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class ActionScore implements Action {
	    private Scoredetails scoredetails;
	    private List<Scoredetails> scoredetailsList = new ArrayList<Scoredetails>();
	    private Score score = new Score();
	    private List<Score> scoreList= new ArrayList<Score>();
	    private Set<Paper> paperSet= new HashSet<Paper>();
	    private List<Class> classList= new  ArrayList<Class>();
	    private List<Subject> subjectList=new ArrayList<Subject>();
	    private List<Paper> paperList= new ArrayList<Paper>();
	    private List<Question> questionList = new ArrayList<Question>();
	    private List<Student> studentList = new ArrayList<Student>();
	    private Set<Question> questionSet = new HashSet<Question>();
	    private Student student;
	    private Paper paper;
	    private Class classe;
	    
	    
	    //��ϸ�Ծ�
	    public String Score(){
	    	
	    	Session session=HibernateSessionFactory.getSession();
			Transaction transaction = session.beginTransaction();
			student= (Student) session.get(Student.class,student.getId());
			classe = (Class) session.get(Class.class, student.getClasse().getId());
			classe = student.getClasse();
			System.out.println("�༶"+classe.getClassName());
			paper =(Paper)session.get(Paper.class, paper.getPid());
		    subjectList = session.createCriteria(Subject.class).add(Restrictions.eq("subjectId", paper.getSubjectName())).list();
		    score.setClasse(classe);
			score.setStudent(student);
			score.setPaper(paper);
			score.setSubject(subjectList.get(0));
			Date beginTime = new Date();
			Date endTime = new Date(beginTime.getTime()+paper.getTestHour()*60*1000);
			score.setBeginTime(beginTime);
			score.setEndTime(endTime);
			float s = 0;
			score.setScore(s);
			session.save(score);
			score = (Score)session.createCriteria(Score.class)
			    .add(Restrictions.eq("Student",student))
			    .add(Restrictions.eq("Paper", paper)).list().get(0);
				System.out.println(score.getPaper().getTotalScore());
				
				questionSet = score.getPaper().getQuestionSet();
				for (Question question : questionSet) {
					Scoredetails scoredetails = new Scoredetails();
					scoredetails.setScore(score);
					scoredetails.setQuestion(question);
					scoredetails.setAnswer("0");
					scoredetails.setResult("0");
					session.save(scoredetails);
				}
				
				scoredetailsList =session.createCriteria(Scoredetails.class).add(Restrictions.eq("score", score)).list();
				for (Scoredetails scoredetails : scoredetailsList) {
					System.out.println(scoredetails.getQuestion().getContent());
					break;
				}
				
				transaction.commit();
				HibernateSessionFactory.closeSession();
	    	return "Score";
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public Scoredetails getScoredetails() {
		return scoredetails;
	}

	public void setScoredetails(Scoredetails scoredetails) {
		this.scoredetails = scoredetails;
	}

	public List<Scoredetails> getScoredetailsList() {
		return scoredetailsList;
	}

	public void setScoredetailsList(List<Scoredetails> scoredetailsList) {
		this.scoredetailsList = scoredetailsList;
	}

	public Score getScore() {
		return score;
	}

	public void setScore(Score score) {
		this.score = score;
	}

	public List<Score> getScoreList() {
		return scoreList;
	}

	public void setScoreList(List<Score> scoreList) {
		this.scoreList = scoreList;
	}

	public Set<Paper> getPaperSet() {
		return paperSet;
	}

	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}

	public List<Class> getClassList() {
		return classList;
	}

	public void setClassList(List<Class> classList) {
		this.classList = classList;
	}

	public List<Subject> getSubjectList() {
		return subjectList;
	}

	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}

	public List<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	public List<Student> getStudentList() {
		return studentList;
	}

	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}

	public Set<Question> getQuestionSet() {
		return questionSet;
	}

	public void setQuestionSet(Set<Question> questionSet) {
		this.questionSet = questionSet;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public Class getClasse() {
		return classe;
	}

	public void setClasse(Class classe) {
		this.classe = classe;
	}

}
