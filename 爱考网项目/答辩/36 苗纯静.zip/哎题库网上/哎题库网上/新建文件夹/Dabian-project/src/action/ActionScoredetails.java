package action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

import vo.Class;
import vo.Paper;
import vo.Question;
import vo.Score;
import vo.Scoredetails;
import vo.Student;
import vo.Subject;
import vo.Users;

public class ActionScoredetails implements Action{
	 private Scoredetails scoredetails;
	    private List<Scoredetails> scoredetailsList = new ArrayList<Scoredetails>();
	    private Score score = new Score();
	    private List<Score> scoreList= new ArrayList<Score>();
	    private Set<Paper> paperSet= new HashSet<Paper>();
	    private List<Class> classList= new  ArrayList<Class>();
	    private List<Subject> subjectList=new ArrayList<Subject>();
	    private List<Paper> paperList= new ArrayList<Paper>();
	    private List<Question> questionList = new ArrayList<Question>();
	    private List<Student> studentList = new ArrayList<Student>();
	    private Set<Question> questionSet = new HashSet<Question>();
	    private Student student;
	    private Paper paper;
	    private Class classe;
	    private int id;
	    private Set<Scoredetails> scoredetailsSet = new HashSet<Scoredetails>();
	    
	    
	    public String Details(){
	    	 Session session=HibernateSessionFactory.getSession();
	 		Transaction transaction = session.beginTransaction();
	 		
	 		score = (Score)session.get(Score.class, score.getId());
	 		scoredetailsSet = score.getScoredetailsSet();
	 		for (Scoredetails scoredetails : scoredetailsSet) {
	 			System.out.println(scoredetails.getQuestion().getAnswer()+scoredetails.getQuestion().getContent());
	 		}
	 		System.out.println(score.getStudent().getStuName());
	 		System.out.println(score.getPaper().getTotalScore());
	 		transaction.commit();
	 		HibernateSessionFactory.closeSession();
	 		return "details";
	    }
	   
	    //�鿴�ɼ�
	    public String Chengji(){
	    	
	    	id = (Integer)ServletActionContext.getRequest().getSession().getAttribute("id");
			Session session=HibernateSessionFactory.getSession();
			Transaction transaction = session.beginTransaction();
			
			student =(Student) session.get(Student.class, id);
			scoreList= session.createCriteria(Score.class).add(Restrictions.eq("student", student)).list();
			for (Score s : scoreList) {
				System.out.println(s.getPaper().getTitle());
			}
			
			transaction.commit();
			HibernateSessionFactory.closeSession();
		    return "chengji";
	    }
	    
	    
	    
	    
	    
	    
		public Scoredetails getScoredetails() {
			return scoredetails;
		}


		public void setScoredetails(Scoredetails scoredetails) {
			this.scoredetails = scoredetails;
		}


		public List<Scoredetails> getScoredetailsList() {
			return scoredetailsList;
		}


		public Set<Scoredetails> getScoredetailsSet() {
			return scoredetailsSet;
		}

		public void setScoredetailsSet(Set<Scoredetails> scoredetailsSet) {
			this.scoredetailsSet = scoredetailsSet;
		}

		public void setScoredetailsList(List<Scoredetails> scoredetailsList) {
			this.scoredetailsList = scoredetailsList;
		}


		public Score getScore() {
			return score;
		}


		public int getId() {
			return id;
		}






		public void setId(int id) {
			this.id = id;
		}






		public void setScore(Score score) {
			this.score = score;
		}


		public List<Score> getScoreList() {
			return scoreList;
		}


		public void setScoreList(List<Score> scoreList) {
			this.scoreList = scoreList;
		}


		public Set<Paper> getPaperSet() {
			return paperSet;
		}


		public void setPaperSet(Set<Paper> paperSet) {
			this.paperSet = paperSet;
		}


		public List<Class> getClassList() {
			return classList;
		}


		public void setClassList(List<Class> classList) {
			this.classList = classList;
		}


		public List<Subject> getSubjectList() {
			return subjectList;
		}


		public void setSubjectList(List<Subject> subjectList) {
			this.subjectList = subjectList;
		}


		public List<Paper> getPaperList() {
			return paperList;
		}


		public void setPaperList(List<Paper> paperList) {
			this.paperList = paperList;
		}


		public List<Question> getQuestionList() {
			return questionList;
		}


		public void setQuestionList(List<Question> questionList) {
			this.questionList = questionList;
		}


		public List<Student> getStudentList() {
			return studentList;
		}


		public void setStudentList(List<Student> studentList) {
			this.studentList = studentList;
		}


		public Set<Question> getQuestionSet() {
			return questionSet;
		}


		public void setQuestionSet(Set<Question> questionSet) {
			this.questionSet = questionSet;
		}


		public Student getStudent() {
			return student;
		}


		public void setStudent(Student student) {
			this.student = student;
		}


		public Paper getPaper() {
			return paper;
		}


		public void setPaper(Paper paper) {
			this.paper = paper;
		}


		public Class getClasse() {
			return classe;
		}


		public void setClasse(Class classe) {
			this.classe = classe;
		}


		public String execute() throws Exception {
			// TODO Auto-generated method stub
			return null;
		}
	    
}
