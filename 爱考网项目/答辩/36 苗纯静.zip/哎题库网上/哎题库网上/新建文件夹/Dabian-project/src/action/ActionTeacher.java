package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Admin;
import vo.Student;
import vo.Teacher;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class ActionTeacher implements Action {
    private Student student;
    private Teacher teacher;
    private Admin admin;
    private Users user;
    private List list = new ArrayList();
    private String message;
    private List<Student> stuList =new ArrayList<Student>();
    private List<Teacher> reaList= new ArrayList<Teacher>();
    private List<Admin> admList = new ArrayList<Admin>();
    private List<Student> studentList = new ArrayList<Student>();
	 /*
	    * ��ѯ��ʦ����
	    */
    public String Teacher () {
		// TODO Auto-generated method stub
 	  
 	   Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   reaList = session.createCriteria(Teacher.class).list();
		  System.out.println("QQQ");
		   transaction.commit();
		   HibernateSessionFactory.closeSession();
        return "teacher";
    }
    

	//������Ϣ
	public String Person() {
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		studentList=session.createCriteria(Student.class).list();
		transaction.commit();
	    HibernateSessionFactory.closeSession();
		return "person";
		
	}
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}



	public List<Student> getStuList() {
		return stuList;
	}

	public void setStuList(List<Student> stuList) {
		this.stuList = stuList;
	}

	public List<Teacher> getReaList() {
		return reaList;
	}

	public void setReaList(List<Teacher> reaList) {
		this.reaList = reaList;
	}

	public List<Admin> getAdmList() {
		return admList;
	}

	public void setAdmList(List<Admin> admList) {
		this.admList = admList;
	}

}
