package vo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.sun.org.apache.bcel.internal.generic.NEW;

//

public class Subject {
	private int id;
	private String direction;//����
	private String stage;//�׶�
	private String subjectId;//��Ŀid
	private List<Object[]> objsub=new ArrayList<Object[]>();
	private Set<Score> scoreSet;
	
	
	public Set<Score> getScoreSet() {
		return scoreSet;
	}
	public void setScoreSet(Set<Score> scoreSet) {
		this.scoreSet = scoreSet;
	}
	public List<Object[]> getObjsub() {
		return objsub;
	}
	public void setObjsub(List<Object[]> objsub) {
		this.objsub = objsub;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	
}
