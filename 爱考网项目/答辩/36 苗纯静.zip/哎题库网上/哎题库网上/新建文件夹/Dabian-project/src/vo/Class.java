package vo;

import java.sql.Date;
import java.util.Set;

public class Class {
	private int id;
	private String classNo;
	private String className;
	private String direction;
	private String headteacher;
	private String lecturer;
	private Date date;
	private String state;
	private Set<Paper> paperset;
	private Set<Student> studentSet;
	private  Set<Score>  scoreSet;;
	
	public Set<Student> getStudentSet() {
		return studentSet;
	}
	
	public Set<Score> getScoreSet() {
		return scoreSet;
	}

	public void setScoreSet(Set<Score> scoreSet) {
		this.scoreSet = scoreSet;
	}

	public void setStudentSet(Set<Student> studentSet) {
		this.studentSet = studentSet;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassNo() {
		return classNo;
	}
	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getHeadteacher() {
		return headteacher;
	}
	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}
	public String getLecturer() {
		return lecturer;
	}
	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Set<Paper> getPaperset() {
		return paperset;
	}
	public void setPaperset(Set<Paper> paperset) {
		this.paperset = paperset;
	}
}
