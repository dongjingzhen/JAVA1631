package action;

import java.util.List;

import vo.P_paper;
import vo.Subjectes;

import com.opensymphony.xwork2.Action;

import dao.P_paperDao;
import dao.TiDao;

public class TiAction implements Action {
TiDao td = new TiDao();
P_paperDao ppd = new P_paperDao();
private List<Subjectes> show_list;
private List<P_paper> show_paper;
private int sub_id;



	public int getSub_id() {
	return sub_id;
}
public void setSub_id(int subId) {
	sub_id = subId;
}
	public List<P_paper> getShow_paper() {
	return show_paper;
}
public void setShow_paper(List<P_paper> showPaper) {
	show_paper = showPaper;
}
	public List<Subjectes> getShow_list() {
	return show_list;
}
public void setShow_list(List<Subjectes> showList) {
	show_list = showList;
}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String show_P_paper(){
		show_paper = ppd.show_paper(sub_id);
		System.out.println("��ѯ���");
		return "show_P_paper";
	}
	public String show_subject(){
		show_list = td.show_subject();
		System.out.println("��ѯ����");
		return "show_subject";
	}

}
