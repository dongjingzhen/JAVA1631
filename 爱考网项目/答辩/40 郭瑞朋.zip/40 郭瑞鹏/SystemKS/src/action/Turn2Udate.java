package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import vo.Classes;
import vo.Paper;
import vo.Question;
import vo.Student;
import vo.Subject;
import vo.SubjectType;
import vo.Teacher;
import vo.TeacherDept;

import com.opensymphony.xwork2.Action;

import dao.CutString;

public class Turn2Udate implements Action {
	private List<Object> obj=new ArrayList<Object>();
	private int id=0;
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public List<Object> getObj() {
		return obj;
	}
	public void setObj(List<Object> obj) {
		this.obj = obj;
	}
	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}
	public String UpdateTest() throws Exception {
		ServletActionContext.getRequest().setAttribute("tempList",dao.HibernateUtils.createCriteria_List(Classes.class));
		return SUCCESS;
	}
	public String UpdateQuestion()throws Exception  {
		Question q=(Question)dao.HibernateUtils.get(Question.class, id);
		obj.add(q);
		ServletActionContext.getRequest().setAttribute("dept", dao.HibernateUtils.createCriteria_List(SubjectType.class));
		if (id!=0) {
		ServletActionContext.getRequest().setAttribute("str",new CutString().cut(q.getAnswer()));
		
		
			return "update";
		}else
		return SUCCESS;
	}
	public String UpdatePaper() {
		obj.add((Paper)dao.HibernateUtils.get(Paper.class, id));
		ServletActionContext.getRequest().setAttribute("dept", dao.HibernateUtils.createCriteria_List(Subject.class));
		return SUCCESS;
	}
	public String UpdateTeacher() {
		obj.add((Teacher)dao.HibernateUtils.get(Teacher.class, id));
		ServletActionContext.getRequest().setAttribute("dept", dao.HibernateUtils.createCriteria_List(TeacherDept.class));
		return SUCCESS;
	}
	public String UpdateClasses(){
		obj.add((Classes)dao.HibernateUtils.get(Classes.class, id));
		return SUCCESS;
	}
	public String UpdateStudent(){
		obj.add((Student)dao.HibernateUtils.get(Student.class, id));
		return SUCCESS;
	}
}
