package action;


import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;


import vo.Paper;
import vo.Question;
import vo.Subject;

public class CRUDPaper implements Action {
	private Paper paper;
	private int[] str;
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String read() throws Exception {
		
		paper=(Paper) dao.HibernateUtils.get(Paper.class, paper.getId());
		
		int x=((Subject) dao.HibernateUtils.get(Subject.class, paper.getSubject().getId())).getSubjectType().getId();
		ServletActionContext.getRequest().setAttribute("tempList",dao.HibernateUtils.createCriteria_OptionList(
																	Question.class,
																	new String[]{"subjectType.id"},
																	new String[]{"equals"},
																	new String[]{x+""}));
			return SUCCESS;
	}
public String readTest() throws Exception {
		
		paper=(Paper) dao.HibernateUtils.get(Paper.class, paper.getId());
		
		int x=((Subject) dao.HibernateUtils.get(Subject.class, paper.getSubject().getId())).getSubjectType().getId();
		List list=(List)dao.HibernateUtils.createCriteria_OptionList(
				Question.class,
				new String[]{"subjectType.id"},
				new String[]{"equals"},
				new String[]{x+""});
		ServletActionContext.getRequest().setAttribute("tempList",list);
		int i=0;
		for (Object object : list) {
			i++;
		}
		System.out.println("123a"+i);
		ServletActionContext.getRequest().setAttribute("inter",i);
			return SUCCESS;
	}
	public String create() throws Exception {
		new dao.TextPaper(paper,str); 
			return SUCCESS;
	}
	public String update() {
		
		Paper p=(Paper)dao.HibernateUtils.get(Paper.class, paper.getId() );
		List<Question> tempList=new ArrayList<Question>();
		for (int i:str) {
			tempList.add((Question)dao.HibernateUtils.get(Question.class, i));
		}
		p.setQuestionList(tempList);
		dao.HibernateUtils.update(p);
	
			return SUCCESS;
	}	
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public int[] getStr() {
		return str;
	}
	public void setStr(int[] str) {
		this.str = str;
	}
}
