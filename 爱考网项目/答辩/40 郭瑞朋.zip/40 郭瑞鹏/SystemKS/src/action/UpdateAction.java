package action;

import org.apache.struts2.ServletActionContext;

import vo.Classes;
import vo.Student;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

public class UpdateAction implements Action {
	private Object obj=objec();
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String update(){
		String str ="";
		if (typeNum()==1) {
			teacher();
			str="teacher";
			
		}else if (typeNum()==2) {
			dao.HibernateUtils.update((Classes)obj);
			str="classes";
		}else{
			dao.HibernateUtils.update((Student)obj);
			str="student";
		}
		return str;
	}
	private void teacher() {
		// TODO Auto-generated method stub
		dao.HibernateUtils.update((Teacher)obj);
	}
	public Object getObj() {
		return obj;
	}
	public void setObj(Object obj) {
		this.obj = obj;
	}

	private Object objec(){
			Object o=null;
				if (typeNum()==1) {
					o=new Teacher();
				}else if (typeNum()==2) {
					o=new Classes();
				}else{
					o=new Student();
				}
				
		return o;
	}
	private int typeNum(){//��ʦ���༶��ѧ��
		return Integer.parseInt((String) ServletActionContext.getRequest().getParameter("typer"));
	}
}
