package action;

import org.apache.struts2.ServletActionContext;

import vo.Student;
import vo.T_Admin;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

public class LoginAction implements Action {
	private String name;
	private String pwd;
	private int role;
	@Override
	public String execute() throws Exception {
		// TODO 
		boolean flag=false;
		if (role==1) {//ѧ��.��ʦ.����Ա
			Object x= dao.HibernateUtils.selectUser(Student.class,name, pwd);
			if (x==null) {
				flag=false;
			}else{
				flag=true;
				ServletActionContext.getRequest().getSession().setAttribute("usersId",  ((Student)x).getId());
			}
			
		}else if (role==2){
			Teacher x=(Teacher) dao.HibernateUtils.selectUser(Teacher.class,name, pwd);
			if (x==null) {
				flag=false;
			}else{
				flag=true;
				ServletActionContext.getRequest().getSession().setAttribute("usersId",  x.getId());
			}
		}else if (role==4){
			T_Admin x=(T_Admin) dao.HibernateUtils.selectUser(T_Admin.class,name, pwd);
			if (x==null) {
				flag=false;
			}else{
				flag=true;
				ServletActionContext.getRequest().getSession().setAttribute("usersId", x.getId());
			}
		}
		
		if (flag) {
			ServletActionContext.getRequest().getSession().setAttribute("userName", name);
			ServletActionContext.getRequest().getSession().setAttribute("auth", role);
			return "index";
		}else{
			return "login";
		}
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}

}
