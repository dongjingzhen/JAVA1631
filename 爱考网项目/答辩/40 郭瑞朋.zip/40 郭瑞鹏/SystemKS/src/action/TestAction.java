package action;

import vo.Paper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import tempVo.Test;
import vo.Question;
import vo.Source;
import vo.SourceData;
import vo.Student;

import com.opensymphony.xwork2.Action;

public class TestAction implements Action{
	private Map<Integer,Test> test=new HashMap<Integer, Test>();
	private int no;
	private int paperNo;
	@Override
	public String execute() throws Exception {
		System.out.println(123);
		int wrong=0;
		Source source=new Source();
		List<SourceData> sd = new ArrayList<SourceData>();
		for (int i = 1; i <= no; i++) {
			System.out.println(test.get(i));
			Test t=test.get(i);
			Question q=(Question) dao.HibernateUtils.get(Question.class, t.getId());
			
			SourceData sdd=new SourceData(q,q.getAnswer(),t.getAnswer());
			sdd.setSource(source);
			sd.add(sdd);
			if (t.getAnswer()!=null) {
				if (!t.getAnswer().equals(q.getAnswer())) {
					wrong++;
				}
			}else{
				wrong++;
			}
			
		}
		Paper p=(Paper) dao.HibernateUtils.get(Paper.class, paperNo);
		int x=p.getTotalSource()/sd.size()*(sd.size()-wrong);
		
		source.setTotalSource(x);
		source.setPaper(p);
		source.setSourceDataList(sd);
		source.setStudent(
				(Student)dao.HibernateUtils.get(Student.class, 
				Integer.parseInt(ServletActionContext.getRequest().getSession().getAttribute("usersId")+""))
				);
		dao.HibernateUtils.add(source);
		return SUCCESS;
	}
	public Map<Integer, Test> getTest() {
		return test;
	}
	public void setTest(Map<Integer, Test> test) {
		this.test = test;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getPaperNo() {
		return paperNo;
	}
	public void setPaperNo(int paperNo) {
		this.paperNo = paperNo;
	}

}
