package action;

import java.util.ArrayList;
import java.util.List;

import vo.Question;
import vo.Student;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

public class DeleteAction implements Action {
	private int allid;
	public int getAllid() {
		return allid;
	}
	public void setAllid(int allid) {
		this.allid = allid;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//ɾ��������ͨ��ҳ�洫ֵ���÷��������ٵ���ʵ����ɾ��������ͬ��
	public String DeleteTeacher(){
		dao.HibernateUtils.delete(dao.HibernateUtils.get(Teacher.class, allid));
		return SUCCESS;
	}
	public String DeleteStudent(){
		dao.HibernateUtils.delete(dao.HibernateUtils.get(Student.class, allid));
		return SUCCESS;
	}
	public String DeleteQuestion(){
		dao.HibernateUtils.delete(dao.HibernateUtils.get(Question.class, allid));
		return SUCCESS;
	}
	


	
}
