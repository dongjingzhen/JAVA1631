package action;

import java.io.File;  
import java.io.FileInputStream;  
import java.io.IOException;  
import java.util.List;
  
import org.apache.commons.io.FileUtils;  
import org.apache.poi.hssf.usermodel.HSSFCell;  
import org.apache.poi.hssf.usermodel.HSSFRow;  
import org.apache.poi.hssf.usermodel.HSSFSheet;  
import org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import org.apache.struts2.ServletActionContext;  

import vo.Teacher;
import vo.TeacherDept;
  
/** 
 * �û��ϴ�excel�ļ��������, ����excel�ļ� 
 *  
 * @author zhaoj 
 *  
 */  
public class ParseExcelAction {  
  
    private File excel;// ����������е�name����һ��  
    private String excelFileName;// ������name����+FileName  
  
    public File getExcel() {  
        return excel;  
    }  
  
    public void setExcel(File excel) {  
        this.excel = excel;  
    }  
  
    public String getExcelFileName() {  
        return excelFileName;  
    }  
  
    public void setExcelFileName(String excelFileName) {  
        this.excelFileName = excelFileName;  
    }  
  
    public String execute() throws IOException {  
  
        // ���ͻ��˵��ļ��ϴ��������  
        String desPath = ServletActionContext.getServletContext().getRealPath(  
                "/imags");  
        File destFile = new File(desPath, excelFileName);  
        FileUtils.copyFile(excel, destFile);  
  
        // ����excel  
        // �õ�һ��excel�ļ�  
        HSSFWorkbook book = new HSSFWorkbook(new FileInputStream(destFile));  
        // �õ���һ�ű�  
        HSSFSheet sheet = book.getSheetAt(0);  
        // �������  
        for (int i = 0; i <= sheet.getLastRowNum(); i++) {  
            // �õ���  
            HSSFRow row = sheet.getRow(i);  
//            for (int j = 0; j < row.getLastCellNum(); j++) {  
//                // �õ�һ���еĵ�Ԫ��  
//                HSSFCell cell = row.getCell(j);  
//                //TODO
//                System.out.print(cell + "\t");  
//            }  
            Teacher t=new Teacher();
            t.setId(Integer.parseInt(row.getCell(0)+""));
            t.setName(row.getCell(1)+"");
            t.setLoginID(row.getCell(2)+"");
            t.setLoginPwd(row.getCell(3)+"");
            List<TeacherDept> l=dao.HibernateUtils.createCriteria_OptionList(TeacherDept.class,
            		new String[]{"deptName"},
            		new String[]{"eq"},
            		new String[]{""+row.getCell(4)+""});
            t.setTeacherDept(l.get(0));
            dao.HibernateUtils.update(t);
        }  
  
        return "success";  
    }  
}  