package vo;

import java.util.HashSet;
import java.util.Set;

public class Subjectes {
	private int sub_id;
	private String sub_Name;
	private Direction direction;
	private Stage stage;
	public Set<P_paper> paper_set = new HashSet<P_paper>();
	public Set<P_paper> getPaper_set() {
		return paper_set;
	}
	public void setPaper_set(Set<P_paper> paperSet) {
		paper_set = paperSet;
	}
	public int getSub_id() {
		return sub_id;
	}
	public void setSub_id(int subId) {
		sub_id = subId;
	}
	public String getSub_Name() {
		return sub_Name;
	}
	public void setSub_Name(String subName) {
		sub_Name = subName;
	}
	public Direction getDirection() {
		return direction;
	}
	public void setDirection(Direction direction) {
		this.direction = direction;
	}
	public Stage getStage() {
		return stage;
	}
	public void setStage(Stage stage) {
		this.stage = stage;
	}
	

}
