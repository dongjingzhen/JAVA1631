package vo;

import java.util.HashSet;
import java.util.Set;

public class AllPaper {
	private int pid;
	private String pName;
	private Set<Grade> gradeSet = new HashSet<Grade>();
	
	public Set<Grade> getGradeSet() {
		return gradeSet;
	}
	public void setGradeSet(Set<Grade> gradeSet) {
		this.gradeSet = gradeSet;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	

}
