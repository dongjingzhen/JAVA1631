package vo;

public class T_Admin {
	/**
	 * @see HibernateUtils
	 */
	private int id;
	private String loginID;
	private String loginPwd;
	public T_Admin( String loginID, String loginPwd) {
		this.loginID = loginID;
		this.loginPwd = loginPwd;
	}
	public T_Admin(){}
	
	
	
	
	
	
	//////////////////////////////////////////////////////
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	
	
}
