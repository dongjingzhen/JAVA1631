package vo;

import java.util.List;

public class Question {
	private int id;
	private String kind;
	private String content;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String answer;
	private String defficulty;
	
	private SubjectType subjectType ;
	private List<Paper> paperList;
	
	public Question(){};
	public Question( String kind, String content, String optionA,
			String optionB, String optionC, String optionD, String answer,
			String defficulty, SubjectType subjectType) {
		this.kind = kind;
		this.content = content;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.optionD = optionD;
		this.answer = answer;
		this.defficulty = defficulty;
		this.subjectType = subjectType;
	}
	
	
	
	
	
	
	
	
	
	
	////////////////////////////////////////////
	public int getId() {
		return id;
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getDefficulty() {
		return defficulty;
	}
	public void setDefficulty(String defficulty) {
		this.defficulty = defficulty;
	}
	public SubjectType getSubjectType() {
		return subjectType;
	}
	public void setSubjectType(SubjectType subjectType) {
		this.subjectType = subjectType;
	}
	
	
	
}
