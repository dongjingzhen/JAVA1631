package vo;

import java.util.List;

public class Student {
	/**
	 * @see HibernateUtils
	 */
	private int id;
	private String name;
	private String loginID;
	private String loginPwd;
	private Classes classes;
	private List<Source> sourceList;
	public Student( String name, String loginID, String loginPwd) {
		this.name = name;
		this.loginID = loginID;
		this.loginPwd = loginPwd;
	}
	public Student() {}
	
	
	
	
	
	
	
	
	
	
	////////////////////////////////////////////////////
	
	public int getId() {
		return id;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public List<Source> getSourceList() {
		return sourceList;
	}
	public void setSourceList(List<Source> sourceList) {
		this.sourceList = sourceList;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	
	
}
