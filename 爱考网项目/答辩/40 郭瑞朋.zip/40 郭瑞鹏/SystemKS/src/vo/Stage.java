package vo;

public class Stage {
	private int sta_id;
	private String sta_name;
	public int getSta_id() {
		return sta_id;
	}
	public void setSta_id(int staId) {
		sta_id = staId;
	}
	public String getSta_name() {
		return sta_name;
	}
	public void setSta_name(String staName) {
		sta_name = staName;
	}
	
	

}
