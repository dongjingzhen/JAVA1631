package vo;


public class Teacher {
	/**
	 * @see HibernateUtils
	 */
	private int id;
	private String name;
	private String loginID;
	private String loginPwd;
	private TeacherDept teacherDept;

	
	public Teacher( String name, String loginID, String loginPwd,TeacherDept teacherDept) {
		this.name = name;
		this.loginID = loginID;
		this.loginPwd = loginPwd;
		this.teacherDept = teacherDept;
	}
	public Teacher() {}
	
	
	
	
	
	
	
	
	///////////////////////////////////////////////////////////////////////////////
	public int getId() {
		return id;
	}
	public TeacherDept getTeacherDept() {
		return teacherDept;
	}
	public void setTeacherDept(TeacherDept teacherDept) {
		this.teacherDept = teacherDept;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}

	
}
