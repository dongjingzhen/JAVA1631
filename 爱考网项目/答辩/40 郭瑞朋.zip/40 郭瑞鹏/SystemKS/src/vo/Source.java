package vo;

import java.util.Date;
import java.util.List;

public class Source {
	private int id ;
	private Paper paper;
	private Student student;
	private Date beginTime;
	private Date endTime;
	private int totalSource;
	
	private List<SourceData> sourceDataList;

	public Source(Paper paper, Student student, Date beginTime, Date endTime,
			int totalSource) {
		this.paper = paper;
		this.student = student;
		this.beginTime = beginTime;
		this.endTime = endTime;
		this.totalSource = totalSource;
	}
	public Source(){};
	////////////////////////////////////////
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public int getTotalSource() {
		return totalSource;
	}
	public void setTotalSource(int totalSource) {
		this.totalSource = totalSource;
	}
	public List<SourceData> getSourceDataList() {
		return sourceDataList;
	}

	public void setSourceDataList(List<SourceData> sourceDataList) {
		this.sourceDataList = sourceDataList;
	}
	
}
