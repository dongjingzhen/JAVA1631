package vo;

import java.util.List;

public class SubjectType {
	private int id;
	private String subjectName;
	private List<Question> questionList;
	
	public SubjectType() {}
	public SubjectType(String subjectName) {
		this.subjectName = subjectName;
	}

	
	
	
	
	
	






	//////////////////////////////////////////////////////////
	public int getId() {
		return id;
	}
	public List<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}


	
	
	
}
