package vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Grade {
	private int gid;//
	private String gNum;//�༶���
	private String gName;//�༶��
	private Teacher m_teacher;//�����Σ����
	private Teacher j_teacher;//��ʦ�����
	private Date begin_time;//����ʱ��
	private String gDirection;//����
	private int gState;//״̬
	private Set<AllPaper> allPaperSet = new HashSet<AllPaper>();
	
	
	
	public Set<AllPaper> getAllPaperSet() {
		return allPaperSet;
	}
	public void setAllPaperSet(Set<AllPaper> allPaperSet) {
		this.allPaperSet = allPaperSet;
	}
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getgNum() {
		return gNum;
	}
	public void setgNum(String gNum) {
		this.gNum = gNum;
	}
	public String getgName() {
		return gName;
	}
	public void setgName(String gName) {
		this.gName = gName;
	}
	public Teacher getM_teacher() {
		return m_teacher;
	}
	public void setM_teacher(Teacher mTeacher) {
		m_teacher = mTeacher;
	}
	
	public Teacher getJ_teacher() {
		return j_teacher;
	}
	public void setJ_teacher(Teacher jTeacher) {
		j_teacher = jTeacher;
	}
	public Date getBegin_time() {
		return begin_time;
	}
	public void setBegin_time(Date beginTime) {
		begin_time = beginTime;
	}
	public String getgDirection() {
		return gDirection;
	}
	public void setgDirection(String gDirection) {
		this.gDirection = gDirection;
	}
	public int getgState() {
		return gState;
	}
	public void setgState(int gState) {
		this.gState = gState;
	}
	
	
	

}
