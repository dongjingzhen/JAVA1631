package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.AllPaper;
import vo.Grade;

public class KaoShiDao {
	
	public static void main(String[] args) {
		Show_gra_allPap();
	}
	public static void Show_gra_allPap(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<AllPaper> list = session.createCriteria(AllPaper.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("��ѯ���");
		for (AllPaper a : list) {
			System.out.println(a.getpName());
		}
	}

}
