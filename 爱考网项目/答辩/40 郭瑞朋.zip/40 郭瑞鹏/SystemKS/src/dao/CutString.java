package dao;

public class CutString {
	String strin[]=new String[4];
	int index=0;
public String[] cut(String s){
	
		if (s.length()!=1) {
			String str=s.substring(0, 1);
			s=s.substring(2);
			strin[index]=str;
			index++;
			this.cut(s);
		}else{
			
			strin[index]=s;
		}
		String[] ss=cut(strin);
		return ss;
	}
private String[] cut(String[] s){ 
	for (int i = s.length-1; i >=0 ; i--) {
		if (s[i]!=null) {
		if (s[i].equals("a")) {
			s[i]="m";
			s[0]="a";
		}else if (s[i].equals("b")) {
			s[i]="m";
			s[1]="b";
		}else if (s[i].equals("c")) {
			s[i]="m";
			s[2]="c";
		}else if (s[i].equals("d")) {
			s[i]="m";
			s[3]="d";
		}
		}
	}
	for (String string : s) {
		System.out.println(string);
	}
	return s;
}
public String combine(String[] s){
	String str = "";
	for (String string : s) {
		str=str+string+",";
	}
	str=str.substring(0, str.length()-1);
	return str;
}
public static void main(String[] args) {
	CutString c=new CutString();
	String m[]=c.cut("a,c,d");
//	for (String string : m) {
//		System.out.println(string);
//	}
//	System.out.println(c.combine(m));
	
}
}
