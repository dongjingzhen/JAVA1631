package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Admin;
import vo.Student;
import vo.Teacher;

public class LoginDao {
	public List<Admin> adminLogin(String Num,String Pwd){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Admin> list = session.createCriteria(Admin.class)
							.add(Restrictions.eq("aNum", Num))
							.add(Restrictions.eq("aPwd", Pwd))
							.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("��ѯ���");
		return list;
	}
	public List<Teacher> teacherLogin(String Num,String Pwd){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Teacher> list = session.createCriteria(Teacher.class)
		.add(Restrictions.eq("tNum", Num))
		.add(Restrictions.eq("tPwd", Pwd))
		.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}
	public List<Student> studentLogin(String Num,String Pwd){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Student> list = session.createCriteria(Student.class)
		.add(Restrictions.eq("sNum", Num))
		.add(Restrictions.eq("sPwd", Pwd))
		.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return list;
	}
//	public static void main(String[] args) {
//		init();
//	}
//	public static void init(){
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction = session.beginTransaction();
//		Admin admin = new Admin();
//		admin.setaNum("admin");
//		admin.setaPwd("admin");
//		session.save(admin);
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
//	}

}
