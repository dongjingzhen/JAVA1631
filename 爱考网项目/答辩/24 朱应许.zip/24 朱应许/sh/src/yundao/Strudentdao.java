package yundao;

import java.util.List;



import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Strudent;

import dao.HibernateSessionFactory;

public class Strudentdao {

	@SuppressWarnings("unchecked")
	public List<Strudent> list()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Strudent> strudentList =(List<Strudent>) session.createCriteria(Strudent.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return strudentList;
		
	}
}
