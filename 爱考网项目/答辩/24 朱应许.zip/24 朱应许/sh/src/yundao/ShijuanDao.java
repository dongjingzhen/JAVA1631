package yundao;

import io.Question;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;

public class ShijuanDao {
	@SuppressWarnings("unchecked")
	public List<Question> list()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Question> questionjiaList =(List<Question>) session.createCriteria(Question.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return questionjiaList;
		
	}
}
