package vo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ��������
 * @author gao
 *
 */ 
public class TestQusertion {
	private int id;
	private String keMu;
	private String content;//�������Ŀ
	private int diJiQi;//�ڼ���
	private String testType;//��������͵�ѡOR��ѡ
	private String optionA;//ѡ��A
	private String optionB;//ѡ��B
	private String optionC;//ѡ��C
	private String optionD;//ѡ��D
	private String ansWer;//��
	private String difficuLty;//�Ѷ�
	private String testTypeJOrB;//����OR����
	private String chaPter;//�½�
	
	
	private Question questiones;
	//TestQusertion is not mapped [select t.keMu,c.fewQuest,t.testType,t.testTypeJOrB, count(t)
	//from TestQusertion t join t.questiones c group by t.keMu,c.fewQuest,t.testType,t.testTypeJOrB]
	
	private Set<ThePapers> ThePapersList = new HashSet<ThePapers>();
	public String getKeMu() {
		return keMu;
	}
	public void setKeMu(String keMu) {
		this.keMu = keMu;
	}
	public int getDiJiQi() {
		return diJiQi;
	}
	public void setDiJiQi(int diJiQi) {
		this.diJiQi = diJiQi;
	}
	public String getTestTypeJOrB() {
		return testTypeJOrB;
	}
	public void setTestTypeJOrB(String testTypeJOrB) {
		this.testTypeJOrB = testTypeJOrB;
	}
	public String getTestType() {
		return testType;
	}
	public void setTestType(String testType) {
		this.testType = testType;
	}

	
	public Set<ThePapers> getThePapersList() {
		return ThePapersList;
	}
	public void setThePapersList(Set<ThePapers> thePapersList) {
		ThePapersList = thePapersList;
	}

	public Question getQuestiones() {
		return questiones;
	}
	public void setQuestiones(Question questiones) {
		this.questiones = questiones;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getAnsWer() {
		return ansWer;
	}
	public void setAnsWer(String ansWer) {
		this.ansWer = ansWer;
	}
	public String getDifficuLty() {
		return difficuLty;
	}
	public void setDifficuLty(String difficuLty) {
		this.difficuLty = difficuLty;
	}
	public String getChaPter() {
		return chaPter;
	}
	public void setChaPter(String chaPter) {
		this.chaPter = chaPter;
	}
	
}
