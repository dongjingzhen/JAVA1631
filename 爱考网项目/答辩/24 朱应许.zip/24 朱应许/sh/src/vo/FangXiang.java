package vo;

import java.util.ArrayList;
import java.util.List;

public class FangXiang {
	private int id;
	private String fangName;//��רҵ������
	private List<Question> questionesList= new ArrayList<Question>();
	private List<Strudent> studentsList= new ArrayList<Strudent>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFangName() {
		return fangName;
	}
	public void setFangName(String fangName) {
		this.fangName = fangName;
	}
	public List<Question> getQuestionesList() {
		return questionesList;
	}
	public void setQuestionesList(List<Question> questionesList) {
		this.questionesList = questionesList;
	}
	public List<Strudent> getStudentsList() {
		return studentsList;
	}
	public void setStudentsList(List<Strudent> studentsList) {
		this.studentsList = studentsList;
	}
	
}
