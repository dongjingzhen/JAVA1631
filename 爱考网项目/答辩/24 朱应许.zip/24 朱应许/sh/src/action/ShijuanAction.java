package action;

import io.Question;


import java.util.List;

import yundao.ShijuanDao;


import com.opensymphony.xwork2.Action;

public class ShijuanAction implements Action{
	private List<Question> questionList;
	

	
	public List<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String list() throws Exception {
		
		ShijuanDao ShijuanDao = new ShijuanDao();
		questionList = ShijuanDao.list();
		
		return "list";
	}
	
}
