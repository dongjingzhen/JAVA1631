package action;

import org.apache.struts2.ServletActionContext;

import org.hibernate.Session;
import org.hibernate.Transaction;


import vo.Admin;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class LoginAction implements Action{

	private Admin users;
	private String role;
	

	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}
	public Admin getUsers() {
		return users;
	}


	public void setUsers(Admin users) {
		this.users = users;
	}


	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
	
		return null;
	}
	public String login()
	{
	
		Session session =HibernateSessionFactory.getSession();
		
		Transaction transaction =session.beginTransaction();
		
		//�������ݿ��ѯ��¼
		transaction.commit();
		HibernateSessionFactory.closeSession();
		String result ="index";
		if("admin".equals(role))
		{
			String sql = "select *from ";
			System.out.println(sql);
			
		}
		
		if("student".equals(role))
		{
			String sql = "select *from ";
			System.out.println(sql);
		}
		
		if("teacher".equals(role))
		{
			String sql = "select *from ";
			System.out.println(sql);
		}
		ServletActionContext.getRequest().getSession().setAttribute("users", users);
		return result;
		
		
		
	}
	
}
