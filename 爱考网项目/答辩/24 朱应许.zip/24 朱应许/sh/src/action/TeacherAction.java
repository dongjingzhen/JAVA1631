package action;



import java.util.List;

import vo.Teacher;
import yundao.TeacherDao;

import com.opensymphony.xwork2.Action;


public class TeacherAction implements Action {

	private List<Teacher> teacherList;
	public List<Teacher> getTeacherList() {
		return teacherList;
	}



	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}



	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	public String list() throws Exception {
		
		
		TeacherDao teacherDao = new TeacherDao();
		teacherList =teacherDao.list();
		return "list";
	}
	
	

}
