package tempVo;

import java.util.Arrays;

public class Test {
	private int id;
	private String answer;
	private String[] str;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Test [answer=" + answer + ", id=" + id + ", str="
				+ Arrays.toString(str) + "]";
	}
	public String getAnswer() {
		if (answer==null) {
			if (str!=null) {
				if (str.length!=0) {
					answer=new dao.CutString().combine(str);
				}
			}
		}
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String[] getStr() {
		if (str==null) {
			if (answer!=null) {
				str=new dao.CutString().cut(answer);
			}
		}
		return str;
	}
	public void setStr(String[] str) {
		this.str = str;
	}
	
}
