package dao;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.HibernateException;  
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.cfg.Configuration;  
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.hql.ast.tree.OrderByClause;

import com.sun.xml.internal.bind.v2.model.core.ID;
import com.sun.xml.internal.fastinfoset.algorithm.IntEncodingAlgorithm;

import sun.reflect.LangReflectAccess;
import vo.SubjectType;
  
public final class HibernateUtils {  
	public final static  String ORDER_SORT = "orderSort";
	public final static  String ORDER_NAME = "orderName";
	public final static  String LIKE="like";
	public final static  String EQUALS="equals";
    private static SessionFactory factory;  
    public static Session getSession() {  
        return factory.openSession();  
    }  
  
    private HibernateUtils() { // ����ģʽ  
    }  
  
    static { // ���������ʱִ��һ��  
        // configureĬ�ϼ���hibernate.cfg.xml  
        // �������hibernate.cfg.xml����ָ���������֣����ļ���classpath����  
        Configuration config = new Configuration().configure();  
        factory = config.buildSessionFactory();  
    }  
  
    public static void add(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
            session.save(obj);  
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static void update(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
            session.saveOrUpdate(obj);  
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static void delete(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
            session.delete(obj);  
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static Object get(Class clazz, Serializable id) {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession();  
            Object obj = session.get(clazz, id);  
            return obj;  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
    public static Object load(Class clazz, Serializable id) {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession();  
            Object obj = session.load(clazz, id);  
            return obj;  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
    public static Object selectUser(Class clazz,String name,String pwd){
    	Session session = null;  
        try {  
        	System.out.println(name+pwd);
            session = HibernateUtils.getSession();  
            List obj = session.createCriteria(clazz)
            					.add(Restrictions.eq("loginID", name)).add(Restrictions.eq("loginPwd", pwd)).list();
           if (obj.get(0)!=null) {
        	   System.out.println("...");
        	   System.out.println( obj.get(0));
        	   return  obj.get(0); 
           }else {
        	   System.out.println("!!!");
        	   return null; 
           }
            
        }catch (Exception e) {
        	System.out.println("!!!");
			return null;
		} finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }
    public static List createCriteria_List(Class clazz) {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession();  
            List obj = session.createCriteria(clazz).list();  
            return obj;  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
    public static List<Object[]> selectSubjectType() {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession();  
            Criteria c=session.createCriteria(SubjectType.class)
			.setFetchMode("questionList", FetchMode.JOIN).createAlias("questionList", "temp")
			.setProjection(Projections.projectionList()
							.add(Projections.count("temp.id"))
							.add(Projections.groupProperty("id"))
							.add(Projections.groupProperty("subjectName"))
							)
							.addOrder(Order.asc("id"));
            return c.list();  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
    public static List createCriteria_PageList(Class clazz,int pageNum,int pageSize ) {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession(); 
            List obj = session.createCriteria(clazz).setFirstResult((pageNum-1)*pageSize).setMaxResults(pageNum*pageSize).list();  
            return obj;  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
    public static List createCriteria_OptionList(Class clazz,String[] s1,String[] s2, int pageNum,int pageSize ) {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession(); 
            Criteria c= session.createCriteria(clazz);  
            if (clazz==vo.Teacher.class) {
            	c.setFetchMode("teacherDept", FetchMode.JOIN).createAlias("teacherDept", "temp");
			}else if (clazz==vo.Student.class) {
				c.setFetchMode("classes", FetchMode.JOIN).createAlias("classes", "temp");
			}
            if (s2!=null) {
            	 for (int i = 0; i < s2.length; i++) {
     				c.add(Restrictions.like(s1[i], "%"+s2[i]+"%"));
     			}
			}
            c.setFirstResult((pageNum-1)*pageSize).setMaxResults(pageNum*pageSize);
            return c.list();  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
    public static List createCriteria_OptionList(Class clazz,String[] s1,String[] s,String[] s2) {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession(); 
            Criteria c= session.createCriteria(clazz);  
           
            if (s2!=null) {
            	 for (int i = 0; i < s2.length; i++) {
            		 if (s[i].equals("like")) {
            			 c.add(Restrictions.like(s1[i], "%"+s2[i]+"%"));
					}else if (s[i].equals("equals")) {
						c.add(Restrictions.eq(s1[i], Integer.parseInt(s2[i])));
					}
     				
     			}
			}
            return c.list();  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
    
    @SuppressWarnings("unchecked")
	public static List<Object> list(Class clazz,Map filterMap,Map orderMap,int firstNo,int  maxNo ) {  
        Session session = null;  
        try {  
        	List<Object> list = new ArrayList<Object>();
            session = HibernateUtils.getSession(); 
            Criteria criteria =session.createCriteria(clazz);
			if(filterMap!=null)
			{
				 for(int i=0;i<filterMap.size();i++)
		            {
					 	Iterator iteratorFilter = filterMap.keySet().iterator();
					 	while(iteratorFilter.hasNext())
					 	{
					 		Object key = iteratorFilter.next();
					 		Criterion criterion = Expression.like(key.toString(),filterMap.get(key) );
					 		criteria.add(criterion);
					 	}
		            }
			}
			if(orderMap!=null)
			{
				String orderSort =(String) orderMap.get(ORDER_SORT);
				String orderName = (String) orderMap.get(ORDER_NAME);
				
				if(orderSort.equals("desc"))
				{
					criteria.addOrder(Order.desc(orderName));
				}
				else
				{
					criteria.addOrder(Order.asc(orderName));
				}
			}
			
			criteria.setFirstResult(firstNo).setMaxResults(maxNo);
			
			list=criteria.list();
            return   list;
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    } 
    public static List<Object> Cut_List(List list, int firstNum,int lastNum){
    	//TODO first 0~list.size()
    	for (int i = list.size()-1; i >=0 ; i--) {
			if (i>lastNum) {
				list.remove(i);
			}else
			if (i<firstNum) {
				list.remove(i);
			}
		}
    	
    	return list;
    }
   
}  