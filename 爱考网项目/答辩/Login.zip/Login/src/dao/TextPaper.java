package dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.transform.Transformers;

import vo.Paper;
import vo.Question;
import vo.Subject;

public class TextPaper {
		private String[] TEMP={"��","�е�","����","��","�е�","����"}; 
	public TextPaper(Paper paper,int[] question) {
		Subject s=(Subject)dao.HibernateUtils.get(Subject.class, paper.getSubject().getId());
		paper.setSubject(s);
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String sql="";
		for (int i = 0; i < question.length; i++) {
			String str="";
			if (i<=2) {
				str="��ѡ";
			}else{
				str="Ϲѡ";
			}
			sql=sql+"select * from(select top "+question[i]+" id from question where subjectType_id="+s.getSubjectType().getId()+" and defficulty= '"+TEMP[i]+"' and kind= '"+str+"' order by newId()) as question"+i+" " ;
			if (i!=5) {
				sql=sql+" union all ";
			}else{
				sql=sql+" order by id ";
			}
		}
		Query query=session.createSQLQuery(
				sql
				);
		List<Object> l=query.list();
		for (Object p :l) {
			paper.getQuestionList().add((Question)dao.HibernateUtils.get(Question.class, Integer.parseInt(p.toString())));
			System.out.println(p);
		}
		session.saveOrUpdate(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	public static void main(String[] args) {
		int q[]={1,2,3,1,0,1};
		TextPaper t=new TextPaper(new Paper(),q);
	}
}
