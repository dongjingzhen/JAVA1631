package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.*;

public class tempDao {
	public static void main(String[] args) {
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Paper_Classes pc=new Paper_Classes();
		pc.setTestTime(new Date(100,1,1,17,0));
		session.save(pc);
		session.saveOrUpdate(new T_Admin("admin","123"));
		TeacherDept t1=new TeacherDept("��ʦ");
		TeacherDept t2=new TeacherDept("������");
		session.saveOrUpdate(t1);
		session.saveOrUpdate(t2);
		session.saveOrUpdate(new Teacher("����ʦ","201701","123",t1)); 
		session.saveOrUpdate(new Teacher("����ʦ","201702","123",t2));
		Classes classes=new Classes("java1631", "����ʦ","����ʦ");
		classes.getPaperList().add(pc);
		Student student=new Student("��־Զ","163103","123");
		student.setClasses(classes);
		SubjectType subjectType=new SubjectType("��������");
		Subject subject=new Subject( "SCME", "G2", subjectType);
		Question question=new Question(
				"Ϲѡ", "��˧����", "��˧", "˧", "��", "�ǳ���", "a,c,d", "��", subjectType);
		List<Paper_Classes> classesList=new ArrayList<Paper_Classes>();
		classesList.add(pc);
		List<Question> questionList=new ArrayList<Question>();
		questionList.add(question);
		Paper paper =new Paper(subject, "��", "Java,�����ŵ�����.",
				classesList, 60, 100, questionList , "�ѿ���");
		Source source=new Source(paper, student,  new Date(),  new Date(), 0);
		SourceData sourceData=new SourceData(question, source, "a,c,d", "b");
		

		session.saveOrUpdate(classes);
		session.saveOrUpdate(student);
		session.saveOrUpdate(subjectType);
		session.saveOrUpdate(question);
		session.saveOrUpdate(subject);
		session.saveOrUpdate(paper);
		session.saveOrUpdate(source);
		session.saveOrUpdate(sourceData);
		
		System.out.println(session.get(Student.class, 1));
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		
//		
		
	}
}
