package action;

import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import vo.Classes;
import vo.Paper;
import vo.Paper_Classes;
import vo.Student;
import vo.T_Admin;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

public class StartTest implements Action {
	private int[] classes;
	private Paper paper;
	private int role;
	private int[] date;//years,month,day,hours,min
	@Override
	public String execute() throws Exception {
		for (int x : date) {
			System.out.println(x);
		}
		for (int i = 0; i < classes.length; i++) {
			Paper_Classes pc=new Paper_Classes();
			Date d=new Date(date[i*5],date[i*5+1]-1,date[i*5+2],date[i*5+3],date[i*5+4]);
			System.out.println(d);
			pc.setTestTime(d);
			pc.setClasses((Classes)dao.HibernateUtils.get(Classes.class, classes[i]));
			pc.setPaper((Paper)dao.HibernateUtils.get(Paper.class, paper.getId()));
			dao.HibernateUtils.add(pc);
		}
		
		return SUCCESS;
	}
	public int[] getClasses() {
		return classes;
	}
	public void setClasses(int[] classes) {
		this.classes = classes;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public int[] getDate() {
		return date;
	}
	public void setDate(int[] date) {
		this.date = date;
	}


}
