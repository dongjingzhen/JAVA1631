package action;

import vo.Question;
import vo.SubjectType;

import com.opensymphony.xwork2.Action;

import dao.CutString;

public class CRUDQuestion implements Action {
	private Question question;
	private String[] str;
	@Override
public String execute() throws Exception {
		return SUCCESS;
	}
	public String create() throws Exception {
		question.setAnswer((new CutString()).combine(str));
		question.setSubjectType((SubjectType)dao.HibernateUtils.get(SubjectType.class, question.getSubjectType().getId()));
		dao.HibernateUtils.add(question);
		
			return SUCCESS;
	}
	public String read() throws Exception {
		question=(Question) dao.HibernateUtils.get(Question.class, question.getId());
		str=new CutString().cut(question.getAnswer());
			return SUCCESS;
	}
	public String update() throws Exception {
		question.setAnswer(new CutString().combine(str));
		dao.HibernateUtils.update(question);
			return SUCCESS;
		}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public String[] getStr() {
		return str;
	}
	public void setStr(String[] str) {
		this.str = str;
	}
	
}

