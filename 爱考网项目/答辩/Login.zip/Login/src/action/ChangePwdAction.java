package action;

import org.apache.struts2.ServletActionContext;

import vo.Student;

import com.opensymphony.xwork2.Action;

public class ChangePwdAction implements Action{
	Student obj;
	@Override
	public String execute() throws Exception {
		obj=(Student) dao.HibernateUtils.get(Student.class, 
		Integer.parseInt(ServletActionContext.getRequest().getSession().getAttribute("usersId")+""));
		
		return SUCCESS;
	}
	
	public String ChangeStudent() throws Exception {
		Student s=(Student) dao.HibernateUtils.get(Student.class, 
				Integer.parseInt(ServletActionContext.getRequest().getSession().getAttribute("usersId")+""));
		s.setLoginPwd(obj.getLoginPwd());
		dao.HibernateUtils.update(s);
		return SUCCESS;
	}

	public Student getObj() {
		return obj;
	}

	public void setObj(Student obj) {
		this.obj = obj;
	}
	
	
}
