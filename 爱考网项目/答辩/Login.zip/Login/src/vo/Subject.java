package vo;

public class Subject {
	private int id;
	private String direction;
	private String stage;
	private SubjectType subjectType;
	
	public Subject() {}
	public Subject( String direction, String stage, SubjectType subjectType) {
		this.direction = direction;
		this.stage = stage;
		this.subjectType = subjectType;
	}

	
	
	
	
	
	
	
	









	//////////////////////////////////////////////////////////
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public SubjectType getSubjectType() {
		return subjectType;
	}
	public void setSubjectType(SubjectType subjectType) {
		this.subjectType = subjectType;
	}

	
	
	
}
