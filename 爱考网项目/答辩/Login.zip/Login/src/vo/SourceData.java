package vo;

public class SourceData {
	private int id;
	private Question question;
	private Source source;
	private String answer;//��
	private String result;//ԭ��
	public SourceData(Question question, Source source, String answer,
			String result) {
		super();
		this.question = question;
		this.source = source;
		this.answer = answer;
		this.result = result;
	}
	public SourceData(Question question, String answer,
			String result) {
		super();
		this.question = question;
		this.answer = answer;
		this.result = result;
	}
	public SourceData() {
	}
	
	
	
	
	
	
	
	
	
	
	

	///////////////////////////////////////
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public Source getSource() {
		return source;
	}
	public void setSource(Source source) {
		this.source = source;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	
}
