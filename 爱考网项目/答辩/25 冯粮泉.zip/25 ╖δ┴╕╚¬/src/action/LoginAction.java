package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Students;
import vo.Teacheres;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class LoginAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String selectM(){
		String Success=null;
		int userName=new Integer(ServletActionContext.getRequest().getParameter("userName"));
		String userPwd=ServletActionContext.getRequest().getParameter("userPwd");
		int quanxian= new Integer(ServletActionContext.getRequest().getParameter("userRole"));
		if (quanxian==1) {
			Session session=HibernateSessionFactory.getSession();
			Transaction transaction=session.beginTransaction();
			List<Students> studentList = new ArrayList<Students>();
			studentList=session.createQuery("from Students").list();
			for (Students students : studentList) {
				System.out.println(students.getStuedetId());
				System.out.println(userName);
				if (students.getStuedetId()==userName) {
					if (students.getMima().equals(userPwd)) {
						ServletActionContext.getRequest().getSession().setAttribute("userName", students.getStuName());
						ServletActionContext.getRequest().getSession().setAttribute("userSF",1);
						ServletActionContext.getRequest().getSession().setAttribute("userID",students.getId());
						return "selectM";
					}else {
						return "select";
					}
				}else {
					return "select";
				}
			
			}
			
			transaction.commit();
		}
		else if (quanxian==2) {
			Session session=HibernateSessionFactory.getSession();
			Transaction transaction=session.beginTransaction();
			List<Teacheres> teacheres = new ArrayList<Teacheres>();
			teacheres=session.createQuery("from Teacheres").list();
		
			for (Teacheres students : teacheres) {
				if (students.getZhanghao()==userName) {
					if (students.getMima().equals(userPwd)) {
						ServletActionContext.getRequest().getSession().setAttribute("userName", students.getTeacheName());
						ServletActionContext.getRequest().getSession().setAttribute("userSF",2);
						return "selectM";
					}else {
						return "select";
					}
				}else {
					return "select";
				}
			
			}
			
			transaction.commit();
		}
		else if(quanxian==3){
			System.out.println("管理员");
			ServletActionContext.getRequest().getSession().setAttribute("userSF",3);
			return "selectM";
		}
		return "select";
	}
}
