package vo;

import java.util.ArrayList;
import java.util.List;

/**
 * 题库表
 * @author gao
 *
 */
public class Questiones {
	private int id;
	private int fewQuest;
	private FangXiang fangXiang;
	private List<TestQusertion> testQusertionlist= new ArrayList<TestQusertion>();
	
	public List<TestQusertion> getTestQusertionlist() {
		return testQusertionlist;
	}
	public void setTestQusertionlist(List<TestQusertion> testQusertionlist) {
		this.testQusertionlist = testQusertionlist;
	}
	public FangXiang getFangXiang() {
		return fangXiang;
	}
	public void setFangXiang(FangXiang fangXiang) {
		this.fangXiang = fangXiang;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getFewQuest() {
		return fewQuest;
	}
	public void setFewQuest(int fewQuest) {
		this.fewQuest = fewQuest;
	}
	
 
}
