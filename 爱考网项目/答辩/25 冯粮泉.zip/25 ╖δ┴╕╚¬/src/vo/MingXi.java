package vo;

import java.util.HashSet;
import java.util.Set;

public class MingXi {
 public int id;
 public String uAnsWer;
 public Students students;
 public Set<TestQusertion> testQusertionList = new  HashSet<TestQusertion>();
 
public Students getStudents() {
	return students;
}
public void setStudents(Students students) {
	this.students = students;
}
public Set<TestQusertion> getTestQusertionList() {
	return testQusertionList;
}
public void setTestQusertionList(Set<TestQusertion> testQusertionList) {
	this.testQusertionList = testQusertionList;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getuAnsWer() {
	return uAnsWer;
}
public void setuAnsWer(String uAnsWer) {
	this.uAnsWer = uAnsWer;
} 
}
