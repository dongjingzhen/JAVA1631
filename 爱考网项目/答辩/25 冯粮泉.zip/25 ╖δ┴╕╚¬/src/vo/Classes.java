package vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
/**
 * 班级表
 * @author gao
 *
 */
public class Classes {
	private int id;
	private String className;
	private Date openTion;
	private List<Students> studentList = new ArrayList<Students>();
	private Teacheres teacheres;
	private Set<ThePapers> thePapersList = new HashSet<ThePapers>();
	
	public Set<ThePapers> getThePapersList() {
		return thePapersList;
	}
	public void setThePapersList(Set<ThePapers> thePapersList) {
		this.thePapersList = thePapersList;
	}
	public Teacheres getTeacheres() {
		return teacheres;
	}
	public void setTeacheres(Teacheres teacheres) {
		this.teacheres = teacheres;
	}
	public List<Students> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Students> studentList) {
		this.studentList = studentList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Date getOpenTion() {
		return openTion;
	}
	public void setOpenTion(Date openTion) {
		this.openTion = openTion;
	}
	
}
