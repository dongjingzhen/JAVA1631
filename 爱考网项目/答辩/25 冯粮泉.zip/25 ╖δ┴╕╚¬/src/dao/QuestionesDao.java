package dao;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;


import vo.Classes;
import vo.Questiones;
import vo.TestQusertion;

import vo.ThePapers;

public class QuestionesDao {
	public List<Classes> selectClassName(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		List<Classes> classesList= session.createQuery("from Classes").list();
		for (Classes classes : classesList) {
			System.out.println(classes.getClassName());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return classesList;
	}
	public void addPage_Class(ThePapers thePapers,String[] classesNa,Date date){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Classes classes = null;
	
		for (String classesNas : classesNa) {
			int id=Integer.parseInt(classesNas);
			classes=(Classes) session.get(Classes.class,id);
			thePapers =(ThePapers) session.get(ThePapers.class, thePapers.getId());
			System.out.println(date);
			thePapers.setDateTime(date);
			thePapers.setExaminState("准备考试");
			System.out.println(thePapers.getDateTime());
			session.save(thePapers);
			thePapers.getClassesList().add(classes);
		}
	
		transaction.commit();
	}
	
	public void addThePapers(TestQusertion testQusertion,ThePapers thePapers,String duoxuan,int danJdan,int danKnan,
			int duoJdan,int duoKnan){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String hQl=" select id from (select top "+danJdan+" id from dbo.t_TestQusertion where" +
				" difficuLty='简单' and diJiQi="+testQusertion.getDiJiQi()+" and keMu='"+testQusertion.getKeMu()+"' and " +
				" testType='"+testQusertion.getTestType()+"'  and  testTypeJOrB='"+testQusertion.getTestTypeJOrB()+"' order by newid()" +
				" union select top "+danKnan+" id from t_TestQusertion where" +
				" difficuLty='困难' and diJiQi="+testQusertion.getDiJiQi()+"  and keMu='"+testQusertion.getKeMu()+"' " +
				" and  testType='"+testQusertion.getTestType()+"' and testTypeJOrB='"+testQusertion.getTestTypeJOrB()+"' order by newid() " +
				"union select top "+duoJdan+" id from dbo.t_TestQusertion where" +
				" difficuLty='简单' and diJiQi="+testQusertion.getDiJiQi()+" and keMu='"+testQusertion.getKeMu()+"' and " +
				" testType='"+duoxuan+"'  and  testTypeJOrB='"+testQusertion.getTestTypeJOrB()+"' order by newid()" +
				" union select top "+duoKnan+" id from t_TestQusertion where" +
				" difficuLty='困难' and diJiQi="+testQusertion.getDiJiQi()+"  and keMu='"+testQusertion.getKeMu()+"' and " +
				"testType='"+duoxuan+"' and testTypeJOrB='"+testQusertion.getTestTypeJOrB()+"' order by newid())as t";
		List obj=session.createSQLQuery(hQl).list();
		for (Object object : obj) {
			int id=Integer.parseInt( object.toString());
			System.out.println(id);
			TestQusertion tempTestq=(TestQusertion) session.get(TestQusertion.class,id);
		
			thePapers.getThePaperQusertion().add(tempTestq);
		}
		thePapers.setPaperType("笔试");
		thePapers.setExaminState("未开考");
		thePapers.setKeMu(testQusertion.getKeMu());
		session.save(thePapers);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	public void deleteThePagers(int id){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String hql="from TestQusertion";
		ThePapers thePapers =(ThePapers)session.get(ThePapers.class,id);
		List<TestQusertion> testQusertion = session.createQuery(hql).list();
		for (TestQusertion testQusertion2 : testQusertion) {
			System.out.println(testQusertion2.getId());
			TestQusertion testQusertionq=(TestQusertion) session.get(TestQusertion.class,testQusertion2.getId());
			thePapers.getThePaperQusertion().remove(testQusertionq);
			
		}
		session.flush();
		session.delete(thePapers);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public List<ThePapers> selectThePapers(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String hql="from ThePapers";
		List<ThePapers> thePapersList=session.createQuery(hql).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return thePapersList;
	}
	public void addQuestion(TestQusertion testQusertion){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		TestQusertion tempTestQ = new TestQusertion();
		tempTestQ.setContent(testQusertion.getContent());
		tempTestQ.setKeMu(testQusertion.getKeMu());
		tempTestQ.setDiJiQi(testQusertion.getDiJiQi());
		tempTestQ.setTestType(testQusertion.getTestType());
		tempTestQ.setOptionA(testQusertion.getOptionA());
		tempTestQ.setOptionB(testQusertion.getOptionB());
		tempTestQ.setOptionC(testQusertion.getOptionC());
		tempTestQ.setOptionD(testQusertion.getOptionD());
		tempTestQ.setAnsWer(testQusertion.getAnsWer());
		tempTestQ.setDifficuLty(testQusertion.getDifficuLty());
		tempTestQ.setTestTypeJOrB(testQusertion.getTestTypeJOrB());
		tempTestQ.setChaPter(testQusertion.getChaPter());
		int id=0;
		String testHql="select q from Questiones q join q.fangXiang f  where q.fewQuest="+testQusertion.getDiJiQi()+" and f.fangName='"+testQusertion.getKeMu()+"'";
		List<Questiones> QuestionesList= session.createQuery(testHql).list();
		for (Questiones questiones : QuestionesList) {
			id=questiones.getId();
		}
		Questiones questiones = (Questiones) session.get(Questiones.class, id);
//		tempTestQ.getQuestiones().getId();
		tempTestQ.setQuestiones(questiones);
		session.save(tempTestQ);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public void testQ(TestQusertion testQusertion){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		int id =new Integer(ServletActionContext.getRequest().getParameter("cmd"));
		TestQusertion temTestQuers=(TestQusertion)session.get(TestQusertion.class, id);
		temTestQuers.setTestType(testQusertion.getTestType());
		temTestQuers.setContent(testQusertion.getContent());
		temTestQuers.setOptionA(testQusertion.getOptionA());
		temTestQuers.setOptionB(testQusertion.getOptionB());
		temTestQuers.setOptionC(testQusertion.getOptionC());
		temTestQuers.setOptionD(testQusertion.getOptionD());
		temTestQuers.setAnsWer(testQusertion.getAnsWer());
		temTestQuers.setDifficuLty(testQusertion.getDifficuLty());
		temTestQuers.setChaPter(testQusertion.getChaPter());
		session.update(temTestQuers);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public List<Object[]> QuestionesCount(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String hql="select t.keMu,c.fewQuest,t.testTypeJOrB, count(t) from TestQusertion t join t.questiones c group by t.keMu,c.fewQuest,t.testTypeJOrB";
		List<Object[]> liset=session.createQuery(hql).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return liset;
	}
	public List<TestQusertion> testQuset(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String keMu=ServletActionContext.getRequest().getParameter("keMu");
		String diJiQi= ServletActionContext.getRequest().getParameter("diJiQi");
		System.out.println(diJiQi);
		List<TestQusertion> testQuestionesList = new ArrayList<TestQusertion>();
		testQuestionesList=session.createQuery("from TestQusertion t where keMu='"+keMu+"' and diJiQi="+diJiQi+"  ").list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return testQuestionesList;
		}
	public TestQusertion modifySeleQuser(){
		int cmd= new Integer(ServletActionContext.getRequest().getParameter("id"));
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		TestQusertion testQusertion = (TestQusertion)session.get(TestQusertion.class, cmd);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return testQusertion;
	}




	
}
