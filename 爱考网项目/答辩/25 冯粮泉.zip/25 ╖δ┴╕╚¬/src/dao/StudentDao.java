package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Achievement;
import vo.Classes;
import vo.MingXi;
import vo.Questiones;
import vo.Students;
import vo.TestQusertion;
import vo.ThePapers;

public class StudentDao {
	
	public List<Object[]> selectMingXi(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String Hql="select m.uAnsWer, t.content,t.ansWer from MingXi m join m.testQusertionList t ";
		List<Object[]> mingxiList=session.createQuery(Hql).list();
		for (Object[] objects : mingxiList) {
			System.out.println(objects[2]);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return mingxiList;
	}
	
	public List<Achievement> selectFens(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		int id =Integer.parseInt( ServletActionContext.getRequest().getSession().getAttribute("userID").toString());
		
		String Hql="select a from Achievement a join a.studentsList s where s.id="+id+"";
		List<Achievement>  achievement =session.createQuery(Hql).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return achievement;
	}
	
	
	public int tiJiao(){
		int count=0;
		Map<Object,Object> mapList=new HashMap<Object,Object>();
		mapList=(Map<Object, Object>) ServletActionContext.getRequest().getSession().getAttribute("mapList");
		int userId=new Integer( ServletActionContext.getRequest().getSession().getAttribute("userID").toString());
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		int i=1;
		for (Map.Entry<Object,Object> e : mapList.entrySet()) {
			Students students= (Students) session.get(Students.class, userId);
			System.out.println(ServletActionContext.getRequest().getParameter("radioValues"+e.getKey()+""));
			String xuanX=ServletActionContext.getRequest().getParameter("radioValues"+e.getKey()+"");
			if (xuanX==null) {
				xuanX="　";
			}
			MingXi ming=new MingXi();
			ming.setuAnsWer(xuanX);
			ming.setStudents(students);
			session.save(ming);
			TestQusertion s =(TestQusertion) e.getValue();
			ming.getTestQusertionList().add(s);
			
		
			String daAn=s.getAnsWer();
			System.out.println(daAn);
			if (xuanX.equals(daAn)) {
				count=count+1;
				System.out.println(count);
			}
			
		}
		transaction.commit();
		return count;
	}
	
	public void fenShu(int countTiao){
		int userId=new Integer( ServletActionContext.getRequest().getSession().getAttribute("userID").toString());
		double danTfen=0;
		double countFen=0;
		int nameId=new Integer( ServletActionContext.getRequest().getAttribute("nameId").toString());
		List <ThePapers> thePapersList = selectClass(1,nameId);
		for (ThePapers thePapers2 : thePapersList) {
			danTfen=thePapers2.getCcorePer();
		}
		countFen=danTfen*countTiao;
		System.out.println(countFen);
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Students students =(Students) session.get(Students.class, userId);
		Achievement achievemen =new Achievement();
		achievemen.setAchievement(countFen);
		achievemen.getStudentsList().add(students);
		session.save(achievemen);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public List<TestQusertion>  startExamination(int id){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String Hql="select q from ThePapers t join t.thePaperQusertion q where t.id="+id+"";
		List <TestQusertion> thePapersList=session.createQuery(Hql).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return thePapersList;
	}
	public List<ThePapers> selectClass(int id,int sJid){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Students students=(Students) session.get(Students.class, id);
		int classId=students.getClasses().getId();
		
		String classesName=students.getClasses().getClassName();
		ServletActionContext.getRequest().getSession().setAttribute("classesName",classesName);
		Classes classes =(Classes) session.get(Classes.class, classId);
		String Hql="select s from Classes c join c.thePapersList s where c.id="+classId+"";
		if (sJid!=0) {
			Hql+=" and s.id="+sJid+"";
		}
		List <ThePapers> thePapersList=session.createQuery(Hql).list();
		transaction.commit();
		return thePapersList;
	}
	public List<Students> selectStudent(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		List<Students> studentList = new ArrayList<Students>();
		studentList=session.createQuery("from Students").list();
		
		transaction.commit();
		return studentList;
	}
}
