package tools;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;  
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.cfg.Configuration;  
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.Order;
import org.hibernate.hql.ast.tree.OrderByClause;
  
public final class HibernateUtils {  
	public final static  String ORDER_SORT = "orderSort";
	public final static  String ORDER_NAME = "orderName";
    private static SessionFactory factory;  
  
    public static Session getSession() {  
        return factory.openSession();  
    }  
  
    private HibernateUtils() { // ����ģʽ  
    }  
  
    static { // ���������ʱִ��һ��  
        // configureĬ�ϼ���hibernate.cfg.xml  
        // �������hibernate.cfg.xml����ָ���������֣����ļ���classpath����  
        Configuration config = new Configuration().configure();  
        factory = config.buildSessionFactory();  
    }  
  
    public static void add(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
            session.save(obj);  
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static void update(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
            session.update(obj);  
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static void delete(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
            session.delete(obj);  
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static Object get(Class clazz, Serializable id) {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession();  
            Object obj = session.get(clazz, id);  
            return obj;  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
    
    
    @SuppressWarnings("unchecked")
	public static List<Object> list(Class clazz,Map filterMap,Map orderMap,int firstNo,int  maxNo ) {  
        Session session = null;  
        try {  
        	List<Object> list = new ArrayList<Object>();
            session = HibernateUtils.getSession(); 
            Criteria criteria =session.createCriteria(clazz);
            Map temp =null;
           
			if(filterMap!=null)
			{
				 for(int i=0;i<filterMap.size();i++)
		            {
					 	Iterator iteratorFilter = filterMap.keySet().iterator();
					 	while(iteratorFilter.hasNext())
					 	{
					 		Object key = iteratorFilter.next();
					 		Criterion criterion = Expression.like(key.toString(),filterMap.get(key) );
					 		criteria.add(criterion);
					 	}
		            	
		            	
		            }
		      
			}
			if(orderMap!=null)
			{
				String orderSort =(String) orderMap.get(ORDER_SORT);
				String orderName = (String) orderMap.get(ORDER_NAME);
				
				if(orderSort.equals("desc"))
				{
					criteria.addOrder(Order.desc(orderName));
				}
				else
				{
					criteria.addOrder(Order.asc(orderName));
				}
			}
			
			criteria.setFirstResult(firstNo).setMaxResults(maxNo);
			
			list=criteria.list();
            return   list;
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
  
}  