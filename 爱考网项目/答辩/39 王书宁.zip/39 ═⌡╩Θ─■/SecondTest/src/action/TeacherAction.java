package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Student;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.loginDao;
import dao.teacherDao;

public class TeacherAction implements Action{
	private teacherDao tdao = new teacherDao();
	private List<Teacher> teachers = new ArrayList<Teacher>();
	public List<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(List<Teacher> teachers) {
		this.teachers = teachers;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String allTeacher(){
		
		teachers = tdao.allteacher();
		return "next";
	}
}
