package dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import org.hibernate.Session;

import po.Paper;
import po.Question;
import po.Scoredetails;

import tools.HibernateSessionFactory;

public class AreDao {
	//����
  public  Integer questions( Integer questionIndex,Integer questionReadyIndex,int pid,Question question,Paper paper){	  
	  Session session =HibernateSessionFactory.getSession();
	  session.beginTransaction();
	  HttpSession httpSession = ServletActionContext.getRequest().getSession();
	  Map questionMap = (Map) httpSession.getAttribute("questionMap");   
	  if (questionMap == null) {
	paper =(Paper) session.get(Paper.class, pid);
	questionMap= new HashMap();
	Set<Question> questionSet = null;
	questionSet = paper.getQuestionset();
	Integer i = 1;
	for (Question question1 : questionSet) {

		questionMap.put(i, question1);
		i++;

	}
	httpSession.setAttribute("questionMap", questionMap);
	} else {
		if(question!= null)
		{	
		
			 questionMap.put(questionIndex, question);
			 questionIndex =questionReadyIndex;
				
		}
	}
	Question  question2=   (Question) questionMap.get(questionReadyIndex);
	  System.out.println(question2);
	  session.beginTransaction().commit();
	  session.close();
	return questionIndex;
	
  }
  //�����Ծ�id���Ծ�
  public  Paper papers(int pid){
	    Session session =HibernateSessionFactory.getSession();
	    session.beginTransaction();	  
	    Paper paperlist = (Paper) session.get(Paper.class, pid);
	    session.beginTransaction().commit();	
	    session.close();
	  return paperlist;
  }
  
  //�ɼ���ϸ
  public List<Scoredetails> scoredetails(){
	    Session session =HibernateSessionFactory.getSession();
	    session.beginTransaction();	 
		  HttpSession httpSession = ServletActionContext.getRequest().getSession();
		  Map questionMap = (Map) httpSession.getAttribute("questionMap"); 
	     Collection<String> collection= questionMap.values();
        System.out.println(collection);
	    
	    session.beginTransaction().commit();	
	    session.close();
	  return null;
  }

}
