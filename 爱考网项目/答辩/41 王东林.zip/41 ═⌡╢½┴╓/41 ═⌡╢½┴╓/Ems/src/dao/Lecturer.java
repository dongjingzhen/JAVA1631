package dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;

import po.Teacher;
import tools.HibernateSessionFactory;

public class Lecturer {
	//��ѯ
    public List<Teacher> teachers(){
    Session session =HibernateSessionFactory.getSession();
    session.beginTransaction();
    String hql="select t from Teacher t ";
    Query querylist = session.createQuery(hql);
    List<Teacher> lecturerlist=querylist.list();
    session.beginTransaction().commit();
    session.close();
    	return lecturerlist;
    }
    //ɾ��
    public void delect(int id){
        Session session =HibernateSessionFactory.getSession();
        session.beginTransaction();
       Teacher teacher = (Teacher) session.get(Teacher.class, id); 
        session.delete(teacher);
        session.beginTransaction().commit();
        session.close();
    }
    //����
    public void inio(Teacher teacher){
        Session session =HibernateSessionFactory.getSession();
        session.beginTransaction();
        session.save(teacher);
        session.beginTransaction().commit();
        session.close();
    }
    //�޸�
    public void update(int id){
        Session session =HibernateSessionFactory.getSession();
        session.beginTransaction();
      Teacher teacher1 =  (Teacher) session.get(Teacher.class, id);
        session.update(teacher1);
        session.beginTransaction().commit();
        session.close();
    }
}
