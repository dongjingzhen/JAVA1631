package po;

import java.sql.Timestamp;

/**
 * Score entity. @author MyEclipse Persistence Tools
 */

public class Score implements java.io.Serializable {
   //�ɼ���
	// Fields

	private Integer id;
	private Integer classId;//�༶���ID
	private Integer stuId;//ѧ��ID
	private Integer subjectId;//��ĿID
	private Integer paperId;//�Ծ�ID
	private Timestamp beginTime;//��ʼʱ��
	private Timestamp endTime;//����ʱ��
	private Double score;//�ɼ�

	// Constructors

	/** default constructor */
	public Score() {
	}

	/** full constructor */
	public Score(Integer classId, Integer stuId, Integer subjectId,
			Integer paperId, Timestamp beginTime, Timestamp endTime,
			Double score) {
		this.classId = classId;
		this.stuId = stuId;
		this.subjectId = subjectId;
		this.paperId = paperId;
		this.beginTime = beginTime;
		this.endTime = endTime;
		this.score = score;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getClassId() {
		return this.classId;
	}

	public void setClassId(Integer classId) {
		this.classId = classId;
	}

	public Integer getStuId() {
		return this.stuId;
	}

	public void setStuId(Integer stuId) {
		this.stuId = stuId;
	}

	public Integer getSubjectId() {
		return this.subjectId;
	}

	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}

	public Integer getPaperId() {
		return this.paperId;
	}

	public void setPaperId(Integer paperId) {
		this.paperId = paperId;
	}

	public Timestamp getBeginTime() {
		return this.beginTime;
	}

	public void setBeginTime(Timestamp beginTime) {
		this.beginTime = beginTime;
	}

	public Timestamp getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public Double getScore() {
		return this.score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

}