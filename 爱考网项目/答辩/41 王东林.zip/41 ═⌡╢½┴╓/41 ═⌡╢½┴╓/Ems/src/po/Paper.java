package po;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Paper implements java.io.Serializable {
   //�Ծ���
	// Fields

	private Integer pid; //
	private String subjectName; //��Ŀ
	private String kind; //��𣨻����ԣ�
	private String title; //����
	private String className; //���԰༶
	private Timestamp testTime; //����ʱ��
	private Integer testHour; //����ʱ��
	private Double totalScore; //�ܷ�
	private Integer qnumber; //��Ŀ����
	private String state; //״̬
    private Set<Question> questionset =new  HashSet<Question>();//����Ŀ�Ķ�Զ�
    private Set<Student> studentset = new HashSet<Student>();//��ѧ���Ķ�Զ�
	// Constructors

	/** default constructor */
	public Paper() {
	}

	/** full constructor */
	public Paper(String subjectName, String kind, String title,
			String className, Timestamp testTime, Integer testHour,
			Double totalScore, Integer qnumber, String state) {
		this.subjectName = subjectName;
		this.kind = kind;
		this.title = title;
		this.className = className;
		this.testTime = testTime;
		this.testHour = testHour;
		this.totalScore = totalScore;
		this.qnumber = qnumber;
		this.state = state;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getSubjectName() {
		return this.subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getKind() {
		return this.kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getClassName() {
		return this.className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Timestamp getTestTime() {
		return this.testTime;
	}

	public void setTestTime(Timestamp testTime) {
		this.testTime = testTime;
	}

	public Integer getTestHour() {
		return this.testHour;
	}

	public void setTestHour(Integer testHour) {
		this.testHour = testHour;
	}

	public Double getTotalScore() {
		return this.totalScore;
	}

	public void setTotalScore(Double totalScore) {
		this.totalScore = totalScore;
	}

	public Integer getQnumber() {
		return this.qnumber;
	}

	public void setQnumber(Integer qnumber) {
		this.qnumber = qnumber;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Set<Question> getQuestionset() {
		return questionset;
	}

	public void setQuestionset(Set<Question> questionset) {
		this.questionset = questionset;
	}

	public Set<Student> getStudentset() {
		return studentset;
	}

	public void setStudentset(Set<Student> studentset) {
		this.studentset = studentset;
	}

}