package po;

/**
 * Scoredetails entity. @author MyEclipse Persistence Tools
 */

public class Scoredetails implements java.io.Serializable {
  //�ɼ���ϸ��
	// Fields

	private Integer id;
	private Integer scoreId;//�ɼ�ID	
	private Integer questionId;//��ĿID
	private String answer;//�𰸣����⣩
	private String result;//�Դ���1�ԣ�0����

	// Constructors

	/** default constructor */
	public Scoredetails() {
	}

	/** full constructor */
	public Scoredetails(Integer scoreId, Integer questionId, String answer,
			String result) {
		this.scoreId = scoreId;
		this.questionId = questionId;
		this.answer = answer;
		this.result = result;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getScoreId() {
		return this.scoreId;
	}

	public void setScoreId(Integer scoreId) {
		this.scoreId = scoreId;
	}

	public Integer getQuestionId() {
		return this.questionId;
	}

	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getResult() {
		return this.result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}