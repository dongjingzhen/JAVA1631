package action;

import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import po.Class;
import po.Paper;
import po.Question;
import po.Random;
import po.Student;
import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.sun.org.apache.regexp.internal.recompile;

import dao.PaperDao;

public class PaperAction implements Action {
    private List<Paper> paperlist;//�Ծ��б�
	private Paper paper;//�Ծ�����
    private Random random;//���
    private int tid;//����ǰ̨��id
    private Set<Question>  testquestion;//�Ծ���Ŀ�б�
    private List<Class> classlist;//�༶�б�
    public String random(){
    	//���ѡ�Ᵽ��
	Session session = HibernateSessionFactory.getSession();		
		Transaction transaction=session.beginTransaction();
		String sql  ="select q.* from (select top "+random.getDa()+" * from question where difficulty= '��' and kind='��ѡ'  order by newId() union select top "+random.getDb()+" * from question where difficulty= 'һ��' and kind=' ��ѡ' order by newId() union select top "+random.getDc()+" * from question where difficulty= '����' and kind=' ��ѡ' order by newId() union select top "+random.getDda()+" * from question where difficulty= '��' and kind='��ѡ' order by newId() union select top "+random.getDdb()+" * from question where difficulty= 'һ��' and kind='��ѡ' order by newId() union select top "+random.getDdc()+" * from question where difficulty= '����' and kind='��ѡ' order by newId()) as q";
		List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();
		for (Question question : questionList) {
			paper.getQuestionset().add(question);
		}
	    System.out.println("�ҵ���Ŀ��:"+questionList.size());
	    paper.setState("δ����");
		session.save(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
    	return "random";
    }
    //��ҳ��ѯ
	public String inio(){
		PaperDao dao = new PaperDao();
		paperlist =dao.pList();
		return "inio";
	}
	//�鿴�Ծ�
	public String testpaper(){
		   Session session =HibernateSessionFactory.getSession();
		   session.beginTransaction();
		   paper=(Paper) session.get(Paper.class, tid);
		   testquestion= paper.getQuestionset();
		
           session.beginTransaction().commit();
           session.close();
		return "testpaper";
	}
	//���ÿ���
	public String startpaper(){
		Session session =HibernateSessionFactory.getSession();
		   session.beginTransaction();
		   paper=(Paper) session.get(Paper.class, tid);
		   //�õ��༶�б�
		   classlist=session.createCriteria(Class.class).list();
		   session.beginTransaction().commit();
           session.close();
	return "startpaper";
	}
	//��ʼ����
	public String updatePaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		//����ѡ��İ༶���ƣ���ѯ�༶����ע�����༶��Ҫ�ָ�
	     String  className=	paper.getClassName();
	     
	   //�õ����ݿ�����Ӷ��󣬸��¾��ӵĿ��԰༶�Լ�����ʱ��,����״̬
	    Paper paperDB =(Paper)session.get(Paper.class, paper.getPid());
	    paperDB.setClassName(className);
	    paperDB.setTestTime(paper.getTestTime());
	    paperDB.setState(paper.getState());
	    
	    String hql="select c from Class c where c.className = :className";
		//�жϾ���ѡ���Ƕ���༶����
	    if (className.contains(",")) {
			String classnames[] = className.split(","); 
			for (int i=0;i<classnames.length;i++) {
				String classNameTmep = classnames[i];
				this.setPaperStudents(classNameTmep.trim(), hql, session, paperDB);
			}
			//�����༶����
		} else {
                this.setPaperStudents(className, hql, session, paperDB);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "updatePaper";
	}
	//�õ��༶���󣬵õ��༶������һ�Զ�ѧ������ 
	public void setPaperStudents(String className,String hql,Session session,Paper paperDB){
		Class classes =(Class) session.createQuery(hql).setParameter("className", className).uniqueResult();
		Set<Student> studentSet = classes.getStudentset();
		for (Student student : studentSet) {
		  paperDB.getStudentset().add(student);
		}
		session.update(paperDB);
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public Random getRandom() {
		return random;
	}
	public void setRandom(Random random) {
		this.random = random;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public Set<Question> getTestquestion() {
		return testquestion;
	}
	public void setTestquestion(Set<Question> testquestion) {
		this.testquestion = testquestion;
	}
	public List<Class> getClasslist() {
		return classlist;
	}
	public void setClasslist(List<Class> classlist) {
		this.classlist = classlist;
	}
	

}
