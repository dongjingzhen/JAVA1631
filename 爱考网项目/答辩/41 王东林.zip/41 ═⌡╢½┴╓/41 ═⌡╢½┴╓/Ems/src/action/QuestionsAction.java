package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;

import po.Question;
import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;

import dao.QuestionsDao;

public class QuestionsAction implements Action {
     private List<Question> questionlist;
	 private Question question;
	 private List<Object[]>	qlist;
	public String  save(){
	    Session session =HibernateSessionFactory.getSession();
	    session.beginTransaction();
        session.save(question);
	    session.beginTransaction().commit();
	    session.close();
		return "save";
	}
	public String inioa(){
		QuestionsDao question = new QuestionsDao();
		qlist=question.questionlista();


		return "inioa";
	}
	public String inio(){		
		QuestionsDao question = new QuestionsDao();
	 	questionlist =question.questionlist();
 	 
 	 
		return "inio";
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Question> getQuestionlist() {
		return questionlist;
	}
	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public List<Object[]> getQlist() {
		return qlist;
	}
	public void setQlist(List<Object[]> qlist) {
		this.qlist = qlist;
	}

	

}
