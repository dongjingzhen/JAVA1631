package action;

import java.util.List;

import javax.ejb.SessionContext;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;

import po.Admin;
import po.Student;
import po.User;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;

public class CheckAction implements Action {
    private User user;
    private Admin admin;
    private String role;
	//��֤
	public String check(){
	 Session session =	HibernateSessionFactory.getSession();
	 session.beginTransaction();
	 String r = "";
	 ServletActionContext.getRequest().getSession().setAttribute("username", user.getName());
	 //����ԱȨ��
	 if ("admin".equals(role)) {
		 String hql  = "select a from Admin a where a.aname='"+user.getName()+"' and a.apwd="+user.getPwd()+" ";
		 Query admins= session.createQuery(hql);
		 
		 if (admins.list().size() !=0) {			
			r = "check"; 
		}else{
			r="shib";
		}
		 
	} 
	 //ѧ��Ȩ��
	 if ("student".equals(role)) {
		 String hql  = "select a from Student a where a.stuNo='"+user.getName()+"' and a.stuPwd="+user.getPwd()+" ";
		 Query admins= session.createQuery(hql);
		 if (admins.list().size() !=0) {
		  List<Student> sutlist =	 admins.list();
			 for (Student student : sutlist) {
		ServletActionContext.getRequest().getSession().setAttribute("className", student.getClassid().getClassName());

			}
			r = "check"; 
		}else{
			r="shib";
		}
		 
	} 
	 //��ʦȨ��
	 if ("lecturer".equals(role)) {
		 String hql  = "select a from Teacher a where a.taccount='"+user.getName()+"' and a.tpwd="+user.getPwd()+" ";
		 Query admins= session.createQuery(hql);		
		 if (admins.list().size() !=0) {
			r = "check"; 
		}else{
			r="shib";
		}
		 
	} 
	 session.beginTransaction().commit();
	 session.close();
		return r;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

}
