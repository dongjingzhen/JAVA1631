package action;

import java.util.List;

import po.Teacher;

import com.opensymphony.xwork2.Action;
import com.sun.org.apache.regexp.internal.recompile;

import dao.Lecturer;

public class LecturerListAction implements Action {
    private List<Teacher> teachers;
	private Teacher teacher;
	private int id;	
	//��ѯ
	public String lecturer(){
		Lecturer lecturer = new Lecturer();
		teachers=lecturer.teachers();
		return "lecturer";
	}
	//ɾ��
	public String delect(){
		Lecturer lecturer = new Lecturer();
		lecturer.delect(id);
		return "delect";
	}
	//����
	public String inio(){
		Lecturer lecturer = new Lecturer();
		lecturer.inio(teacher);
		return "inio";
	}
	//�޸�
	public String update(){
		Lecturer lecturer = new Lecturer();
		lecturer.update(id);
		return "update";
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(List<Teacher> teachers) {
		this.teachers = teachers;
	}
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}
