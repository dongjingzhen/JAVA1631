package action;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;

import po.Paper;
import po.Question;
import po.Student;
import sun.net.www.content.text.plain;
import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.sun.org.apache.regexp.internal.recompile;

import dao.AreDao;
import dao.PaperDao;


public class StudentExam implements Action {
	   private List<Paper> paperlist;//�Ծ��б�
	   private Student student; //ѧ������
	   private Paper paper;//�Ծ�����
	   private int pid;
	   private int qid;
	   private List<Question> questionlist;//һ����Ķ���
	   private Integer questionIndex;//���
	   private Integer questionReadyIndex;//׼�����
	   private Question question;//�����
	//�鿴�Ծ�
	public String ioin(){
 	    Session session =HibernateSessionFactory.getSession();
	    session.beginTransaction();
	    String className= (String) ServletActionContext.getRequest().getSession().getAttribute("className");
	    System.out.println(className);
	    String sql ="select * from paper where className='"+className+"' and state='׼������' or state='������'";
	    Query query =  session.createSQLQuery(sql).addEntity(Paper.class);
	    paperlist= query.list();
	  
	    session.beginTransaction().commit();
	    session.close();
		return "ioin";
	}
	//�Ѿ���ʼ�����ˣ����Ծ�����Ϣ�ŵ��Ծ���
	public String are(){	
		AreDao areDao = new AreDao();
		paper = areDao.papers(pid);	
		questionIndex= areDao.questions(questionIndex, questionReadyIndex, pid,question,paper);
		return "are";
	}
 //�ɼ���ϸ
	public String details(){
		AreDao areDao = new AreDao();
		areDao.scoredetails();
		return "details";
	}
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	public List<Paper> getPaperlist() {
		return paperlist;
	}


	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}


	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	public Paper getPaper() {
		return paper;
	}


	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}

	public List<Question> getQuestionlist() {
		return questionlist;
	}
	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public Integer getQuestionIndex() {
		return questionIndex;
	}
	public void setQuestionIndex(Integer questionIndex) {
		this.questionIndex = questionIndex;
	}
	public Integer getQuestionReadyIndex() {
		return questionReadyIndex;
	}
	public void setQuestionReadyIndex(Integer questionReadyIndex) {
		this.questionReadyIndex = questionReadyIndex;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}




}
