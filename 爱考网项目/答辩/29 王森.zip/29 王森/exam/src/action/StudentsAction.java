package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Student;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class StudentsAction implements Action {
	
	private List<Student> studentlist = new ArrayList<Student>();
	private Users user = new Users();
	private int id;
	private Student student;
	
	
	public Student getStudent() {
		return student;
	}




	public void setStudent(Student student) {
		this.student = student;
	}




	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}




	public List<Student> getStudentlist() {
		return studentlist;
	}




	public void setStudentlist(List<Student> studentlist) {
		this.studentlist = studentlist;
	}




	public Users getUser() {
		return user;
	}




	public void setUser(Users user) {
		this.user = user;
	}




	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//��ʾ������Ϣ
	public String info(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		id = (Integer)ServletActionContext.getRequest().getSession().getAttribute("id");
		student =  (Student) session.get(Student.class, id);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "info";
		
	}
	//��ʾ�޸�����ҳ��
	public String showUpdatePwd(){
		return "showUpdatePwd";
		
	}
	//�޸�����
	public String updatePwdOK(){
		
		return "updatePwdOK";
		
	}

}
