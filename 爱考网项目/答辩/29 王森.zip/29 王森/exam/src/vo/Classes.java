package vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Classes {
	
	private int id;
	
	private String classNo;
	
	private String className;
	
	private String direction;
	
	private String headteacher;
	
	private String lecturer;
	
	private Date date;
	
	private String state;
	
	private Set<Student> students = new HashSet<Student>();
	
	private Set<Score> scoreSet = new HashSet<Score>();
	
	
	
	public Set<Score> getScoreSet() {
		return scoreSet;
	}

	public void setScoreSet(Set<Score> scoreSet) {
		this.scoreSet = scoreSet;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	@Override
	public String toString() {
		return "Classes [className=" + className + ", classNo=" + classNo
				+ ", date=" + date + ", direction=" + direction
				+ ", headteacher=" + headteacher + ", id=" + id + ", lecturer="
				+ lecturer + ", state=" + state + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getHeadteacher() {
		return headteacher;
	}

	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}

	public String getLecturer() {
		return lecturer;
	}

	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	

}
