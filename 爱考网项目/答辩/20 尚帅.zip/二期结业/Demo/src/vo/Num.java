package vo;

public class Num {
	
	private int danj;
	private int dany;
	private int dank;
	private int duoj;
	private int duoy;
	private int duok;
	public int getDanj() {
		return danj;
	}
	public void setDanj(int danj) {
		this.danj = danj;
	}
	public int getDany() {
		return dany;
	}
	public void setDany(int dany) {
		this.dany = dany;
	}
	public int getDank() {
		return dank;
	}
	public void setDank(int dank) {
		this.dank = dank;
	}
	public int getDuoj() {
		return duoj;
	}
	public void setDuoj(int duoj) {
		this.duoj = duoj;
	}
	public int getDuoy() {
		return duoy;
	}
	public void setDuoy(int duoy) {
		this.duoy = duoy;
	}
	public int getDuok() {
		return duok;
	}
	public void setDuok(int duok) {
		this.duok = duok;
	}
	
}
