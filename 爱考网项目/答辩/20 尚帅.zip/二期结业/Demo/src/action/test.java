package action;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Admin;
import vo.Classes;
import vo.Paper;
import vo.Question;
import vo.Student;
import vo.Teacher;
import dao.HibernateSessionFactory;

public class test {
	public static void main(String[] args) {
		Map ss = new HashMap();
		ss.put(1, 'a');
		ss.put(2, 'b');
		ss.put(3, 'c');
		ss.put(4, 'd');
		
		for (int i = 0; i < ss.size(); i++) {
			System.out.println(ss.get(i+1));
		}
	}

}
