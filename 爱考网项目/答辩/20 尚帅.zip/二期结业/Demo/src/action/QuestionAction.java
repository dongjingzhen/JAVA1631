package action;

import java.util.ArrayList;
import java.util.List;

import tools.HibernateUtils;
import vo.Question;
import vo.Subject;

import com.opensymphony.xwork2.Action;

import dao.QuestionDao;

public class QuestionAction implements Action {
	private Question question;
	//�洢ѡ��
	private String[] ss = {"A","B","C","D"};
	private String[] nan = {"��","�е�","����"};
	public String[] getNan() {
		return nan;
	}
	public void setNan(String[] nan) {
		this.nan = nan;
	}
	public String[] getSs() {
		return ss;
	}
	public void setSs(String[] ss) {
		this.ss = ss;
	}
	
	private List<Question> questions = new ArrayList<Question>();
	public QuestionDao getQdao() {
		return qdao;
	}
	public void setQdao(QuestionDao qdao) {
		this.qdao = qdao;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	private List<Subject> subject = new ArrayList<Subject>();
	private QuestionDao qdao = new QuestionDao();
	public List<Subject> getSubject() {
		return subject;
	}
	public void setSubject(List<Subject> subject) {
		this.subject = subject;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String allSubject(){
		subject = qdao.allsubject();
		return "next";
		
	}
	public String showAddQuestion(){
		return "next";
		
	}
	public String selectQuestion(){
		questions = qdao.SubjectQuestion(question);
		System.out.println(question.getKind());
		return "next";
	}
	public String addQuestion(){
		HibernateUtils.add(question);
		return "next";
	}
	public String deleteQuestion(){
		question = (Question) HibernateUtils.get(Question.class, question.getQid());
		HibernateUtils.delete(question);
		return "next";
	}
	public String showQuestion(){
		question = (Question) HibernateUtils.get(Question.class, question.getQid());
		System.out.println(question.getAnswer());
		System.out.println(question.getAnswer().trim());
		question.setAnswer(question.getAnswer().trim());
		return "next";
	}
	public String UpdateQuestion(){
		
		HibernateUtils.update(question);
		return "next";
	}
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
}
