package action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import vo.Paper;
import vo.Score;
import vo.Scoredetails;
import vo.Student;
import vo.Subject;

import com.opensymphony.xwork2.Action;

import dao.ScoreDao;

public class ScoreAction implements Action {
	private ScoreDao dao = new ScoreDao();
	private String test;
	public String getTest() {
		return test;
	}
	public void setTest(String test) {
		this.test = test;
	}
	private List<Scoredetails> scoredetailss = new ArrayList<Scoredetails>();
	public List<Scoredetails> getScoredetailss() {
		return scoredetailss;
	}
	public void setScoredetailss(List<Scoredetails> scoredetailss) {
		this.scoredetailss = scoredetailss;
	}
	private Scoredetails scoredetail = new Scoredetails(); ;
	public Scoredetails getScoredetail() {
		return scoredetail;
	}
	public void setScoredetail(Scoredetails scoredetail) {
		this.scoredetail = scoredetail;
	}
	private int end;
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	private Paper paper;
	private Subject subject;
	private Score score;
	private Student student;
	private int index;
	private int sindex;
	public int getSindex() {
		return sindex;
	}
	public void setSindex(int sindex) {
		this.sindex = sindex;
	}
	private long endTime;
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	
	public long getEndTime() {
		return endTime;
	}
	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public Score getScore() {
		return score;
	}
	public void setScore(Score score) {
		this.score = score;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String paperQuestion(){
		score = dao.addscore(student, paper);
		endTime = score.getEndTime().getTime();
		scoredetailss = dao.allquestions(score);
		Map questionMap =new HashMap();
		HttpSession httpSession = ServletActionContext.getRequest()
		.getSession();
		Integer i = 1;
		for (Scoredetails ss : scoredetailss) {
			questionMap.put(i, ss);
			i++;

		}
		httpSession.setAttribute("questionMap", questionMap);
		index=1;
		return "next";
	}
	public String pageQuestion(){
		HttpSession httpSession = ServletActionContext.getRequest()
		.getSession();
		Map questionMap =new HashMap();
		questionMap = (Map) httpSession.getAttribute("questionMap");
		Scoredetails s = (Scoredetails) questionMap.get(index);
		if (scoredetail.getAnswer()==null) {
			
		}else {
			System.out.println(s.getAnswer());
			s.setAnswer(scoredetail.getAnswer());
		}
		
		questionMap.put(index, s);
		index = sindex;
		if (test.equals("�ύ")) {
			dao.tijiao(questionMap,score);
			return "ret";
		}
		return "next";
	}
	public String ScoreQuestion(){
		score = dao.getscore(score);
		return "next";
	}
	
}
