package dao;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Admin;
import vo.Student;
import vo.Teacher;
import vo.Users;

public class loginDao {
		public String login(Users user){
			String message = "loginnot";
			Session session=HibernateSessionFactory.getSession();
			Transaction transaction = session.beginTransaction();
			if (user.getRole()==1) {
				String hql = "from Student where stuNo='"+user.getUserNo()+"' and stuPwd='"+user.getPwd()+"'";
				List<Student> student = session.createQuery(hql).list();
				if (student.size()==0) {
					user=null;
					message = "loginnot";
				}else {
					user.setName(student.get(0).getStuName());
					ServletActionContext.getRequest().getSession().setAttribute("loginUser", user);
					message = "loginok";
				}
			}else if (user.getRole()==2) {
				String hql = "from Teacher where taccount='"+user.getUserNo()+"' and tpwd='"+user.getPwd()+"'";
				List<Teacher> student = session.createQuery(hql).list();
				if (student.size()==0) {
					user=null;
					message = "loginnot";
				}else {
					user.setName(student.get(0).getTname());
					ServletActionContext.getRequest().getSession().setAttribute("loginUser", user);
					message = "loginok";	
					}
			}else if (user.getRole()==3) {
				String hql = "from Admin where aname='"+user.getUserNo()+"' and apwd='"+user.getPwd()+"'";
				List<Admin> student = session.createQuery(hql).list();
				if (student.size()==0) {
					user=null;
					message = "loginnot";
				}else {
					user.setName(student.get(0).getAname());
					ServletActionContext.getRequest().getSession().setAttribute("loginUser", user);
					message = "loginok";
				}
			}
			
			transaction.commit();
			HibernateSessionFactory.closeSession();
			return message;
		}
}
