package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Teacher;

public class teacherDao {
	public List<Teacher> allteacher(){
		List<Teacher> teachers = new ArrayList<Teacher>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		teachers = session.createCriteria(Teacher.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teachers;
	}
}
