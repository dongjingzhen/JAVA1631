package vo;

import java.util.HashSet;
import java.util.Set;

/**
 * 成绩表
 * @author gao
 *
 */
public class Achievement {
	private int id;
	private String coent;
	private double achievement;//成绩
	private String className;
	private Set<Students> studentsList = new HashSet<Students>();
	public String getCoent() {
		return coent;
	}
	public void setCoent(String coent) {
		this.coent = coent;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Set<Students> getStudentsList() {
		return studentsList;
	}
	public void setStudentsList(Set<Students> studentsList) {
		this.studentsList = studentsList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getAchievement() {
		return achievement;
	}
	public void setAchievement(double achievement) {
		this.achievement = achievement;
	}
	
	 
}
