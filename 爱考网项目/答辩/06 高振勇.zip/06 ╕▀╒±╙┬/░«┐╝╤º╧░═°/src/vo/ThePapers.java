package vo;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
/**
 * 考卷表
 * @author gao
 *
 */ 
public class ThePapers {
	private int id;
	private String paperType;//试卷类型
	private String keMu;
	private String tiTtle;//标题
	private int longExam;//考试时长
	private Date dateTime;//开始时间
	private int  totalScore;//总分
	private int totaZongT;//总题数
	private double  ccorePer;//每题分数
	private String examinState;//考试状态：考试中，考试结束，未开考
	private Set<TestQusertion> thePaperQusertion = new HashSet<TestQusertion>();
	private Set<Classes> classesList = new HashSet<Classes>();
	
	public Set<Classes> getClassesList() {
		return classesList;
	}
	public void setClassesList(Set<Classes> classesList) {
		this.classesList = classesList;
	}
	public int getTotaZongT() {
		return totaZongT;
	}
	public void setTotaZongT(int totaZongT) {
		this.totaZongT = totaZongT;
	}
	public double getCcorePer() {
		return ccorePer;
	}
	public void setCcorePer(double ccorePer) {
		this.ccorePer = ccorePer;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public Set<TestQusertion> getThePaperQusertion() {
		return thePaperQusertion;
	}
	public void setThePaperQusertion(Set<TestQusertion> thePaperQusertion) {
		this.thePaperQusertion = thePaperQusertion;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getKeMu() {
		return keMu;
	}
	public void setKeMu(String keMu) {
		this.keMu = keMu;
	}
	public String getPaperType() {
		return paperType;
	}
	public void setPaperType(String paperType) {
		this.paperType = paperType;
	}
	public String getTiTtle() {
		return tiTtle;
	}
	public void setTiTtle(String tiTtle) {
		this.tiTtle = tiTtle;
	}
	
	public int getLongExam() {
		return longExam;
	}
	public void setLongExam(int longExam) {
		this.longExam = longExam;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public String getExaminState() {
		return examinState;
	}
	public void setExaminState(String examinState) {
		this.examinState = examinState;
	}
	
	
}
