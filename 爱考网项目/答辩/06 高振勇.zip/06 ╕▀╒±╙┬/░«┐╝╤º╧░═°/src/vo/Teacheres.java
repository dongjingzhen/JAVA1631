package vo;

import java.util.ArrayList;
import java.util.List;
/**
 * 老师表
 * @author gao
 *
 */ 
public class Teacheres {
	private int id;
	private int zhanghao;//账号
	private String teacheName;//姓名
	private String position;//职位
	private String birthDay;//生日
	private String educaTion;//学历
	private String mima;
	private List<Classes> classList =new ArrayList<Classes>();
	private List<Students> studentslsit =new ArrayList<Students>();
	
	public List<Students> getStudentslsit() {
		return studentslsit;
	}
	public void setStudentslsit(List<Students> studentslsit) {
		this.studentslsit = studentslsit;
	}
	public List<Classes> getClassList() {
		return classList;
	}
	public void setClassList(List<Classes> classList) {
		this.classList = classList;
	}
	public String getMima() {
		return mima;
	}
	public void setMima(String mima) {
		this.mima = mima;
	}
	public String getBirthDay() {
		return birthDay;
	}
	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}
	public String getEducaTion() {
		return educaTion;
	}
	public void setEducaTion(String educaTion) {
		this.educaTion = educaTion;
	}
	public int getZhanghao() {
		return zhanghao;
	}
	public void setZhanghao(int zhanghao) {
		this.zhanghao = zhanghao;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTeacheName() {
		return teacheName;
	}
	public void setTeacheName(String teacheName) {
		this.teacheName = teacheName;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	
}
