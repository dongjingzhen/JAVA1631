package action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;


import vo.Achievement;
import vo.Students;
import vo.TestQusertion;
import vo.ThePapers;

import com.opensymphony.xwork2.Action;

import dao.StudentDao;

public class StudentAction implements Action{
private String[] radioValues;
private Map<Object,Object> mapList=new HashMap<Object,Object>();

	
	public Map<Object, Object> getMapList() {
	return mapList;
}
public void setMapList(Map<Object, Object> mapList) {
	this.mapList = mapList;
}
	public String[] getRadioValues() {
	return radioValues;
}
public void setRadioValues(String[] radioValues) {
	this.radioValues = radioValues;
}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String selectMingXi(){
		StudentDao dao = new StudentDao();
		List<Object[]> obList = dao.selectMingXi();
		ServletActionContext.getRequest().setAttribute("obList", obList);
			return "selectMingXi";
			
		}
	//查看分数
	public String selectFen(){
		StudentDao dao = new StudentDao();
		List<Achievement>  achievement=dao.selectFens();
		String className=(String) ServletActionContext.getRequest().getSession().getAttribute("classesName");
		for (Achievement achievement2 : achievement) {
			achievement2.setClassName(className);
			achievement2.setCoent("java 1阶段项目检测");
		}
		ServletActionContext.getRequest().setAttribute("achievement", achievement);
		
		return "selectFen";
	}
	
	
	public String seleRem(){
		StudentDao dao = new StudentDao();
		List<Students> studentList=dao.selectStudent();
		ServletActionContext.getRequest().setAttribute("studentList", studentList);
		return "seleRem";
		
	}
	//开始考试
	public String startExamination(){
		int id=Integer.parseInt( ServletActionContext.getRequest().getParameter("id").toString());
		
		int tempI=1;
		StudentDao dao = new StudentDao();
		List <TestQusertion> testQusertionList=dao.startExamination(id);
		
		for (int i = 1; i <= testQusertionList.size(); i++) {
			
			mapList.put(i, null);
		}
		for (TestQusertion testQusertion : testQusertionList) {
			
			System.out.println(testQusertion);
			mapList.put(tempI, testQusertion);
			tempI++;
		}
		
//		for (Map.Entry<Object,Object> e : mapList.entrySet()) {
//			System.out.println(e.getKey());
//			System.out.println(e.getValue());
//		}
		ServletActionContext.getRequest().setAttribute("nameId", id);
		ServletActionContext.getRequest().getSession().setAttribute("mapList", mapList);
		
		return "startExamination";
		
	}
	//提交
	public String tiJiaoSj(){
//		System.out.println(radioValues.length);
		StudentDao dao = new StudentDao();
		//算出答对多少道提
		int countT=dao.tiJiao();
		int id=new Integer(ServletActionContext.getRequest().getParameter("nameId").toString()) ;
		dao.fenShu(countT,id);
		ServletActionContext.getRequest().getSession().removeAttribute("mapList");
		return "tiJiaoSj";
		
	}
	//查询班级对应的试卷
	public String selectJuan(){
		int id =Integer.parseInt( ServletActionContext.getRequest().getSession().getAttribute("userID").toString());
		StudentDao dao = new StudentDao();
		List<ThePapers> thePapersList= dao.selectClass(id,0);
		ServletActionContext.getRequest().setAttribute("thePapersList", thePapersList);
		return "selectJuan";
		
	} 
}
