package action;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.omg.CORBA.Request;

import vo.Classes;
import vo.TestQusertion;
import vo.ThePapers;

import com.opensymphony.xwork2.Action;
import com.sun.org.apache.regexp.internal.recompile;

import dao.QuestionesDao;

public class QuestionesAction implements Action {

	private TestQusertion testQusertion;
	private ThePapers thePapers;
	private Classes classes;
	private String[] classesNa;
	
	
	public String[] getClassesNa() {
		return classesNa;
	}
	public void setClassesNa(String[] classesNa) {
		this.classesNa = classesNa;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public ThePapers getThePapers() {
		return thePapers;
	}
	public void setThePapers(ThePapers thePapers) {
		this.thePapers = thePapers;
	}
	public TestQusertion getTestQusertion() {
		return testQusertion;
	}
	public void setTestQusertion(TestQusertion testQusertion) {
		this.testQusertion = testQusertion;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	//查看班级
	public String selectClasses(){
		QuestionesDao dao = new QuestionesDao();
		List<Classes> classesList= dao.selectClassName();
		ServletActionContext.getRequest().setAttribute("id", thePapers.getId());
		ServletActionContext.getRequest().setAttribute("classesList", classesList);
		return "selectClasses";
		
		
	}
	//
	public String addClassPagers() throws ParseException{
		

		
		System.out.println(thePapers.getId());

		QuestionesDao dao = new QuestionesDao();
		System.out.println(thePapers.getDateTime());
		dao.addPage_Class(thePapers,classesNa,thePapers.getDateTime());	
		
		return "addClassPagers";
	}
	//删除试卷
	public String deleteThePagers(){
		int id=testQusertion.getId();
		System.out.println(testQusertion.getId());
		QuestionesDao dao = new QuestionesDao();
		dao.deleteThePagers(id);
		return "deletPagers";
		
	}
	//添加考卷
	public String addThePage(){
		QuestionesDao dao = new QuestionesDao();
		String duoXuan=ServletActionContext.getRequest().getParameter("duoXuan");
		int  danJdan=new Integer(ServletActionContext.getRequest().getParameter("danJdan")) ;
		int danKnan=new Integer(ServletActionContext.getRequest().getParameter("danKnan"));
		int duoJdan=new Integer(ServletActionContext.getRequest().getParameter("duoJdan"));
		int duoKnan=new Integer(ServletActionContext.getRequest().getParameter("duoKnan"));
		testQusertion.setTestTypeJOrB("笔试");
	
		dao.addThePapers(testQusertion, thePapers,duoXuan,danJdan,danKnan,duoJdan,duoKnan);
		return "addPagers";
	}
	//查看试卷
	public String selectThePapers(){
		QuestionesDao dao = new QuestionesDao();
		List<ThePapers> thePapersList= dao.selectThePapers();
		ServletActionContext.getRequest().setAttribute("thePapersList", thePapersList);
		return "selectPapers";
	}
	//增加试题
	public String addQuestion(){
		QuestionesDao dao = new QuestionesDao();
		System.out.println(ServletActionContext.getRequest().getParameter("diJiQi"));
		System.out.println(testQusertion.getKeMu());
		dao.addQuestion(testQusertion);
		return "addQuestion";
		
	}
	//修改试题
	public String modifyQuser(){
		QuestionesDao dao = new QuestionesDao();
		
		dao.testQ(testQusertion);
		System.out.println(testQusertion.getKeMu());
		System.out.println(testQusertion.getDiJiQi());
		return "modifyQuser";
	}
	//修改查询
	public String modifySeleQuser(){
		QuestionesDao dao = new QuestionesDao();
		TestQusertion testQusertion= dao.modifySeleQuser();
		ServletActionContext.getRequest().setAttribute("testQusertion", testQusertion);
		
		return "modifySeleQuser";
		
	}
	//查询方向以及第几期
	public String selectQuest(){
		QuestionesDao dao = new QuestionesDao();
		List<Object[]> List =dao.QuestionesCount();
		ServletActionContext.getRequest().setAttribute("objList", List);
		return "selectQuest";
		}
	//单独查询试题
	public String selectTestQuest(){
		QuestionesDao dao = new QuestionesDao();
		String kemu=null;
		int dijiqi=0;
		int questioneId=0;
		List<TestQusertion> testQusertionList = dao.testQuset();
		for (TestQusertion testQusertion : testQusertionList) {
			questioneId=testQusertion.getQuestiones().getId();
			kemu=testQusertion.getKeMu();
			dijiqi=testQusertion.getDiJiQi();
		}
		System.out.println(ServletActionContext.getRequest().getParameter("kemu"));
		ServletActionContext.getRequest().setAttribute("questioneId",questioneId);
		ServletActionContext.getRequest().setAttribute("kemu",kemu);
		ServletActionContext.getRequest().setAttribute("diJiQi",dijiqi);
		ServletActionContext.getRequest().setAttribute("testQusertionList", testQusertionList);
		return "selectTestQuest";
		
	}
}
