package vo;

import java.util.ArrayList;
import java.util.List;

/**
 * 学习的方向标
 * @author 
 *
 */
public class FangXiang {
	private int id;
	private String fangName;//所专业的名字
	private List<Questiones> questionesList= new ArrayList<Questiones>();
	private List<Students> studentsList= new ArrayList<Students>();
	public List<Students> getStudentsList() {
		return studentsList;
	}
	public void setStudentsList(List<Students> studentsList) {
		this.studentsList = studentsList;
	}
	public List<Questiones> getQuestionesList() {
		return questionesList;
	}
	public void setQuestionesList(List<Questiones> questionesList) {
		this.questionesList = questionesList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFangName() {
		return fangName;
	}
	public void setFangName(String fangName) {
		this.fangName = fangName;
	}
	

}
