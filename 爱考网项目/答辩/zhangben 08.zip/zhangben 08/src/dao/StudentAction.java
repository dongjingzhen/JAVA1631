package dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.Set;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;


import bean.Classes;
import bean.Parper;
import bean.Question;
import bean.Scoredetetails;
import bean.Scores;
import bean.Students;

import com.opensymphony.xwork2.Action;

public class StudentAction implements Action{
	private int id;
	private String name;
	private String pwd;
	private List<Students> studentList;//���մ����ݿ��ѯ��Student����
	private List<Classes> classList ;
	private List<Object[]> paperList ;
	private Set<Question> questionList; 
	private Parper parper;
	private Question question;
	private Scoredetetails scoredetetails;
	private Map<Object,Object> questionMap = new HashMap<Object,Object>();
	private String[] answerTrue;
	private String[] answerSelf;
	
	
	
	
	
	public String[] getAnswerTrue() {
		return answerTrue;
	}
	public void setAnswerTrue(String[] answerTrue) {
		this.answerTrue = answerTrue;
	}
	public String[] getAnswerSelf() {
		return answerSelf;
	}
	public void setAnswerSelf(String[] answerSelf) {
		this.answerSelf = answerSelf;
	}
	public Map<Object, Object> getQuestionMap() {
		return questionMap;
	}
	public void setQuestionMap(Map<Object, Object> questionMap) {
		this.questionMap = questionMap;
	}
	public Scoredetetails getScoredetetails() {
		return scoredetetails;
	}
	public void setScoredetetails(Scoredetetails scoredetetails) {
		this.scoredetetails = scoredetetails;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public Parper getParper() {
		return parper;
	}
	public void setParper(Parper parper) {
		this.parper = parper;
	}
	public Set<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(Set<Question> questionList) {
		this.questionList = questionList;
	}
	public List<Object[]> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Object[]> paperList) {
		this.paperList = paperList;
	}
	public List<Classes> getClassList() {
		return classList;
	}
	public void setClassList(List<Classes> classList) {
		this.classList = classList;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public List<Students> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Students> studentList) {
		this.studentList = studentList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	
	//������Ϣ��ѯ
	public String studentSelf(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		int id = (Integer) ServletActionContext.getRequest().getSession().getAttribute("id");
		String hql = "select s from Students s where id="+id;
		
		Query query = session.createQuery(hql);
		
		studentList = query.list();
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
		
		
	}
	//���߿��� ---- ��ѯ��¼�˿��Կ��������Ծ�
	public String PersonPaper(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		int id = (Integer) ServletActionContext.getRequest().getSession().getAttribute("id");
		
		Criteria criteria = session.createCriteria(Parper.class)
										.setFetchMode("students", FetchMode.JOIN)
										.createAlias("students", "s")
										.add(Restrictions.eq("s.id", id ));
		ProjectionList projectionList = Projections.projectionList()
										.add(Projections.groupProperty("kind"))
										.add(Projections.groupProperty("subjectName"))
										.add(Projections.groupProperty("title"))
										.add(Projections.groupProperty("className"))
										.add(Projections.groupProperty("testTime"))
										.add(Projections.groupProperty("testHour"))
										.add(Projections.groupProperty("pid"));
										
		paperList = criteria.setProjection(projectionList).list();
//		for (Object[] o : paperList) {
//			System.out.println(o[0]+" "+o[1]+" "+o[2]+" "+o[3]+" "+o[4]+" "+o[5]);
//		}
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
	}
	
	//ѧ��ѡ���Ծ���ʼ����
	public String test(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		int stuId = (Integer) ServletActionContext.getRequest().getSession().getAttribute("id");
		System.out.println("ѧ��"+stuId);
		Parper paper = (Parper) session.get(Parper.class, id);
		Students students = (Students) session.get(Students.class, stuId);
		Classes classes = students.getClasses();
		
		Scores scores = new Scores();
		scores.setParper(paper);
		scores.setStudents(students);
		scores.setBeginTime(paper.getTestTime());
		scores.setClasses(classes);
		scores.setScore(0);
		session.save(scores);
		parper = paper;
		questionList =  paper.getQuestion();
		int i = 1;
		for (Question question : questionList) {
			questionMap.put(i, question);
			i++;
		}
		ServletActionContext.getRequest().getSession().setAttribute("maplist", questionMap);
		transaction.commit();
		return SUCCESS;
		
		
	}
	//�ύ�����Ծ�
	public String tiJaoPaper(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Question question1 = (Question) session.get(Question.class, id);
		
		
		questionMap = (HashMap<Object, Object>) ServletActionContext.getRequest().getSession().getAttribute("maplist");
		for (Entry<Object, Object> hpp : questionMap.entrySet()) {
			
			Scoredetetails score = new Scoredetetails();
			Question question = (Question) hpp.getValue();
			score.setQuestion(question1);
			score.setAnswerTrue(ServletActionContext.getRequest().getParameter("answerTrue"+hpp.getKey()));
			score.setAnswerSelf(ServletActionContext.getRequest().getParameter("answerSelf"+hpp.getKey()));
			
		}
		
		
		
		transaction.commit();
		return SUCCESS;
		
		
	}
	//�鿴���Գɼ�
	public String selectTest(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		
		
		
		
		
		transaction.commit();
		return SUCCESS;
		
		
	}
	

}
