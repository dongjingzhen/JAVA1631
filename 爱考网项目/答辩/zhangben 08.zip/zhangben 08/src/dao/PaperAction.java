package dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.ChuanZhi;
import bean.Classes;
import bean.Parper;
import bean.Question;
import bean.Students;
import bean.Subjects;
import bean.Teachers;

import com.opensymphony.xwork2.Action;

public class PaperAction implements Action {
	private List<Parper> parperList;//���ܴ����ݿ�����paper��ֵ
	private List<Subjects> subjectsList;//���մ����ݿ����Ŀ�Ŀ��ֵ
	private Parper parper;//����jsp�д�����ֵ
	private List<Classes> classesList;//���մ����ݿ����İ༶��ֵ
	private Classes classes;
	private String subjectName;
	private String kind;
	private ChuanZhi chuanZhi;
	private int id;
	
	
	//�Ծ��б�
	public String paperList(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		parperList = session.createCriteria(Parper.class).list();
		subjectsList = session.createCriteria(Subjects.class).list();
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
		
		
	}
	//�������Ծ�
	public String SJPaper(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		//Parper p = (Parper) session.get(Parper.class, 1) ;
		Parper p = new Parper();
		
		p.setClassName(parper.getClassName());
		p.setKind(parper.getKind());
		p.setQnumber(parper.getQnumber());
		p.setState(parper.getState());
		p.setSubjectName(parper.getSubjectName());
		p.setTestHour(parper.getTestHour());
		p.setTestTime(parper.getTestTime());
		p.setTitle(parper.getTitle());
		p.setTotalScore(parper.getTotalScore());
			String sql= "select qid from (select top "+chuanZhi.getDJ()+" qid from dbo.question where difficulty='��' and kind='��ѡ' order by newId() "
						+" union select top "+chuanZhi.getDK()+" qid from question where difficulty='����' and kind='��ѡ' order by newId() "
						+" union select top "+chuanZhi.getDY()+" qid from question where difficulty='һ��' and kind='��ѡ' order by newId() "
						+" union select top "+chuanZhi.getDk()+" qid from question where difficulty='����' and kind='��ѡ' order by newId() "
						+" union select top "+chuanZhi.getDy()+" qid from question where difficulty='һ��' and kind='��ѡ' order by newId() "
						+" union select top "+chuanZhi.getDj()+" qid from question where difficulty='��' and kind='��ѡ' order by newId()  )as t";
			List list =  session.createSQLQuery(sql).list();
			for (Object object : list) {
				
				System.out.println(object);
				Question question = (Question) session.get(Question.class, Integer.parseInt(object.toString()));
				p.getQuestion().add(question);
			
		
		}
			session.save(p);
//			session.save(parper);
			// ��ʼ����
			transaction.commit();
			return SUCCESS;	
		
	}
	//�鿴�Ծ�
	public String selectPaper(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		HttpServletRequest request = ServletActionContext.getRequest();
		Parper parper = (Parper) session.get(Parper.class, id);
		questionList = parper.getQuestion();
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
		
		
	}
	//�������Ծ�
	public String addPaper(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		subjectsList = session.createCriteria(Subjects.class).list();
		
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
		
		
	}
	//���ݿ�Ŀ�����Ͳ�ѯ�Ծ�
	@SuppressWarnings("unchecked")
	public String xiangXiShiJuan(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		subjectsList = session.createCriteria(Subjects.class).list();
		String sql = "select * from paper ";
		System.out.println("111"+subjectName);
		if (subjectName.equals("")) {
			if (kind.equals("")) {
				
			}else {
				sql+=" where kind= '"+kind+"'";
			}
		}else {
			if (kind.equals("")) {
				sql+=" where subjectName= '"+subjectName+"'";
			}else {
				sql+=" where kind= '"+kind+"' and subjectName ='"+subjectName+"'";
			}
		}
		
		parperList =  session.createSQLQuery(sql).list();
		
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
	}
	//��ʼ����
	public String startTest(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		classesList = session.createCriteria(Classes.class).list();
		
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
		
		
	}
	//�Ѱ༶���ӵ��Ծ���
	public String addTest(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		Parper parper1 = (Parper) session.get(Parper.class, id);
		Classes cc=(Classes)session.get(Classes.class, classes.getId());
		System.out.println("�༶Id"+classes.getId());
		System.out.println("�Ծ�Id"+id);
		String hql = "select s from Students s where classesId="+classes.getId();
		
		Query query = session.createQuery(hql);
		
		List<Students> list = query.list();
		for (Students students : list) {
			parper1.getStudents().add(students);
		}
		System.out.println(parper.getTestTime());
		parper1.setTestTime(parper.getTestTime());
		parper1.setClassName(cc.getClassName());
		parper1.setState("������");
		session.update(parper1);
		
		
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
		
		
	}
	
	
	
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public List<Classes> getClassesList() {
		return classesList;
	}
	public void setClassesList(List<Classes> classesList) {
		this.classesList = classesList;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public ChuanZhi getChuanZhi() {
		return chuanZhi;
	}
	public void setChuanZhi(ChuanZhi chuanZhi) {
		this.chuanZhi = chuanZhi;
	}
	private Set<Question> questionList = new HashSet<Question>(); 
	public Set<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(Set<Question> questionList) {
		this.questionList = questionList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public Parper getParper() {
		return parper;
	}
	public void setParper(Parper parper) {
		this.parper = parper;
	}
	public List<Subjects> getSubjectsList() {
		return subjectsList;
	}
	public void setSubjectsList(List<Subjects> subjectsList) {
		this.subjectsList = subjectsList;
	}
	public List<Parper> getParperList() {
		return parperList;
	}
	public void setParperList(List<Parper> parperList) {
		this.parperList = parperList;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
