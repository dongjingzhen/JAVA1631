package bean;

public class Scoredetetails {
	private int id;
	private String answerTrue;
	private String answerSelf;
	
	private Question question;
	private Scores scores;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAnswerTrue() {
		return answerTrue;
	}
	public void setAnswerTrue(String answerTrue) {
		this.answerTrue = answerTrue;
	}
	public String getAnswerSelf() {
		return answerSelf;
	}
	public void setAnswerSelf(String answerSelf) {
		this.answerSelf = answerSelf;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public Scores getScores() {
		return scores;
	}
	public void setScores(Scores scores) {
		this.scores = scores;
	}
	
	

}
