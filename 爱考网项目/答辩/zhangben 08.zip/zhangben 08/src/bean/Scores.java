package bean;

import java.util.Date;

public class Scores {
	private int id;
	private Date beginTime;//��ʼʱ��
	private int score;//���Գɼ�
	
	
	private Parper parper;
	private Classes classes;
	private Students students;
	
	
	public Students getStudents() {
		return students;
	}
	public void setStudents(Students students) {
		this.students = students;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public Parper getParper() {
		return parper;
	}
	public void setParper(Parper parper) {
		this.parper = parper;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}
	
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
	
	

}
