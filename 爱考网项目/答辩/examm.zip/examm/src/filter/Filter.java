package filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Filter implements javax.servlet.Filter {

	@Override
	public void destroy() {
		System.out.println("························");
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse ServletResponse,
			FilterChain filterChain) throws IOException, ServletException {
		servletRequest.setCharacterEncoding("utf-8");
		ServletResponse.setCharacterEncoding("utf-8");
		filterChain.doFilter(servletRequest, ServletResponse);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~");

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("-------------------------");
	}

}
