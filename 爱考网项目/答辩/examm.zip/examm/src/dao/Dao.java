package dao;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;


import org.apache.struts2.ServletActionContext;
import org.apache.struts2.components.Else;
import org.extremecomponents.table.context.HttpServletRequestContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import dai.Addteacher;
import dai.Auquestion;
import dai.Begintest;
import dai.Levelnum;
import dai.Lguser;
import dai.subclass;
import dai.subpaper;
import dai.substudent;
import dao.HibernateSessionFactory;
import vo.Admin;
import vo.Class;
import vo.Paper;
import vo.Question;
import vo.Score;
import vo.Scoredetails;
import vo.Student;
import vo.Subject;
import vo.Teacher;

public class Dao {
	//��¼
public int login(Lguser lguser){
	int uid =0;
	Session session=HibernateSessionFactory.getSession();
	int i=Integer.parseInt(lguser.getLgrole());
	System.out.println(lguser.getLgrole());
	System.out.println(lguser.getLgname());
	switch (i) {
	case 1:
		Criteria scriteria=session.createCriteria(Student.class)
        .add(Restrictions.eq("stuName",lguser.getLgname()));
	List<Student> slist=scriteria.list();
   for(Student s:slist){
     if(s.getStuPwd().equals(lguser.getLgpwd())){
uid=s.getId();}
}
		break;
    case 2:
		Criteria tcriteria=session.createCriteria(Teacher.class)
        .add(Restrictions.eq("tname",lguser.getLgname()));
	List<Teacher> tlist=tcriteria.list();
for(Teacher t:tlist){
if(t.getTpwd().equals(lguser.getLgpwd())){
uid=t.getId();
}
}
		break;
    case 3:
		Criteria acriteria=session.createCriteria(Admin.class)
        .add(Restrictions.eq("aname",lguser.getLgname()));
	List<Admin> userlist=acriteria.list();
for(Admin a:userlist){
if(a.getApwd().equals(lguser.getLgpwd())){
uid=a.getId();
}
	break;

	}

	}
	return uid;
}

public List<Object[]> daolist(String type){
	List<Object[]> list=new ArrayList<Object[]>();
	Session session=HibernateSessionFactory.getSession();
	//教师信息查询
	if(type.equals("teacher")){
        Criteria criteria=session.createCriteria(Teacher.class);

        ProjectionList projectionList=Projections.projectionList()
        									.add(Projections.property("id"))        //0
        									.add(Projections.property("taccount"))  //1
        									.add(Projections.property("tname"))     //2
        									.add(Projections.property("tsex"))      //3
        									.add(Projections.property("tbirthday")) //4
       		 								.add(Projections.property("teducation"))//5
       		 								.add(Projections.property("ttelphone")) //6
       		 								.add(Projections.property("tjop"));     //7
        criteria.setProjection(projectionList);
        list=(List<Object[]>)criteria.list();
      //题库信息查询
	}else if(type.equals("question")){
//		  Criteria criteria=session.createCriteria(Question.class).setFetchMode("subject",FetchMode.JOIN)
//		  .createAlias("subject","s").add(Restrictions.eq("",""));
//							System.out.println("jin");
//		 Criteria criteria=session.createCriteria(Question.class).setFetchMode("subject",FetchMode.JOIN)
//            .createAlias("subjectid","s");
//	        ProjectionList projectionList=Projections.projectionList()
//	        .add(Projections.groupProperty("qid"))		    //0
//	        .add(Projections.groupProperty("s.subjectname"))//1
//	        .add(Projections.groupProperty("s.stage"))	    //2
//	        .add(Projections.groupProperty("s.direction"))  //3
//	        .add(Projections.groupProperty("kind"))		    //4
//	        .add(Projections.groupProperty("menthedid"));   //5
//	        									.add(Projections.property("qid"))       //0
//	        									.add(Projections.property("kind"))      //1
//	        									.add(Projections.property("content"))   //2
//	        									.add(Projections.property("optionA"))   //3
//	        									.add(Projections.property("optionB"))   //4
//	       		 								.add(Projections.property("optionC"))   //5
//	       		 								.add(Projections.property("optionD"))   //6
//	       		 								.add(Projections.property("answer"))    //7
//	       		 								.add(Projections.property("difficulty"))//8
//	       		 								.add(Projections.property("subjectId")) //9
//	       		 								.add(Projections.property("chapter"));  //10

		       
		       Criteria criteria=session.createCriteria(Question.class).setFetchMode("subject",FetchMode.JOIN)
                .createAlias("subject","s");
		        ProjectionList projectionList=Projections.projectionList()
		        .add(Projections.groupProperty("s.stage"))
		        .add(Projections.groupProperty("s.subjectname"))
		        .add(Projections.groupProperty("fangfa"))
		        .add(Projections.count("fangfa"))
		        .add(Projections.groupProperty("s.id"));
		        criteria.setProjection(projectionList);
		        list=(List<Object[]>)criteria.list();
		        
	}else if(type.equals("subjectadd")){
		System.out.println("subjectlist");
	    Criteria criteria=session.createCriteria(Subject.class);
        ProjectionList projectionList=Projections.projectionList()
    .add(Projections.property("id"))
    .add(Projections.property("subjectname"));//subjectname
        criteria.setProjection(projectionList);
        list=(List<Object[]>)criteria.list();
	}else if(type.equals("subjectupd")){
		System.out.println("subjectlist");
	    Criteria criteria=session.createCriteria(Subject.class);
        ProjectionList projectionList=Projections.projectionList()
    .add(Projections.property("id"))
    .add(Projections.property("subjectname"));//subjectname
        criteria.setProjection(projectionList);
        list=(List<Object[]>)criteria.list();
        
	}else if(type.equals("paper")){
		
        Criteria criteria=session.createCriteria(Paper.class);

        ProjectionList projectionList=Projections.projectionList()
        									.add(Projections.property("pid"))        	//0
        									.add(Projections.property("subjectName"))   //1
        									.add(Projections.property("kind"))     		//2
        									.add(Projections.property("title"))    	    //3
        									.add(Projections.property("className"))     //4
       		 								.add(Projections.property("testTime"))      //5
       		 								.add(Projections.property("testHour"))      //6
       		 								.add(Projections.property("totalScore"))    //7
        									.add(Projections.property("qnumber"))       //8
        									.add(Projections.property("fen"))           //9
        									.add(Projections.property("state"))         //10
        									;        
        criteria.setProjection(projectionList);
        list=(List<Object[]>)criteria.list();
	}else if(type.equals("addpaper")){
		System.out.println("subjectlist");
	    Criteria criteria=session.createCriteria(Subject.class);
        ProjectionList projectionList=Projections.projectionList()
    .add(Projections.property("id"))
    .add(Projections.property("subjectname"));//subjectname
        criteria.setProjection(projectionList);
        list=(List<Object[]>)criteria.list();
        
	}else if(type.equals("class")){
		 Criteria criteria=session.createCriteria(Class.class);

	        ProjectionList projectionList=Projections.projectionList()
	        								.add(Projections.property("id"))        	 //0
        									.add(Projections.property("classNo"))  		 //1
        									.add(Projections.property("className"))    	 //2
        									.add(Projections.property("direction"))    	 //3
        									.add(Projections.property("headteacher"))    //4
       		 								.add(Projections.property("lecturer"))       //5
       		 								.add(Projections.property("date"))           //6
       		 								.add(Projections.property("state"));         //7
	        									
	        criteria.setProjection(projectionList);
	        list=(List<Object[]>)criteria.list();
	}else if(type.equals("classadd")){
		 Criteria criteria=session.createCriteria(Teacher.class);

	        ProjectionList projectionList=Projections.projectionList()
	        									.add(Projections.property("id"))        //0
	        									.add(Projections.property("taccount"))  //1
	        									.add(Projections.property("tname"))     //2
	        									.add(Projections.property("tsex"))      //3
	        									.add(Projections.property("tbirthday")) //4
	       		 								.add(Projections.property("teducation"))//5
	       		 								.add(Projections.property("ttelphone")) //6
	       		 								.add(Projections.property("tjop"));     //7
	        criteria.setProjection(projectionList);
	        list=(List<Object[]>)criteria.list();
	}else if(type.equals("begintest")){
		 Criteria criteria=session.createCriteria(Class.class);

	        ProjectionList projectionList=Projections.projectionList()
	        								.add(Projections.property("id"))        	 //0
     									.add(Projections.property("classNo"))  		 //1
     									.add(Projections.property("className"))    	 //2
     									.add(Projections.property("direction"))    	 //3
     									.add(Projections.property("headteacher"))    //4
    		 								.add(Projections.property("lecturer"))       //5
    		 								.add(Projections.property("date"))           //6
    		 								.add(Projections.property("state"));         //7
	        									
	        criteria.setProjection(projectionList);
	        list=(List<Object[]>)criteria.list();
	}else if(type.equals("student")) {
		Criteria criteria=session.createCriteria(Student.class).setFetchMode("Class",FetchMode.JOIN)
         .createAlias("class1","c");
		 ProjectionList projectionList=Projections.projectionList()
		                .add(Projections.groupProperty("id"))         //0
		                .add(Projections.groupProperty("stuNo"))      //1
		                .add(Projections.groupProperty("stuPwd"))     //2
		                .add(Projections.groupProperty("c.className"))//3
		                .add(Projections.groupProperty("stuName"))	  //4
		                .add(Projections.groupProperty("stuSex"))     //5
		                .add(Projections.groupProperty("stuTelphone"))//6
		                .add(Projections.groupProperty("parentPhone"))//7
		                .add(Projections.groupProperty("stuSchoolyear"))//8
		                .add(Projections.groupProperty("stuId")) //9
		                .add(Projections.groupProperty("stubrithday"))//10
		                .add(Projections.groupProperty("stuProvide"))//11
		                .add(Projections.groupProperty("stuMajor"))//12
		                .add(Projections.groupProperty("stuParent"))//13
		                .add(Projections.groupProperty("stuDrom"))//14
		                .add(Projections.groupProperty("stuDromNo"))//15
		                .add(Projections.groupProperty("basicSituation"))//16
		                .add(Projections.groupProperty("educational"))//17
		                .add(Projections.groupProperty("guardian"))//18
		                .add(Projections.groupProperty("address"))//19
		                .add(Projections.groupProperty("city"))//10
		                .add(Projections.groupProperty("studyDirection"))//21
		                .add(Projections.groupProperty("image"))//22
		                .add(Projections.groupProperty("political"));//23
		 criteria.setMaxResults(2);
		 criteria.setProjection(projectionList);
	        list=(List<Object[]>)criteria.list();
	}
	
	
	return list;
}

//条件查找

public List<Object[]> tjlist(String type,int qual,int i,int id){
	//题库详细查询
	List<Object[]> list=new ArrayList<Object[]>();
	Session session=HibernateSessionFactory.getSession();
	if(type.equals("question")){
    Criteria criteria=session.createCriteria(Question.class).setFetchMode("paper",FetchMode.JOIN)
    .createAlias("paper","p").add(Restrictions.eq("p.pid",qual));
       ProjectionList projectionList=Projections.projectionList()
	    .add(Projections.property("qid"))       //0
	    .add(Projections.property("kind"))      //1
	    .add(Projections.property("content"))   //2
	    .add(Projections.property("optionA"))   //3
	    .add(Projections.property("optionB"))   //4
		.add(Projections.property("optionC"))   //5
		.add(Projections.property("optionD"))   //6
		.add(Projections.property("answer"))    //7
		.add(Projections.property("difficulty"))//8
		.add(Projections.property("chapter"))   //9
       .add(Projections.property("p.pid"))      //10
       .add(Projections.property("fangfa"));   //11
       criteria.setProjection(projectionList);
       list=(List<Object[]>)criteria.list();
       }else if(type.equals("paper")){
   	    Criteria criteria=session.createCriteria(Paper.class).setFetchMode("Student",FetchMode.JOIN)
	    .createAlias("student","s").add(Restrictions.eq("s.id",qual));
	        ProjectionList projectionList=Projections.projectionList()
	        									.add(Projections.property("pid"))        	//0
	        									.add(Projections.property("subjectName"))   //1
	        									.add(Projections.property("kind"))     		//2
	        									.add(Projections.property("title"))    	    //3
	        									.add(Projections.property("className"))     //4
	       		 								.add(Projections.property("testTime"))      //5
	       		 								.add(Projections.property("testHour"))      //6
	       		 								.add(Projections.property("totalScore"))    //7
	        									.add(Projections.property("qnumber"))       //8
	        									.add(Projections.property("fen"))           //9
	        									.add(Projections.property("state"));        //10
	        criteria.setProjection(projectionList);
	        list=(List<Object[]>)criteria.list();
   }else if(type.equals("testaccount")){
	   Criteria criteria=session.createCriteria(Question.class).setFetchMode("paper",FetchMode.JOIN)
	    .createAlias("paper","p").add(Restrictions.eq("p.pid",qual));
	       ProjectionList projectionList=Projections.projectionList()
		    .add(Projections.property("qid"))       //0
		    .add(Projections.property("kind"))      //1
		    .add(Projections.property("content"))   //2
		    .add(Projections.property("optionA"))   //3
		    .add(Projections.property("optionB"))   //4
			.add(Projections.property("optionC"))   //5
			.add(Projections.property("optionD"))   //6
			.add(Projections.property("answer"))    //7
			.add(Projections.property("p.qnumber")) //8
			.add(Projections.property("p.fen"))     //9
	       .add(Projections.property("p.pid"))      //10
	       .add(Projections.property("fangfa"));   //11
	       criteria.setProjection(projectionList);
//	       criteria.setMaxResults(1);
//	    	   criteria.setFirstResult((i-1)*1);
	       list=(List<Object[]>)criteria.list();
	       int count=0; String get =null; int fen=0;
	       for(Object [] o:list){
	    	  
	    	   Scoredetails scoredetails=new Scoredetails();
	    	   count++;
	    	 String seled=""+count;
	    	 HttpServletRequest request=ServletActionContext.getRequest();
	    	 if(o[1].toString().equals("单选")){
	    		 get=request.getParameter(seled);
	    		 if(get.equals(o[7].toString())){
	    			 System.out.println(count+"正确");
	    			 fen++;
	    		 }
	    		 scoredetails.setResult(get);
	    	 }else
	    	 
	    	 
	         if(o[1].toString().equals("多选")){
	        	 String[] geet=request.getParameterValues(seled); 
	        	  for(int t=0;t<geet.length; t++){
	        	  if(t==0){
	        	  get=""+geet[t];
	        	  }else{
	        	  get=get+", "+geet[t];
	        	  }
	        	  } 
	        	 if(get.equals(o[7].toString())){
		    			 System.out.println(count+"正确");
		    			 fen++;
		    	 }
	        	 scoredetails.setResult(get);
	        	
	         }
	    	 List<Score> scorelist=session.createCriteria(Score.class).list();
	    	 System.out.println("qual id"+qual+id);
	    	 for(Score sc:scorelist){
//	    		 if(sc.getPaperId().equals(qual)&&sc.getStuId().equals(id)){
//	    			 id=sc.getId();
System.out.println(sc.getId()+sc.getPaperId()+sc.getStuId());
//	    		 }
	    		 
	    	 }
	    	 
	    	 Transaction transaction=session.beginTransaction();
	    	   Question question=new Question();
	    	   question =(Question)session.get(Question.class,Integer.parseInt(o[0].toString()));
	    	 System.out.println(scoredetails.getResult());
			 Score score=new Score();
			 System.out.println(id+".....................");
			 score=(Score)session.get(Score.class,1);
			 scoredetails.getScore().add(score);
	    	 question.getScoredetails().add(scoredetails);
        	 session.update(question);
	    	 transaction.commit();
	         
	    	 
	       }
	   
  }else if(type.equals("testquestion")){
	  System.out.println("queston=====");
	  Criteria criteria=session.createCriteria(Question.class).setFetchMode("paper",FetchMode.JOIN)
	    .createAlias("paper","p").add(Restrictions.eq("p.pid",qual));
	       ProjectionList projectionList=Projections.projectionList()
		    .add(Projections.property("qid"))       //0
		    .add(Projections.property("kind"))      //1
		    .add(Projections.property("content"))   //2
		    .add(Projections.property("optionA"))   //3
		    .add(Projections.property("optionB"))   //4
			.add(Projections.property("optionC"))   //5
			.add(Projections.property("optionD"))   //6
			.add(Projections.property("answer"))    //7
			.add(Projections.property("p.qnumber"))//8
			.add(Projections.property("p.fen"))   //9
	       .add(Projections.property("p.pid"))      //10
	       .add(Projections.property("fangfa"));   //11
	    
	       criteria.setProjection(projectionList);
	       
	       
//	       criteria.setMaxResults(1);
//	    	   criteria.setFirstResult((i-1)*1);
	       list=(List<Object[]>)criteria.list();
	  
	       for( Object[] o :list){
	    	   Scoredetails scoredetails=new Scoredetails();
	    	   scoredetails.setQuestionId(Integer.parseInt(o[0].toString()));
	    	   scoredetails.setAnswer(o[7].toString());
	    	   
	    	   List<Object []> slist=new ArrayList<Object []>();
	    	   System.out.println("score =====");
	    	   Criteria criteria1=session.createCriteria(Score.class).setFetchMode("student",FetchMode.JOIN)
	   	    .createAlias("student","s").add(Restrictions.eq("s.id",id));
	    	   ProjectionList projectionList1=Projections.projectionList() .add(Projections.property("id")).add(Projections.property("subjectName"));
	    	   criteria1.setProjection(projectionList1);
	    	   slist=criteria1.list();
	    	   for(Object[] s:slist){
	    	          Transaction transaction =session.beginTransaction();
	    	             System.out.println("sp=====");
	    	             Score score=new Score();
	    	             score=(Score)session.get(Score.class,Integer.parseInt(s[0].toString()));
	    	                                                    
	    	             score.getScoredetails().add(scoredetails);
	    		    	   session.update(score);
	    		    	   transaction.commit();
	    	   }
 
	       }
  }
	return list;
}

public void test(int i,int qual,String radio){
	if(i!=0){
	Session session=HibernateSessionFactory.getSession();
	List<Object[]> slist =new ArrayList<Object[]>();
	   String sql="select top 1 q.qid,q.kind,q.content,q.optionA,q.optionB,q.optionC,q.optionD,q.answer from question q, paper_question pq where q.qid=pq.qid and q.qid not in"+
	   "(select top "+(i-1)+" pq.qid from paper_question pq where pq.pid="+qual+") ";
	  		   slist=session.createSQLQuery(sql).list();
	  		for(Object[] o:slist){
	  			System.out.println("8");
	  			String answer=o[7].toString();
	  			if(answer.equals(radio)){
	  				System.out.println("++++++++++++");
	  				
	  				//加分操作
	  			}else{
	  				System.out.println("budeng");  
	  			}
	  			}
	  		}else{
	  		  System.out.println("i=0");    
}
	
}
//public Map<Object, Object> testz(String type,int qual,int i){
//	Map<Object, Object> map=new HashMap<Object, Object>();
//	if(type.equals("testquestion")){
//		   String sql="select top 1 q.qid,q.kind,q.content,q.optionA,q.optionB,q.optionC,q.optionD,q.answer from question q, paper_question pq where q.qid=pq.qid and q.qid not in"+
//		   "(select top "+i+" pq.qid from paper_question pq where pq.pid="+qual+")";
//		  		   list= session.createSQLQuery(sql).list();
//		  		 HttpServletRequest request=ServletActionContext.getRequest();
//		  		 String radio = request.getParameter("st");
//		  		 Map<Object,Object> map=new HashMap<Object, Object>();
//		  		 map.put(i,radio);
//		  		 System.out.println("----------------");
//		  		 System.out.println(i);
//		  		 System.out.println(radio);
//		  		 test(i, qual, radio);
//		  	     	System.out.println(qual);
//		   
//	}
//}

public List<Object[]> tiaojianlist(int qual,String type){
	//题库详细查询
	
	List<Object[]> list=new ArrayList<Object[]>();
	Session session=HibernateSessionFactory.getSession();
	       Criteria criteria=session.createCriteria(Question.class).setFetchMode("subject",FetchMode.JOIN)
         .createAlias("subject","s").add(Restrictions.eq("fangfa",type))
         .add(Restrictions.eq("s.id",qual));
	        ProjectionList projectionList=Projections.projectionList()
		    .add(Projections.property("qid"))       //0
		    .add(Projections.property("kind"))      //1
		    .add(Projections.property("content"))   //2
		    .add(Projections.property("optionA"))   //3
		    .add(Projections.property("optionB"))   //4
			.add(Projections.property("optionC"))   //5
			.add(Projections.property("optionD"))   //6
			.add(Projections.property("answer"))    //7
			.add(Projections.property("difficulty"))//8
			.add(Projections.property("chapter"))   //9
	        .add(Projections.property("s.id"))      //10
	        .add(Projections.property("fangfa"));   //11
	        criteria.setProjection(projectionList);
	        list=(List<Object[]>)criteria.list();
	if(type.equals("question")){
		
		
	}
	return list;
}

public Object[] dglist(int qual,String type){
	Object[] obj=new Object[25];
	Session session=HibernateSessionFactory.getSession();
	if(type.equals("teacher")){
		obj=new Object[9];
		System.out.println(qual);
		Teacher teacher=new Teacher();
		teacher =(Teacher)session.get(Teacher.class,qual);
		obj[0]=teacher.getId();
		obj[1]=teacher.getTaccount();
		obj[2]=teacher.getTpwd();
		obj[3]=teacher.getTname();
		obj[4]=teacher.getTsex();
		obj[5]=teacher.getTbirthday();
		obj[6]=teacher.getTeducation();
		obj[7]=teacher.getTtelphone();
		obj[8]=teacher.getTjop();
	}else if(type.equals("question")){
		System.out.println(qual);
		Question question=new Question();
		question =(Question)session.get(Question.class,qual);
		obj[0]=question.getKind();
		obj[1]=question.getContent();
		obj[2]=question.getOptionA();
		obj[3]=question.getOptionB();
		obj[4]=question.getOptionC();
		obj[5]=question.getOptionD();
		obj[6]=question.getAnswer();
		obj[7]=question.getDifficulty();
		obj[8]=question.getChapter();
		obj[9]=question.getFangfa();
		obj[10]=question.getSubject().getSubjectname();
		obj[11]=question.getSubject().getId();
		obj[12]=question.getQid();
	    
	}else if(type.equals("class")){
		System.out.println(qual);
		Class class1=new Class();
		class1 =(Class)session.get(Class.class,qual);
		obj[0]=class1.getId();
		obj[1]=class1.getClassNo();
		obj[2]=class1.getClassName();
		obj[3]=class1.getDirection();
		obj[4]=class1.getHeadteacher();
		obj[5]=class1.getLecturer();
		obj[6]=class1.getDate();
		obj[7]=class1.getState();
	
	    
	}else if(type.equals("student")){
		System.out.println(qual);
		Student student=new Student();
		student=(Student)session.get(Student.class, qual);
		obj[0]=student.getId();
		obj[1]=student.getStuNo();
		obj[2]=student.getStuPwd();
		obj[3]=student.getClass1().getClassName();
		obj[4]=student.getStuName();
		obj[5]=student.getStuSex();
		obj[6]=student.getStuTelphone();
		obj[7]=student.getParentPhone();
		obj[8]=student.getStuSchoolyear();
		obj[9]=student.getStuId();
		obj[10]=student.getStubrithday();
		obj[11]=student.getStuProvide();
		obj[12]=student.getStuMajor();
		obj[13]=student.getStuParent();
		obj[14]=student.getStuDrom();
		obj[15]=student.getStuDromNo();
		obj[16]=student.getBasicSituation();
		obj[17]=student.getEducational();
		obj[18]=student.getGuardian();
		obj[19]=student.getAddress();
		obj[20]=student.getCity();
		obj[21]=student.getStudyDirection();
		obj[22]=student.getImage();
		obj[23]=student.getPolitical();
		obj[24]=student.getClassId();
	}
	
	return obj;
	}

public boolean add(String type,Addteacher addteacher,Auquestion auquestion,Levelnum levelnum,subpaper subpaper,subclass subclass,int id,substudent substudent){
	boolean bool=false;
	Session session=HibernateSessionFactory.getSession();
	Transaction transaction=session.beginTransaction();
	if(type.equals("teacher")){
		Teacher teacher=new Teacher();
		teacher.setTname(addteacher.getTname());
		teacher.setTaccount(addteacher.getTaccount());
		teacher.setTeducation(addteacher.getTeducation());
		teacher.setTbirthday(addteacher.getTbirthday());
		teacher.setTjop(addteacher.getTjop());
		teacher.setTpwd(addteacher.getTpwd());
		teacher.setTsex(addteacher.getTsex());
		teacher.setTtelphone(addteacher.getTtelphone());
		teacher.setRemarks(addteacher.getRemarks());
		session.save(teacher);
	}else if(type.equals("question")){
		Question question=new Question();
		Subject subject=new Subject();
		subject=(Subject)session.get(Subject.class,auquestion.getSubjectid());
		question.setAnswer(auquestion.getAnswer());
		question.setChapter(auquestion.getChapter());
		question.setContent(auquestion.getContent());
		question.setDifficulty(auquestion.getDifficulty());
		question.setFangfa(auquestion.getFangfa());
		question.setKind(auquestion.getKind());
		question.setOptionA(auquestion.getOptionA());
		question.setOptionB(auquestion.getOptionB());
		question.setOptionC(auquestion.getOptionC());
		question.setOptionD(auquestion.getOptionD());
		subject.getQuestion().add(question);
		session.update(subject);
	}else if(type.equals("paper")){
		System.out.println(type);
		String sql="select top "+levelnum.getReasy()+" qid,newId() from Question where difficulty='简单'and kind='单选' union all select top "+levelnum.getRmid()+" qid,newId() from Question where difficulty='中等'and kind='单选'union all select top "+levelnum.getRdif()+" qid,newId() from Question where difficulty='困难'and kind='单选' union all select top "+levelnum.getCeasy()+" qid,newId() from Question where difficulty='简单'and kind='多选' union all select top "+levelnum.getCmid()+" qid,newId() from Question where difficulty='中等'and kind='多选' union all select top "+levelnum.getCdif()+" qid,newId() from Question where difficulty='困难'and kind='多选'  order by newId()";
		List<Object[]> obj=session.createSQLQuery(sql).list();
	Paper paper=new Paper();
	paper.setClassName(subpaper.getClassName());
	paper.setKind(subpaper.getKind());
	paper.setQnumber(subpaper.getQnumber());
	paper.setFen(subpaper.getFen());
	paper.setSubjectName(subpaper.getSubjectName());
	paper.setTestHour(subpaper.getTestHour());
	paper.setTestTime(subpaper.getTestTime());
	paper.setTitle(subpaper.getTitle());
	paper.setTotalScore(subpaper.getTotalScore());
	paper.setState(subpaper.getState());
	
	for(Object[] o:obj){
		Question question=new Question();
		question=(Question)session.get(Question.class,Integer.parseInt(o[0].toString()));
		paper.getQuestion().add(question);
		session.save(paper);
	}
		
	}else if(type.equals("class")){
		Class class1=new Class();
		class1.setClassName(subclass.getClassName());
	    class1.setClassNo(subclass.getClassNo());
	    class1.setDate(subclass.getDate());
	    class1.setDirection(subclass.getDirection());
	    class1.setHeadteacher(subclass.getHeadteacher());
	    class1.setLecturer(subclass.getLecturer());
	    class1.setState(subclass.getState());
	    session.save(class1);
	}else if(type.equals("student")){
		//weixie
	}
	transaction.commit();
	HibernateSessionFactory.closeSession();
	return bool;
}

public boolean update(String type,Addteacher addteacher,Auquestion jquestion,subclass subclass,int id,Begintest begintest,substudent substudent){
	System.out.println(id);
	boolean bool=false;
	Session session=HibernateSessionFactory.getSession();
	Transaction transaction=session.beginTransaction();
	if(type.equals("teacher")){
		Teacher teacher=new Teacher();
		teacher=(Teacher)session.get(Teacher.class,id);
		teacher.setTname(addteacher.getTname());
		teacher.setTaccount(addteacher.getTaccount());
		teacher.setTeducation(addteacher.getTeducation());
		teacher.setTbirthday(addteacher.getTbirthday());
		teacher.setTjop(addteacher.getTjop());
		teacher.setTpwd(addteacher.getTpwd());
		teacher.setTsex(addteacher.getTsex());
		teacher.setTtelphone(addteacher.getTtelphone());
		teacher.setRemarks(addteacher.getRemarks());
		session.update(teacher);
	}else if(type.equals("question")){
		
		Question question=new Question();
		Subject subject=new Subject();
		subject=(Subject)session.get(Subject.class,jquestion.getSubjectid());
		question=(Question)session.get(Question.class,id);
		
		question.setAnswer(jquestion.getAnswer());
		question.setChapter(jquestion.getChapter());
		question.setContent(jquestion.getContent());
		question.setDifficulty(jquestion.getDifficulty());
		question.setFangfa(jquestion.getFangfa());
		question.setKind(jquestion.getKind());
		question.setOptionA(jquestion.getOptionA());
		question.setOptionB(jquestion.getOptionB());
		question.setOptionC(jquestion.getOptionC());
		question.setOptionD(jquestion.getOptionD());
		subject.getQuestion().add(question);
		session.update(subject);
	}else if(type.equals("class")){
		Class class1=new Class();
		class1=(Class)session.get(Class.class,id);
		class1.setClassName(subclass.getClassName());
	    class1.setClassNo(subclass.getClassNo());
	    class1.setDate(subclass.getDate());
	    class1.setDirection(subclass.getDirection());
	    class1.setHeadteacher(subclass.getHeadteacher());
	    class1.setLecturer(subclass.getLecturer());
	    class1.setState(subclass.getState());
	    session.update(class1);
	    
	}else if(type.equals("paper")){
		Paper paper=new Paper();
		paper=(Paper)session.get(Paper.class,id);
		paper.setClassName(begintest.getClassName());
		paper.setTestHour(begintest.getTestHour());
		paper.setTestTime(begintest.getTestTime());
		paper.setState(begintest.getState());
		session.update(paper);
		Criteria criteria=session.createCriteria(Student.class).setFetchMode("class",FetchMode.JOIN)
        .createAlias("class1","c").add(Restrictions.eq("c.className",begintest.getClassName()));
		ProjectionList projectionList=Projections.projectionList()
	    .add(Projections.property("id"))
	    .add(Projections.property("c.className"))
	    .add(Projections.property("c.id"));
		criteria.setProjection(projectionList);
		List<Object []> list=criteria.list();
		for(Object[] s: list ){
			Student student=new Student();
			int i=Integer.parseInt(s[0].toString());
			System.out.println(i);
			student=(Student)session.get(Student.class,i);
			
			Score score=new Score();
			score.setBeginTime(begintest.getTestTime());
			score.setClassId(Integer.parseInt(s[2].toString()));//student score
			score.setPaperId(id);
			score.setSubjectName(paper.getSubjectName());
			student.getScore().add(score);
			
			paper.getStudent().add(student);
			session.save(paper);
		}
	}else if(type.equals("student")){
		Student student=new Student();
		student=(Student)session.get(Student.class,id);
		student.setAddress(substudent.getAddress());
		student.setBasicSituation(substudent.getBasicSituation());
		student.setCity(substudent.getCity());
		student.setClassId(substudent.getClassId());
		student.setEducational(substudent.getEducational());
		student.setGuardian(substudent.getGuardian());
		student.setImage(substudent.getImage());
		student.setParentPhone(substudent.getParentPhone());
		student.setPolitical(substudent.getPolitical());
		student.setStubrithday(substudent.getStubrithday());
		student.setStuDrom(substudent.getStuDrom());
		student.setStuDromNo(substudent.getStuDromNo());
		student.setStudyDirection(substudent.getStudyDirection());
		student.setStuId(substudent.getStuId());
		student.setStuMajor(substudent.getStuMajor());
		student.setStuName(substudent.getStuName());
		student.setStuNo(substudent.getStuNo());
		student.setStuParent(substudent.getStuParent());
		student.setStuProvide(substudent.getStuProvide());
		student.setStuPwd(substudent.getStuPwd());
		student.setStuSchoolyear(substudent.getStuSchoolyear());
		student.setStuSex(substudent.getStuSex());
		student.setStuTelphone(substudent.getStuTelphone());
            	session.update(student);
	}
	transaction.commit();
	HibernateSessionFactory.closeSession();
	return bool;
}
public boolean delete(String type,int id){
	boolean bool=false;
	Session session=HibernateSessionFactory.getSession();
	if(type.equals("question")){
		Question question=new Question();
		question=(Question)session.get(Question.class,id);
		session.delete(question);
	}else if(type.equals("teacher")){
		Teacher teacher=new Teacher();
		teacher=(Teacher)session.get(Teacher.class,id);
		session.delete(teacher);
	}
	return bool;
}
	
}
