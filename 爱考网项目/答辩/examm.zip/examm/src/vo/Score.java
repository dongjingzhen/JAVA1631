package vo;
// default package

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;


/**
 * Score entity. @author MyEclipse Persistence Tools
 */

public class Score  implements java.io.Serializable {


    // Fields    

     private Integer id;
     private Integer classId;
     private Integer stuId;
     private String subjectName;
     private Integer paperId;
     private Timestamp beginTime;
     private Timestamp endTime;
     private Double score;
     private Student student;
     private Set<Scoredetails> scoredetails=new HashSet<Scoredetails>();
     
     
     
	public Set<Scoredetails> getScoredetails() {
		return scoredetails;
	}
	public void setScoredetails(Set<Scoredetails> scoredetails) {
		this.scoredetails = scoredetails;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getClassId() {
		return classId;
	}
	public void setClassId(Integer classId) {
		this.classId = classId;
	}
	public Integer getStuId() {
		return stuId;
	}
	public void setStuId(Integer stuId) {
		this.stuId = stuId;
	}

	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public Integer getPaperId() {
		return paperId;
	}
	public void setPaperId(Integer paperId) {
		this.paperId = paperId;
	}
	public Timestamp getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Timestamp beginTime) {
		this.beginTime = beginTime;
	}
	public Timestamp getEndTime() {
		return endTime;
	}
	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}
	public Double getScore() {
		return score;
	}
	public void setScore(Double score) {
		this.score = score;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
     
      
}