package dai;

public class Levelnum {
private int reasy;
private int rmid;
private int rdif;
private int ceasy;
private int cmid;
private int cdif;
public int getReasy() {
	return reasy;
}
public void setReasy(int reasy) {
	this.reasy = reasy;
}
public int getRmid() {
	return rmid;
}
public void setRmid(int rmid) {
	this.rmid = rmid;
}
public int getRdif() {
	return rdif;
}
public void setRdif(int rdif) {
	this.rdif = rdif;
}
public int getCeasy() {
	return ceasy;
}
public void setCeasy(int ceasy) {
	this.ceasy = ceasy;
}
public int getCmid() {
	return cmid;
}
public void setCmid(int cmid) {
	this.cmid = cmid;
}
public int getCdif() {
	return cdif;
}
public void setCdif(int cdif) {
	this.cdif = cdif;
}


}
