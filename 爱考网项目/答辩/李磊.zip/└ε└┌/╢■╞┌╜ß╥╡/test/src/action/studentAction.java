package action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Paper;
import vo.Score;
import vo.Student;
import vo.Subject;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.studentDao;
import dao.teacherDao;

public class studentAction implements Action{
	private studentDao sdao = new studentDao();
	
	private List<Paper> papers = new ArrayList<Paper>();
	private List<Score> scores = new ArrayList<Score>();
	public List<Student> studentList;//����ѧ������ϸ��Ϣ
	
	public List<Student> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}
	public List<Score> getScores() {
		return scores;
	}
	public void setScores(List<Score> scores) {
		this.scores = scores;
	}
	private Student student;
	
	public List<Paper> getPapers() {
		return papers;
	}
	public void setPapers(List<Paper> papers) {
		this.papers = papers;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	private List<Student> students = new ArrayList<Student>();
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String allStudent(){
			
			students = sdao.allStudent();
			return "next";
		}
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	public String studentPaper(){
		
		student = sdao.getstu();
		papers = sdao.studentPaper();
		return "next";
	}
	public String ScorePaper(){
		
		student = sdao.getstu();
		scores = sdao.ScorePaper(student);
		return "next";
	}
	//��ȡĳ��ѧ������ϸ��Ϣ
	public String studentPerson(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		int stuId = (Integer) ServletActionContext.getRequest().getSession().getAttribute("stuId");
		
		String hql = "select s from Student s where id="+stuId;
		
		Query query = session.createQuery(hql);
		
		studentList = query.list();
		
		
		return SUCCESS;
		
		
	}
}
