package action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import vo.Classes;
import vo.Num;
import vo.Paper;
import vo.Question;
import vo.Subject;

import com.opensymphony.xwork2.Action;

import dao.PaperDao;

public class PaperAction implements Action{
	private Question question;//ʵ������   ���ղ�ѯ����������Ϣ
	private Question tquestion;
	private int[] className;//���հ༶���Ƶ�����
	private Date testTime;//���տ���ʱ��
	public Date getTestTime() {
		return testTime;
	}
	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}
	
	public int[] getClassName() {
		return className;
	}
	public void setClassName(int[] className) {
		this.className = className;
	}

	private List<Classes> classes = new ArrayList<Classes>();
	public List<Classes> getClasses() {
		return classes;
	}
	public void setClasses(List<Classes> classes) {
		this.classes = classes;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public Question getTquestion() {
		return tquestion;
	}
	public void setTquestion(Question tquestion) {
		this.tquestion = tquestion;
	}
	private List<Question> questions =new ArrayList<Question>();
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
	private Paper paper;
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	private List<Subject> subject = new ArrayList<Subject>();
	private Subject s;
	private Num num;
	public Num getNum() {
		return num;
	}
	public void setNum(Num num) {
		this.num = num;
	}
	public Subject getS() {
		return s;
	}
	public void setS(Subject s) {
		this.s = s;
	}
	public List<Subject> getSubject() {
		return subject;
	}
	public void setSubject(List<Subject> subject) {
		this.subject = subject;
	}
	PaperDao dao = new PaperDao();
	List<Paper> papers = new ArrayList<Paper>();
	public List<Paper> getPapers() {
		return papers;
	}
	public void setPapers(List<Paper> papers) {
		this.papers = papers;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String allPaper(){
		papers = dao.allPaper();
		return "next";
	}
	public String addPaper(){
		 dao.random(num, paper);
		return "next";
	}
	
	public String showAddPaper(){
		if(s!=null){
			System.out.println(s.getDirection());
			System.out.println(s.getStage());
		}
		subject = dao.allSubject(s);
		return "next";
	}
	public String searchPaper(){
		paper = dao.searchPaper(paper);
		return "next";
	}
	public String anotherQuestion(){
		
		questions = dao.anotherQuestion(paper);
		return "next";
	}
	public String tiQuestion(){
	 	dao.tiQuestion(paper, question, tquestion);
		return "next";
	}
	
	public String allClasses(){
	 	classes = dao.allClasses();
		return "next";
	}
	public String ready(){
		dao.ready(paper, className, testTime);
		return "next";
	}
}
