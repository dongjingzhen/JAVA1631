package vo;

import java.util.List;

public class Page {
		private int dataCount;
		
		private int pageSize=1;
		
		private int pageCount;
		
		private int currentPage;
		
		private List object;
		 
		private float sum;
		public float getSum() {
			return sum;
		}

		public void setSum(float sum) {
			this.sum = sum;
		}

		public int getDataCount() {
			return dataCount;
		}

		public void setDataCount(int dataCount) {
			this.dataCount = dataCount;
		}

		public int getPageSize() {
			return pageSize;
		}

		public void setPageSize(int pageSize) {
			this.pageSize = pageSize;
		}

		public int getPageCount() {
			return pageCount;
		}

		public void setPageCount(int dataCount,int pageSize) {
			if(dataCount%pageSize ==0){
				this.pageCount = dataCount/pageSize;
			}else{
				this.pageCount = dataCount/pageSize+1;
			}
			
		}

		public int getCurrentPage() {
			return currentPage;
		}

		public void setCurrentPage(int currentPage) {
			this.currentPage = currentPage;
		}

		public List getObject() {
			return object;
		}

		public void setObject(List object) {
			this.object = object;
		}
}
