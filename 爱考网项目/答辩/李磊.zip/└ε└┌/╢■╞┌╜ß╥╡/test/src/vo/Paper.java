package vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
/**
	 * �Ծ���
	 * @author Administrator
	 *
	 */
public class Paper {
	
	private int pid;   //����
	
	private String subjectName;		//��Ŀ
	
	private String kind;	//��𣨻����ԣ�
	
	private String title;	//����
	
	
	private Date testTime;	//����ʱ��
	
	private int testhour;	//����ʱ��
	
	private float totalScore;	//�ܷ�
	
	private int qnumber;	//��Ŀ����
	
	private String state;	//״̬
	private Set<Score> scores = new HashSet<Score>();
	public Set<Score> getScores() {
		return scores;
	}

	public void setScores(Set<Score> scores) {
		this.scores = scores;
	}

	private Set<Question> questions = new HashSet<Question>();
	private Set<Classes> classes = new HashSet<Classes>();
	public Set<Classes> getClasses() {
		return classes;
	}

	public void setClasses(Set<Classes> classes) {
		this.classes = classes;
	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	public Date getTestTime() {
		return testTime;
	}

	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}

	public int getTesthour() {
		return testhour;
	}

	public void setTesthour(int testhour) {
		this.testhour = testhour;
	}

	public float getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(float totalScore) {
		this.totalScore = totalScore;
	}

	public int getQnumber() {
		return qnumber;
	}

	public void setQnumber(int qnumber) {
		this.qnumber = qnumber;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
}
