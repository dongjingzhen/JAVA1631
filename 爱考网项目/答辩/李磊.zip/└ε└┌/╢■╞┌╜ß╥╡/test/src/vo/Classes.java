package vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Classes {
	private int id;
	private String classNo;
	private String className;
	private String direction;
	private String headteacher;
	private String lecturer;
	private Date date;
	
	private Set<Score> scores = new HashSet<Score>();
	
	public Set<Score> getScores() {
		return scores;
	}
	public void setScores(Set<Score> scores) {
		this.scores = scores;
	}
	private Set<Paper> papers = new HashSet<Paper>();
	
	private Set<Student> students = new HashSet<Student>();
 	
	public Set<Student> getStudents() {
		return students;
	}
	public void setStudents(Set<Student> students) {
		this.students = students;
	}
	public Set<Paper> getPapers() {
		return papers;
	}
	public void setPapers(Set<Paper> papers) {
		this.papers = papers;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassNo() {
		return classNo;
	}
	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getHeadteacher() {
		return headteacher;
	}
	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}
	public String getLecturer() {
		return lecturer;
	}
	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	private String state;
}
