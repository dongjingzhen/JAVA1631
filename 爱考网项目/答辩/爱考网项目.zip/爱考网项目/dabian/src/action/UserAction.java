package action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;
import domain.Page;
import domain.Paper;
import domain.Question;
import domain.Student;
import domain.Subject;
import domain.Teacher;
import domain.Classes;


import com.opensymphony.xwork2.Action;

import domain.Admin;
import domain.Users;

public class UserAction implements Action {
	
	
	private String result;
	
	private Admin admin = new Admin();
	
	private Paper paper=new Paper();
	private Users user = new Users();
	private Teacher teacher = new Teacher();
	private Student student = new Student();
	private Question question=new Question();
	private Subject subject=new Subject();
	private Classes classes=new Classes();
	
	
	private int jianDan;
	private int yiBan;
	private int kunNan;
	private Page page = new Page();
	

	private List<Admin> adminlist = new ArrayList<Admin>();
	private List<Teacher> teacherlist = new ArrayList<Teacher>();
	private List<Student> studentlist = new ArrayList<Student>();
	private List<Question> questionlist=new ArrayList<Question>();
	private List<Subject> subjectlist=new ArrayList<Subject>();
	private List<Paper> paperlist=new ArrayList<Paper>();
	private List<Classes> classlist=new ArrayList<Classes>();
	
	
	/*
	 * ��½
	 */
	public String login(){
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		if (user.getRole()==3) {
			String hql = "from Admin where aname = '"+user.getName()+"' and apwd = '"+user.getPwd()+"'";
			adminlist= session.createQuery(hql).list();
			transaction.commit();
			if (adminlist.size()==0) {
				result="error";
			} else {
				ServletActionContext.getRequest().getSession().setAttribute("user", user);
				result="adm";
			}
		}else if (user.getRole()==2) {
			String hql = "from Teacher where tname = '"+user.getName()+"' and tpwd = '"+user.getPwd()+"'";
			teacherlist= session.createQuery(hql).list();
			transaction.commit();
			if (teacherlist.size()==0) {
				result="error";
			} else {
				ServletActionContext.getRequest().getSession().setAttribute("user", user);
				result="teacher";
			}
		}else if (user.getRole()==1) {
			String hql = "from Student where stuName = '"+user.getName()+"' and stuPwd = '"+user.getPwd()+"'";
			studentlist= session.createQuery(hql).list();
			transaction.commit();
			if (studentlist.size()==0) {
				result="error";
			} else {
				ServletActionContext.getRequest().getSession().setAttribute("user", user);
				result="stu";
			}
		}else{
			result="error";
		}
		
		return result;
	}
	
	/*
	 * ��ʦ��Ϣ��ѯ
	 */
	public String teacherlist(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		teacherlist=session.createCriteria(Teacher.class).list();
		transaction.commit();		
		return "teacherlist";
	}
	
	
	
	/*
	 * ����ѯ
	 */
	public String question(){
		   Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   //��ѯ���е�object
		   subjectlist=session.createCriteria(Subject.class).list();
		   
		   String sql="select kind,count(kind),subjectid from question group by kind, subjectid";
		   System.out.println();
		   List<Object[]> questionObj= session.createSQLQuery(sql).list(); 
		   for (Object[] obj : questionObj) {
			 for (Subject sub : subjectlist) {
				String a= (String)obj[2];
				
				if (a.equals(sub.getSubjectId())) {
					sub.getSubobj().add(obj);
				}
				
			}
			 
		}
		
		for (Subject sub : subjectlist) {
			Object[] ob = {"��",0,sub.getSubjectId()};
			Object[] obj= {"��",0,sub.getSubjectId()};
			if (sub.getSubobj().size()==1) {
				Object[] ct = sub.getSubobj().get(0);
				String a = (String)ct[2];
				if (a.equals("��")) {
					sub.getSubobj().add(obj);
					
				}else {
					sub.getSubobj().add(ob);
					
				}
				
			}else if (sub.getSubobj().size()==0) {
				sub.getSubobj().add(ob);
				sub.getSubobj().add(obj);
				
			}
			System.out.println(sub);
		}
		   for (Subject s : subjectlist) {
//			stem.out.println(s.getSubjectId()+""+s.getDirection()+""+s.getStage());
			for (int i = 0; i < s.getSubobj().size(); i++) {
				System.out.println(s.getSubobj().get(i)[0]+"  "+s.getSubobj().get(i)[1]+"  "+s.getSubobj().get(i)[2]);
			}
			System.out.println();
			
		}
//		   System.out.println("QQQ");
//		   System.out.println(sql);
		   transaction.commit();
		   HibernateSessionFactory.closeSession();
		return "question";
	}
	
	
	/*
	 * �����ѯ
	 */
	public String questionlist(){
		list();
		return "list";
	}
	
	/*
	 * ��������
	 */
	public String add(){
		HibernateUtils.add(question);
		list();
		return "addok";
	}
	
	/*
	 * ɾ������
	 */
	public String delete(){
		HibernateUtils.delete(question);
		list();
		return "deleteok";
	}
	
	/*
	 * ��ѯ
	 */
	public String updatelist(){
		question =(Question) HibernateUtils.get(Question.class, question.getQid());
		return "updatelistok";
	}
	/*
	 * �޸�
	 */
	public String update(){
		HibernateUtils.update(question);
		list();
		return "update";
	}
	
	
	/*
	 * ע��
	 */
	public String zhuxiao(){
		ServletActionContext.getRequest().getSession().invalidate();
		return INPUT;
	}
	
	
	/*
	 * ����Ծ�
	 */
	public String random(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String sql="select top 5 qid, newId() from question where difficulty= '��'" +
		"  union all select top 3 qid, newId() from question where difficulty= 'һ��' " +
		"union all select top 1 qid, newId() from question where difficulty= '����'" +
		" order by newid()";
		
		return "random";
	}
	
	
	/*
	 * �������ύ
	 */
	public String randomOK(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		//subject = (Subject)HibernateUtils.get(Subject.class, subject.getId());
		
		System.out.println();
		Paper p = new Paper();
		p.setTitle(paper.getTitle());
		p.setKind("����");
		p.setTestHour(paper.getTestHour());
		p.setState("0");
		p.setTotalScore(paper.getTotalScore());
		
		p.setSubjectName(subject.getDirection()
				+" "+subject.getStage()
				+" "+subject.getSubjectId());
		
		String sql="select top "+jianDan+" qid, newId() from question where difficulty= '��'  " +
					"union all " +
						"select top "+yiBan+" qid, newId() from question where difficulty= 'һ��'" +
						"union all " +
						"select top "+kunNan+" qid, newId() from question where difficulty= '����'" +
						"  order by newid()";
		paperlist = (List<Paper>) session.createSQLQuery(sql).list();
		for (Paper list : paperlist) {
			System.out.println(list);
			question = (Question) session.get(Question.class, (Serializable) list);
			p.getQuestionSet().add(question);
		}
		session.save(p);
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "randomOK";
		
	}
	
	/*
	 * ��ѯ�Ծ�
	 */
	public String paperlist(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paperlist=session.createCriteria(Paper.class).list();
		transaction.commit();
		return "paperlist";
	}
	
	
	
	/*
	 * ѧ������
	 */
	public String test(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paperlist=session.createCriteria(Paper.class).list();
		transaction.commit();
		return "testok";
	}
	
	/*
	 * ��ѯ����
	 * @see com.opensymphony.xwork2.Action#execute()
	 */
	
	public void list(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String kind="";
		String sql="from Question where kind='"+question.getKind()+"' and subjectId='"+question.getSubjectId()+"'";
		questionlist=session.createQuery(sql).list();
		for (Question q : questionlist) {
			kind=q.getKind();
			System.out.println(kind);
		}
		
		ServletActionContext.getRequest().setAttribute("kind", kind);
	}
	
	
	/*
	 * ��ѯ�༶(non-Javadoc)
	 * @see com.opensymphony.xwork2.Action#execute()
	 */
	public String listclass(){
		
		
		
		
		
		return "";
	}
	
	
	

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public Admin getAdmin() {
		return admin;
	}



	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public List<Subject> getSubjectlist() {
		return subjectlist;
	}

	public void setSubjectlist(List<Subject> subjectlist) {
		this.subjectlist = subjectlist;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}


	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}
	public Teacher getTeacher() {
		return teacher;
	}



	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}



	public Student getStudent() {
		return student;
	}



	public void setStudent(Student student) {
		this.student = student;
	}



	public Page getPage() {
		return page;
	}



	public void setPage(Page page) {
		this.page = page;
	}



	public List<Admin> getAdminlist() {
		return adminlist;
	}



	public void setAdminlist(List<Admin> adminlist) {
		this.adminlist = adminlist;
	}



	public List<Teacher> getTeacherlist() {
		return teacherlist;
	}



	public void setTeacherlist(List<Teacher> teacherlist) {
		this.teacherlist = teacherlist;
	}



	public List<Student> getStudentlist() {
		return studentlist;
	}



	public void setStudentlist(List<Student> studentlist) {
		this.studentlist = studentlist;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public List<Question> getQuestionlist() {
		return questionlist;
	}

	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public List<Paper> getPaperlist() {
		return paperlist;
	}

	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public List<Classes> getClasslist() {
		return classlist;
	}

	public void setClasslist(List<Classes> classlist) {
		this.classlist = classlist;
	}

}
