package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import beans.Teacher;

public class TeacherDAO {
	public List<Teacher> list(){
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Teacher> teacherList =(List<Teacher>) session.createCriteria(Teacher.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return teacherList;
		
	}
}
