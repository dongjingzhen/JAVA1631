package dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import beans.HibernateUtils;
import beans.Student;
import beans.UserLogin;
import beans.paper;

public class StudentDAO {
	
	public int selectStudent(String stuname,String stupwd){
		String hql = "SELECT s FROM Student s  WHERE  s.stuname= '"+stuname+"' and s.stupwd="+stupwd;
		List<UserLogin> userList = HibernateUtils.getSession().createQuery(hql).list();
		int xs = userList.size(); 
		return xs;
	}
	public List<Student> selectTeacher(){
		
		return null;
	}
	public int selectAdmin(String loginName,String loginPwd ){
		String hql = "SELECT s FROM UserLogin s  WHERE  s.loginName= '"+loginName+"'  and s.loginPwd="+loginPwd ;
		List<UserLogin> userList = HibernateUtils.getSession().createQuery(hql).list();
		int i = userList.size(); 
		return i;
	}
	public List<paper> selectPaper(){
		String hql = "SELECT p from paper p where p.state=1";
		List<paper> selectPaper = HibernateUtils.getSession().createQuery(hql).list();
		return selectPaper;
	}

}
