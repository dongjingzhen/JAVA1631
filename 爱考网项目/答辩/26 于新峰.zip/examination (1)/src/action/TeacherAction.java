package action;

import java.util.List;

import beans.Teacher;

import com.opensymphony.xwork2.Action;

import dao.TeacherDAO;

public class TeacherAction implements Action {
	private List<Teacher> teacherList;
	public String execute() throws Exception {
		return null;
	}
	public String list(){
		TeacherDAO dao = new TeacherDAO();
		teacherList = dao.list();
		return "list";
	}
	public List<Teacher> getTeacherList() {
		return teacherList;
	}
	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}
	
}
