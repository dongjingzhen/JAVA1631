package action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import beans.HibernateUtils;
import beans.Question;

import com.opensymphony.xwork2.Action;

import dao.QuestionDAO;

public class QuestionAction implements Action {
	private List<Object[]> questionList;
	private List<Question> list;
	private List<Question> newlist;
	private List<Question> newslist;
	private String types;
	private String answer;
	private String content;
	private String difficulty;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private int qid;
	private String subject;
	private String type;
	public String execute() throws Exception {
		return null;
	}
	public String questionList(){
		QuestionDAO dao = new QuestionDAO();
		questionList = dao.select();
		return "questionList";
	}
	public String list(){
		QuestionDAO dao = new QuestionDAO();
		list = dao.list();
		return "list";
	}
	public String newlist(){
		QuestionDAO dao = new QuestionDAO();
		newlist = dao.questionlist("����");
		return SUCCESS;
	}
	public String newslist(){
		QuestionDAO dao = new QuestionDAO();
		newlist = dao.questionlist("����");
		return SUCCESS;
	}
	public String Hupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		qid = Integer.parseInt(request.getParameter("qid"));
		subject =request.getParameter("subject");
		type = request.getParameter("type");
		content = request.getParameter("content");
		optionA =  request.getParameter("optionA");
		optionB = request.getParameter("optionB");
		optionC = request.getParameter("optionC");
		optionD = request.getParameter("optionD");
		difficulty = request.getParameter("difficulty");
		System.out.println(type);
		request.setAttribute("qid", qid);
		request.setAttribute("subject", subject);
		request.setAttribute("type", type);
		request.setAttribute("content", content);
		request.setAttribute("optionA", optionA);
		request.setAttribute("qoptionBid", optionB);
		request.setAttribute("optionC", optionC);
		request.setAttribute("difficulty", difficulty);
		return SUCCESS;
	}
	public String Update(){
		Question question = (Question)HibernateUtils.get(Question.class, qid);
		question.setContent(content);
		question.setDifficulty(difficulty);
		question.setOptionA(optionA);
		question.setOptionB(optionB);
		question.setOptionC(optionC);
		question.setOptionD(optionD);
		question.setSubject(subject);
		question.setType(type);
		question.setAnswer(answer);
		System.out.println(answer+optionA+optionB+optionC+optionD);
		HibernateUtils.update(question);
		return "newList";
	}
	public String delete(){
		Question question = (Question)HibernateUtils.get(Question.class, qid);
		HibernateUtils.delete(question);
		return "delete";
	}
	public String insert(){
		Question question = new Question();
		question.setContent(content);
		question.setDifficulty(difficulty);
		question.setOptionA(optionA);
		question.setOptionB(optionB);
		question.setOptionC(optionC);
		question.setOptionD(optionD);
		question.setSubject(subject);
		question.setType(type);
		question.setTypes("����");
		HibernateUtils.add(question);
		return "insert";
	}
	
	
	
	public List<Object[]> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Object[]> questionList) {
		this.questionList = questionList;
	}
	public List<Question> getList() {
		return list;
	}
	public void setList(List<Question> list) {
		this.list = list;
	}
	public List<Question> getNewlist() {
		return newlist;
	}
	public void setNewlist(List<Question> newlist) {
		this.newlist = newlist;
	}
	public String getTypes() {
		return types;
	}
	public void setTypes(String types) {
		this.types = types;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<Question> getNewslist() {
		return newslist;
	}
	public void setNewslist(List<Question> newslist) {
		this.newslist = newslist;
	}
	
}
