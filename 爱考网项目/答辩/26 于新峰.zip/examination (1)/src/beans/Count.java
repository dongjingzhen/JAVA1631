package beans;

public class Count {
	private int countJ;
	private int countZ;
	private int countK;
	private int countsJ;
	private int countsZ;
	private int countsK;
	public int getCountJ() {
		return countJ;
	}
	public void setCountJ(int countJ) {
		this.countJ = countJ;
	}
	public int getCountZ() {
		return countZ;
	}
	public void setCountZ(int countZ) {
		this.countZ = countZ;
	}
	public int getCountK() {
		return countK;
	}
	public void setCountK(int countK) {
		this.countK = countK;
	}
	public int getCountsJ() {
		return countsJ;
	}
	public void setCountsJ(int countsJ) {
		this.countsJ = countsJ;
	}
	public int getCountsZ() {
		return countsZ;
	}
	public void setCountsZ(int countsZ) {
		this.countsZ = countsZ;
	}
	public int getCountsK() {
		return countsK;
	}
	public void setCountsK(int countsK) {
		this.countsK = countsK;
	}
	
	

}
