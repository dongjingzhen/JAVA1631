package beans;

public class Role {
	private int rid;
	private String rname;
	private UserLogin users;
	
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public UserLogin getUsers() {
		return users;
	}
	public void setUsers(UserLogin users) {
		this.users = users;
	}
	
	
}
