package beans;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;


public class Classes {
	private int cid;
	private String classNo;
	private String direction;
	private String headteacher;
	private String clssName;
	private Date date;
	private String lecturer;
	
	private Set<paper> papers = new HashSet<paper>();
	private Set<Student> students = new HashSet<Student>();
	
	
	public Set<paper> getPapers() {
		return papers;
	}
	public void setPapers(Set<paper> papers) {
		this.papers = papers;
	}
	public Set<Student> getStudents() {
		return students;
	}
	public void setStudents(Set<Student> students) {
		this.students = students;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getClassNo() {
		return classNo;
	}
	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getHeadteacher() {
		return headteacher;
	}
	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}
	public String getClssName() {
		return clssName;
	}
	public void setClssName(String clssName) {
		this.clssName = clssName;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getLecturer() {
		return lecturer;
	}
	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}
	
	

}
