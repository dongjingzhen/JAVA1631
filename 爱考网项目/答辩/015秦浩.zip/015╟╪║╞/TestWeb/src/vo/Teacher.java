package vo;

public class Teacher {
	private int teaId;
	private long teaNo;
	private String teaName;
	private String teaPwd;
	private String teaSex;
	private String teaJob;
	private String teaDucation;//ѧλ
	private long teaTel;
	
	
	public long getTeaNo() {
		return teaNo;
	}
	public void setTeaNo(long teaNo) {
		this.teaNo = teaNo;
	}
	public int getTeaId() {
		return teaId;
	}
	public void setTeaId(int teaId) {
		this.teaId = teaId;
	}
	public String getTeaName() {
		return teaName;
	}
	public void setTeaName(String teaName) {
		this.teaName = teaName;
	}
	public String getTeaPwd() {
		return teaPwd;
	}
	public void setTeaPwd(String teaPwd) {
		this.teaPwd = teaPwd;
	}
	public String getTeaSex() {
		return teaSex;
	}
	public void setTeaSex(String teaSex) {
		this.teaSex = teaSex;
	}
	public String getTeaJob() {
		return teaJob;
	}
	public void setTeaJob(String teaJob) {
		this.teaJob = teaJob;
	}
	public String getTeaDucation() {
		return teaDucation;
	}
	public void setTeaDucation(String teaDucation) {
		this.teaDucation = teaDucation;
	}
	public long getTeaTel() {
		return teaTel;
	}
	public void setTeaTel(long teaTel) {
		this.teaTel = teaTel;
	}

}
