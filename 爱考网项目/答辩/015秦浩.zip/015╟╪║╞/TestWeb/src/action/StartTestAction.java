package action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Paper;
import vo.Question;
import vo.Score;
import vo.ScoreDetails;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class StartTestAction implements Action{
	List<Paper> paperlist = new ArrayList<Paper>();
	private  Integer questionIndex;
	private Integer questionReadyIndex;
	
	
	public Integer getQuestionIndex() {
		return questionIndex;
	}
	public void setQuestionIndex(Integer questionIndex) {
		this.questionIndex = questionIndex;
	}
	public Integer getQuestionReadyIndex() {
		return questionReadyIndex;
	}
	public void setQuestionReadyIndex(Integer questionReadyIndex) {
		this.questionReadyIndex = questionReadyIndex;
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//��ѯѧ������ϸ��Ϣ
	public String list() throws Exception {
		// TODO Auto-generated method stub
		return "list";
	}
	//��ѯ��ѧ���ÿ����Ծ�
	public String test() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		String name = (String)ServletActionContext.getRequest().getSession().getAttribute("name");
		
		String sql = "select stuId from students where stuName='"+name+"'";
		List stuId = session.createSQLQuery(sql).list();
		for (Object o : stuId) {
			System.out.println(o.toString());
			String sql1 = "select pid from PaperAndStudents where stuId="+o.toString()+"";
			List pid = session.createSQLQuery(sql1).list();
			for (Object object : pid) {
				
				Paper paper = (Paper)session.get(Paper.class, Integer.parseInt(object.toString()));
				paperlist.add(paper);
			}
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();

		return "test";
	}
	//��ѯ�Ծ��е�������Ŀ
	public String answer() throws Exception {
		// TODO Auto-generated method stub
		Score sc = new Score();
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		String answer = ServletActionContext.getRequest().getParameter("answer");
		String name = (String)ServletActionContext.getRequest().getSession().getAttribute("name");
		String subjectName = (String)ServletActionContext.getRequest().getParameter("subjectName");
		String className = (String)ServletActionContext.getRequest().getParameter("subjectName");
		Map questionmap = (Map)ServletActionContext.getRequest().getSession().getAttribute("questionmap");
		int scoreId = 0;
		
		if (questionmap==null) {
			questionmap = new HashMap();
			int pid = Integer.parseInt(ServletActionContext.getRequest().getParameter("pid"));
			String sql = "select queId from QuestionAndPaper where pid="+pid+"";
			List queId = session.createSQLQuery(sql).list();
			Integer index = 1;
			
			//���ӳɼ���
			String sql1 = "select stuId from students where stuName='"+name+"'";
			List stuId = session.createSQLQuery(sql1).list();
			for (Object object : stuId) {
				
				sc.setStuId(Integer.parseInt(object.toString()));
				sc.setSubjectName(subjectName);
				sc.setClassName(className);
				session.save(sc);
				
				
			}
			
			
			System.out.println(scoreId);
			for (Object o : queId) {
				Question que = new Question();
				que = (Question)session.get(Question.class, Integer.parseInt(o.toString()));
				questionmap.put(index, que);
				index++;
			}
			ServletActionContext.getRequest().getSession().setAttribute("questionmap",questionmap);
		}
		else {
			
				 questionIndex =questionReadyIndex;
				
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().setAttribute("subjectName", subjectName);
		ServletActionContext.getRequest().setAttribute("className", className);
		return "answer";
	}
	public String judge() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
