package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Students;
import vo.Teacher;



import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;


public class StudentsAction implements Action{

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String list() throws Exception{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Students> studentsList =(List<Students>) session.createCriteria(Students.class).list();
		ServletActionContext.getRequest().getSession().setAttribute("studentsList", studentsList);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
	}

}
