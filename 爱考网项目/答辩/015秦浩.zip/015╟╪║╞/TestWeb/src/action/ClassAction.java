package action;

import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Classes;
import vo.Students;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class ClassAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String list() throws Exception {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
//		Classes classes = new Classes();
//		classes.setClassNo("QH1001");
//		classes.setClassName("java1631");
//		classes.setDirection("SCME");
//		classes.setHeadteacher("����ʦ");
//		classes.setLecturer("ţ��ʦ");
//		classes.setDate(new Date());
//		classes.setState("����");
//		
//		session.save(classes);
//		Students stu = (Students)session.get(Students.class, 1);
//		Students stu1 = (Students)session.get(Students.class, 2);
//		Students stu2 = (Students)session.get(Students.class, 3);
//		classes.getStudents().add(stu);
//		classes.getStudents().add(stu1);
//		classes.getStudents().add(stu2);
//		session.save(classes);
//		
		List<Classes> classesList =(List<Classes>) session.createCriteria(Classes.class).list();
		ServletActionContext.getRequest().getSession().setAttribute("classesList", classesList);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
	
	}

}
