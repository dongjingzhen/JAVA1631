package action;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import beans.Count;
import beans.HibernateUtils;
import beans.Question;
import beans.paper;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.PaperDAO;
public class paperAction implements Action {
	private List<paper> paperlist;
	private List<Object[]> list;
	private List<Object[]> selectlist;
	private paper pa;
	private int pid;
	private Count c;
	private Question qu;
	private paper paper;
	private Question question;
	private  Integer questionIndex;
	private Integer questionReadyIndex;
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String paperlist(){
		PaperDAO dao = new PaperDAO();
		paperlist = dao.list();
		return "paperlist";
	}
	public String paperInsert(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper paper = new paper();
		String java = qu.getSubject();
		pa.setSubjectName(java);
		paper.setSubjectName(java);
		paper.setTypes(qu.getTypes());
		paper.setTitle(pa.getTitle());
		paper.setTotalScore(pa.getTotalScore());
		paper.setTestHour(pa.getTestHour());
		paper.setQnumber(pa.getQnumber());
		System.out.println(pa.getType()+pa.getQnumber()+pa.getTitle());
		PaperDAO dao = new PaperDAO();
		list = dao.paperInsert(c, pa);
		for (Object[] q : list) {
			Question question = (Question)session.get(Question.class, (Serializable) q[0]);
			question.getPapers().add(paper);
			session.save(paper);
   		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "paperInsert";
	}
	public String selectlist(){
		PaperDAO dao = new PaperDAO();
		selectlist = dao.selectlist(pid);
		return "selectlist";
	}
	public String delete(){
		paper paper = (paper)HibernateUtils.get(paper.class,pid);
		HibernateUtils.delete(paper);
		return "delete";
	}
	public String stuPaperKaoshi(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		HttpSession httpSession = ServletActionContext.getRequest().getSession();
		//ѧ������
		Map questionMap = (Map) httpSession.getAttribute("questionMap");
		//ѧ���ɼ���ϸ
		if(questionMap==null){
		paper = (paper)session.get(paper.class, paper.getPid());
		questionMap = new HashMap();
		Set<Question> questionSet = null;
		questionSet = paper.getQuestions();
		Integer i = 1;
		for (Question question : questionSet) {

			questionMap.put(i, question);
			i++;

		}
		httpSession.setAttribute("questionMap", questionMap);
	}
	// ��ѯһ�ξ����������,Ȼ��������������Ű�
	else {
		// �ȸ���ѧ������Ż��ԭ��������û�д�
		//����𰸷ǿ�
		if(question!= null)
		{	
			 questionMap.put(questionIndex, question);
			 questionIndex =questionReadyIndex;
		}
			
	}
	//question = (Question) questionMap.get(questionReadyIndex);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "stuPaperKaoshi";
	}
	/**
	 * get/set ����
	 */
	public List<paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<paper> paperlist) {
		this.paperlist = paperlist;
	}
	public paper getPa() {
		return pa;
	}
	public void setPa(paper pa) {
		this.pa = pa;
	}
	public List<Object[]> getList() {
		return list;
	}
	public void setList(List<Object[]> list) {
		this.list = list;
	}
	public Count getC() {
		return c;
	}
	public void setC(Count c) {
		this.c = c;
	}
	public Question getQu() {
		return qu;
	}
	public void setQu(Question qu) {
		this.qu = qu;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public List<Object[]> getSelectlist() {
		return selectlist;
	}
	public void setSelectlist(List<Object[]> selectlist) {
		this.selectlist = selectlist;
	}
	public paper getPaper() {
		return paper;
	}
	public void setPaper(paper paper) {
		this.paper = paper;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public Integer getQuestionIndex() {
		return questionIndex;
	}
	public void setQuestionIndex(Integer questionIndex) {
		this.questionIndex = questionIndex;
	}
	public Integer getQuestionReadyIndex() {
		return questionReadyIndex;
	}
	public void setQuestionReadyIndex(Integer questionReadyIndex) {
		this.questionReadyIndex = questionReadyIndex;
	}
	
}
