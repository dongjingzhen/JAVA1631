package action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import beans.Classes;
import beans.paper;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.PaperDAO;
import dao.StudentDAO;

public class GoThetestAction implements Action {
	private Classes classes;
	private List<Object[]> clist;
	private int pid;
	private int cid;
	private List<paper> selectPaper;
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String classes(){
		PaperDAO dao =new PaperDAO();
		clist = dao.calsses();
		return SUCCESS;
		
	}
	
	public String selectPaper(){
		StudentDAO dao = new StudentDAO();
		selectPaper = dao.selectPaper();
		return "selectPaper";
	}
	
	public String insertClass(){
//		HttpServletRequest request = ServletActionContext.getRequest();
//		cid =  Integer.parseInt(request.getParameter("cid"));
//		pid =  Integer.parseInt(request.getParameter("pid"));
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Classes classes  =(Classes) session.get(Classes.class, cid);
		paper paper = (paper)session.get(paper.class, pid);
		System.out.println(cid+pid);
		classes.getPapers().add(paper);
		session.saveOrUpdate(classes);
		
		PaperDAO dao = new PaperDAO();
		dao.update(pid);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "insertClass";
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public List<Object[]> getClist() {
		return clist;
	}
	public void setClist(List<Object[]> clist) {
		this.clist = clist;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public List<paper> getSelectPaper() {
		return selectPaper;
	}
	public void setSelectPaper(List<paper> selectPaper) {
		this.selectPaper = selectPaper;
	}
	
	
}
