package action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Teachers;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class teacherAction implements Action {
	private List<Teachers> LieBioList;//�б��{�õ�list
	public List<Teachers> getLieBioList() {
		return LieBioList;
	}
	public void setLieBioList(List<Teachers> lieBioList) {
		LieBioList = lieBioList;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//�̎��б�
	public String teacherSelect(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		LieBioList = session.createCriteria(Teachers.class).list();
		
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
	}

}
