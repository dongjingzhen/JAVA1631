package action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;



import bean.Question;
import bean.Num;
import bean.Paper;
import bean.Classes;
import bean.Student;
import bean.Subjects;
import bean.Teachers;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class paperAction implements Action {
	
	
	private Num num;
	private Paper paper;
	private Subjects subject;
	private Classes classes;
	List<Paper> paperlist = new ArrayList<Paper>();
	List<Subjects> subjectlist = new ArrayList<Subjects>();
	private Set<Question> questionSet = new HashSet<Question>();
	private List<Classes> classeslist = new ArrayList<Classes>();
	
	
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//�Ծ��б�
    public String paperList(){
    	Session session = HibernateSessionFactory.getSession();
        Transaction transaction = session.beginTransaction();
        paperlist = session.createQuery("from Paper").list();
        for (Paper paper : paperlist) {
    		Set<Classes> s =paper.getClasses();
    		for (Classes classes : s) {
    			System.out.println(classes.getClassName());
    		}
    		}
        
        System.out.println(111111111+""+paperlist);
        transaction.commit();	 
		HibernateSessionFactory.closeSession();
		return "list";	
    }
  //
    public String showAddPaper(){
    	Session session = HibernateSessionFactory.getSession();
        Transaction transaction = session.beginTransaction();
        Criteria criteria =session.createCriteria(Subjects.class);
        if(subject!=null){
			if(subject.getDirection()!=null && !subject.getDirection().equals("0")){
				criteria.add(Restrictions.eq("direction",subject.getDirection()));
			}
			if(subject.getStage()!=null && !subject.getStage().equals("0")){
				criteria.add(Restrictions.eq("stage", subject.getStage()));
			}
		}
        subjectlist=criteria.list();
        transaction.commit();
		HibernateSessionFactory.closeSession();
		return SUCCESS;
    	
    	
    }
  //������
	public String createPa(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		String sql = 
			"select top "+num.getDanj()+" qid,newId() from question where difficulty='��' and kind='��ѡ' and subjectId = '"+paper.getSubjectName()
			+"' union all "+
			"select top "+num.getDany()+" qid,newId() from question where difficulty='һ��' and kind='��ѡ' and subjectId = '"+paper.getSubjectName()
			+"' union all "+
			"select top "+num.getDank()+" qid,newId() from question where difficulty='����' and kind='��ѡ' and subjectId = '"+paper.getSubjectName()
			+"' union all "+
			"select top "+num.getDuoj()+" qid,newId() from question where difficulty='��' and kind='��ѡ' and subjectId = '"+paper.getSubjectName()
			+"' union all "+
			"select top "+num.getDuoy()+" qid,newId() from question where difficulty='һ��' and kind='��ѡ' and subjectId = '"+paper.getSubjectName()
			+"' union all "+
			"select top "+num.getDuok()+" qid,newId() from question where difficulty='����' and kind='��ѡ' and subjectId = '"+paper.getSubjectName()
			+"' order by newId() ";
			List<Object[]> questions=session.createSQLQuery(sql).list();
			
			for (Object[] paper2 : questions) {
				Question question = (Question) session.get(Question.class,(Serializable)paper2[0]);
				paper.getQuestion().add(question);
			}
	        paper.setQnumber(paper.getQuestion().size());
	        session.save(paper);
		
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
	}
	//�鿴�Ծ�
	public String Seepaper(){
		Session session = HibernateSessionFactory.getSession();  
		Transaction transaction = session.beginTransaction();
		
		Paper pp = (Paper)session.get(Paper.class, paper.getPid());
		questionSet = pp.getQuestion();
		
		System.out.println(2222222+""+questionSet);
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
		
	}
	//ѡ���԰༶
	public String choosepaper(){
		Session session = HibernateSessionFactory.getSession();  
		Transaction transaction = session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Classes.class);
		if(classes!=null){
			if(classes.getClassName()!=null && !classes.getClassName().equals("0")){
				criteria.add(Restrictions.eq("className",classes.getClassName()));
			}
		}
		classeslist=criteria.list();
		System.out.println(33333333+""+classeslist.toString());
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
	}
	public String startpaper(){
		Session session = HibernateSessionFactory.getSession();  
		Transaction transaction = session.beginTransaction();
		Paper parper1 = (Paper) session.get(Paper.class, paper.getPid());
		Classes cc=(Classes)session.get(Classes.class, classes.getId());
		
		String hql = "select s from Student s where classId="+classes.getId();
		
		Query query = session.createQuery(hql);
		
		List<Student> list = query.list();
		for (Student students : list) {
			parper1.getStudent().add(students);
		}
		
		parper1.setTestTime(paper.getTestTime());
		parper1.setClassName(cc.getClassName());
		parper1.setState("0");
		session.update(parper1);
		transaction.commit();
		return SUCCESS;
	}
	
	public Num getNum() {
		return num;
	}
	public void setNum(Num num) {
		this.num = num;
	}
	public Subjects getSubject() {
		return subject;
	}
	public void setSubject(Subjects subject) {
		this.subject = subject;
	}
	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public List<Subjects> getSubjectlist() {
		return subjectlist;
	}
	public void setSubjectlist(List<Subjects> subjectlist) {
		this.subjectlist = subjectlist;
	}
	public Set<Question> getQuestionSet() {
		return questionSet;
	}
	public void setQuestionSet(Set<Question> questionSet) {
		this.questionSet = questionSet;
	}
	public List<Classes> getClasseslist() {
		return classeslist;
	}
	public void setClasseslist(List<Classes> classeslist) {
		this.classeslist = classeslist;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
    
}
