package action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;



import bean.Student;
import bean.Teachers;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class studentAction implements Action{
	private List<Student> students;
	
	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//�̎��б�
	public String allStudent(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		students = session.createCriteria(Student.class).list();
		
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
	}
}
