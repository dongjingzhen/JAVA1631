package action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Login;
import bean.Teachers;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class loginAction implements Action {
	private Login loginCZ;//����loginҳ�洫����ֵ
	private String name;//login����
	private String pwd;//login����
	private int role;//����loginҳ�����������value
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//��¼
	public String Login(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		switch (role) {
		case 1:
			return SUCCESS;
		case 2:
			List<Teachers> teacherList = session.createCriteria(Teachers.class).list();
			for (Teachers teachers : teacherList) {
				if (teachers.getTaccount().equals(name) && teachers.getTpwd().equals(pwd)) {
					return "index2";
				}
			}
		case 3:
			List<Login> loginList = session.createCriteria(Login.class).list();
			for (Login object : loginList) {
				if (object.getAname().equals(name) && object.getApwd().equals(pwd)) {
					return "index3";
					
				}
			}
		}
		// ��ʼ����
		transaction.commit();
		return "worry";
	}
	
	
	
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Login getLoginCZ() {
		return loginCZ;
	}
	public void setLoginCZ(Login loginCZ) {
		this.loginCZ = loginCZ;
	}
}
