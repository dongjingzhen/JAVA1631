package bean;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import bean.Classes;

public class Paper {
	private int pid;//�Ծ�id
	private String subjectName;//��Ŀ����
	private String kind;//��ѡ���߶�ѡ
	private String title;//���Ա���
	private String className;//�༶����
	private Date testTime;//����ʱ��
	private int testHour;//�ܿ���ʱ��
	private String totalScore;//�ܷ���
	private int qnumber;//����Ŀ
	private String state;//�Ծ�״̬
	private Set<Question> question = new HashSet<Question>();
	private Set<Student> student = new HashSet<Student>();
	private Set<Classes> classes = new HashSet<Classes>();
	public Set<Classes> getClasses() {
		return classes;
	}

	public void setClasses(Set<Classes> classes) {
		this.classes = classes;
	}
	
	
	
	public Set<Student> getStudent() {
		return student;
	}
	public void setStudent(Set<Student> student) {
		this.student = student;
	}
	public Set<Question> getQuestion() {
		return question;
	}
	public void setQuestion(Set<Question> question) {
		this.question = question;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Date getTestTime() {
		return testTime;
	}
	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}
	public int getTestHour() {
		return testHour;
	}
	public void setTestHour(int testHour) {
		this.testHour = testHour;
	}
	public String getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(String totalScore) {
		this.totalScore = totalScore;
	}
	public int getQnumber() {
		return qnumber;
	}
	public void setQnumber(int qnumber) {
		this.qnumber = qnumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Paper [className=" + className + ", kind=" + kind + ", pid="
				+ pid + ", qnumber=" + qnumber + ", state=" + state
				+ ", subjectName=" + subjectName + ", testHour=" + testHour
				+ ", testTime=" + testTime + ", title=" + title
				+ ", totalScore=" + totalScore + "]";
	}
	
}
