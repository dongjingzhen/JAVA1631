package bean;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Subjects {
	private int id;//��Ŀid
	private String direction;//�Ͷ�����
	private String stage;//�׶�
	private String subjectId;//��Ŀ����
	private Set<Question> question = new HashSet<Question>();
	private List<Object[]> object = new ArrayList<Object[]>() ;
	
	public List<Object[]> getObject() {
		return object;
	}
	public void setObject(List<Object[]> object) {
		this.object = object;
	}
	public Set<Question> getQuestion() {
		return question;
	}
	public void setQuestion(Set<Question> question) {
		this.question = question;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	
	
	
	

}
