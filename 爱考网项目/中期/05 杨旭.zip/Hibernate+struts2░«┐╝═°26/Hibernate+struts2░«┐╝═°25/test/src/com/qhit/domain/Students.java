package com.qhit.domain;

public class Students {

	private int id;
	private String stuNo;
	private String stuPwd;
	private String classId;
	private String stuName;
	private String stuSex;
	private String stuTelphone;
	private String paretPhone;
	private String stubrithday;
	private String stuProvide;
	private String stuMajor;
	private String stuParent;
	private String stuDrom;
	private String stuDromNO;
	private String basicSituation;
	private String educational;
	private String guardian;
	private String address;
	private String city;
	private String studyDirection;
	private String image;
	private String political;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStuNo() {
		return stuNo;
	}
	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}
	public String getStuPwd() {
		return stuPwd;
	}
	public void setStuPwd(String stuPwd) {
		this.stuPwd = stuPwd;
	}
	public String getClassId() {
		return classId;
	}
	public void setClassId(String classId) {
		this.classId = classId;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuSex() {
		return stuSex;
	}
	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}
	public String getStuTelphone() {
		return stuTelphone;
	}
	public void setStuTelphone(String stuTelphone) {
		this.stuTelphone = stuTelphone;
	}
	public String getParetPhone() {
		return paretPhone;
	}
	public void setParetPhone(String paretPhone) {
		this.paretPhone = paretPhone;
	}
	public String getStubrithday() {
		return stubrithday;
	}
	public void setStubrithday(String stubrithday) {
		this.stubrithday = stubrithday;
	}
	public String getStuProvide() {
		return stuProvide;
	}
	public void setStuProvide(String stuProvide) {
		this.stuProvide = stuProvide;
	}
	public String getStuMajor() {
		return stuMajor;
	}
	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}
	public String getStuParent() {
		return stuParent;
	}
	public void setStuParent(String stuParent) {
		this.stuParent = stuParent;
	}
	public String getStuDrom() {
		return stuDrom;
	}
	public void setStuDrom(String stuDrom) {
		this.stuDrom = stuDrom;
	}
	public String getStuDromNO() {
		return stuDromNO;
	}
	public void setStuDromNO(String stuDromNO) {
		this.stuDromNO = stuDromNO;
	}
	public String getBasicSituation() {
		return basicSituation;
	}
	public void setBasicSituation(String basicSituation) {
		this.basicSituation = basicSituation;
	}
	public String getEducational() {
		return educational;
	}
	public void setEducational(String educational) {
		this.educational = educational;
	}
	public String getGuardian() {
		return guardian;
	}
	public void setGuardian(String guardian) {
		this.guardian = guardian;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStudyDirection() {
		return studyDirection;
	}
	public void setStudyDirection(String studyDirection) {
		this.studyDirection = studyDirection;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getPolitical() {
		return political;
	}
	public void setPolitical(String political) {
		this.political = political;
	}
	
	
	
}
