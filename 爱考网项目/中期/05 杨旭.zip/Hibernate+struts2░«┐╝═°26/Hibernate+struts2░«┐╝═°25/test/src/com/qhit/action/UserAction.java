package com.qhit.action;

import java.util.Date;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;

import com.qhit.domain.Admin;
import com.qhit.domain.Classes;
import com.qhit.domain.Paper;
import com.qhit.domain.Question;
import com.qhit.domain.Students;
import com.qhit.domain.Teacher;

public class UserAction implements Action{

	private Admin user;
	
	private String role;
	
	
	
	public Admin getUser() {
		return user;
	}

	public void setUser(Admin user) {
		this.user = user;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String login()
	{

		String result ="input";
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		List<Admin> list =session.createCriteria(Admin.class).list();
		for (Admin users : list) {
			if (users.getName().equals(user.getName()) && users.getPwd().equals(user.getPwd())) {
				result = "index";
			}
		}
		transaction.commit();
		
		HibernateSessionFactory.closeSession();

		return result;

	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();

		Admin u = new Admin();
		u.setName("admin");
		u.setPwd("123");
		session.save(u);

		Teacher t = new Teacher();
		t.setTaccount("2017122201");
		t.setTpwd("123");
		t.setTname("张三");
		t.setTsex("男");
		t.setTbirthday("1986-11-11");
		t.setTeducation("本科");
		t.setTtelphone("1477411471");
		t.setTjop("班主任");
		t.setRemarks("备注");
		session.save(t);
		Teacher te = new Teacher();
		te.setTaccount("2017122401");
		te.setTpwd("123");
		te.setTname("李四");
		te.setTsex("男");
		te.setTbirthday("1986-11-11");
		te.setTeducation("本科");
		te.setTtelphone("1477411471");
		te.setTjop("讲师");
		te.setRemarks("备注");
		session.save(te);
		
		Classes c = new Classes();
		c.setClassNo("G1T01");
		c.setClassName("Java1631");
		c.setCreateTime("2017-12-24");
		c.setDirection("SCCE");
		c.setHeadteacher("张三");
		c.setLecturer("李四");
		c.setState("启用");
		session.save(c);
		
		Students s = new Students();
		s.setStuNo("2017122401");
		s.setStuPwd("123");
		s.setStuName("李狗蛋");
		s.setClassId("1");
		s.setStuSex("男");
		s.setStuTelphone("1477417412");
		s.setParetPhone("1477417412");
		s.setStubrithday("11-11");
		s.setStuProvide("");
		s.setStuMajor("Java");
		s.setStuParent("");
		s.setStuDrom("boy01");
		s.setStuDromNO("101");
		s.setBasicSituation("");
		s.setEducational("");
		s.setGuardian("李前进");
		s.setAddress("河南洛阳");
		s.setCity("洛阳");
		s.setStudyDirection("Java");
		s.setImage("");
		s.setPolitical("共青团员");
		
		Question q = new Question();
		q.setKind("单选题");
		q.setContent("今晚的月色真美！");
		q.setOptionA("A.恩。很美");
		q.setOptionB("B.还好吧");
		q.setOptionC("C.骗人");
		q.setOptionD("D.夏目漱石");
		q.setAnswer("A");
		q.setDifficulty("困难");
		q.setSubjectid("CTB");
		q.setChapter("T01");
		q.setQuestionType("笔试");
		
		session.save(q);
		
		Question q1 = new Question();
		q1.setKind("单选题");
		q1.setContent("今晚的月色真美！");
		q1.setOptionA("A.恩。很美");
		q1.setOptionB("B.还好吧");
		q1.setOptionC("C.骗人");
		q1.setOptionD("D.夏目漱石");
		q1.setAnswer("A");
		q1.setDifficulty("简单");
		q1.setSubjectid("CTB");
		q1.setChapter("T01");
		q1.setQuestionType("笔试");
		
		session.save(q1);
		
		Question q2 = new Question();
		q2.setKind("单选题");
		q2.setContent("今晚的月色真美！");
		q2.setOptionA("A.恩。很美");
		q2.setOptionB("B.还好吧");
		q2.setOptionC("C.骗人");
		q2.setOptionD("D.夏目漱石");
		q2.setAnswer("A");
		q2.setDifficulty("简单");
		q2.setSubjectid("CTB");
		q2.setChapter("T01");
		q2.setQuestionType("笔试");
		
		session.save(q2);
		Question q3 = new Question();
		q3.setKind("单选题");
		q3.setContent("今晚的月色真美！");
		q3.setOptionA("A.恩。很美");
		q3.setOptionB("B.还好吧");
		q3.setOptionC("C.骗人");
		q3.setOptionD("D.夏目漱石");
		q3.setAnswer("A");
		q3.setDifficulty("普通");
		q3.setSubjectid("CTB");
		q3.setChapter("T01");
		q3.setQuestionType("笔试");
		
		session.save(q3);
		
		Question q4 = new Question();
		q4.setKind("单选题");
		q4.setContent("今晚的月色真美！");
		q4.setOptionA("A.恩。很美");
		q4.setOptionB("B.还好吧");
		q4.setOptionC("C.骗人");
		q4.setOptionD("D.夏目漱石");
		q4.setAnswer("A");
		q4.setDifficulty("简单");
		q4.setSubjectid("CTB");
		q4.setChapter("T01");
		q4.setQuestionType("笔试");
		
		session.save(q4);
		
		Paper p = new Paper();
		p.setKind("单选题");
		p.setTitle("标题");
		p.setSubjectid("TBC");
		p.setChapter("G1");
		p.setClassNo("G25G01");
		p.setState("未开考");
		
		session.save(p);
		
		
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
	}
	
	

}
