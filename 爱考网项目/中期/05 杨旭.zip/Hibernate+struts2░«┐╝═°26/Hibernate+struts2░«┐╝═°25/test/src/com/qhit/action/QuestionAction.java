package com.qhit.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.domain.Question;

public class QuestionAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	private List<Question> list;

	private Question question;
	
	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public List<Question> getList() {
		return list;
	}

	public void setList(List<Question> list) {
		this.list = list;
	}
	
	public String update(){
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		Question q  = (Question) session.get(Question.class, question.getQid());
		q.setKind(question.getKind());
		q.setContent(question.getContent());
		q.setOptionA(question.getOptionA());
		q.setOptionB(question.getOptionB());
		q.setOptionC(question.getOptionC());
		q.setOptionD(question.getOptionD());
		q.setAnswer(question.getAnswer());
		q.setDifficulty(question.getDifficulty());
		q.setSubjectid(question.getSubjectid());
		q.setChapter(question.getChapter());
		q.setQuestionType(question.getQuestionType());
		
		session.update(q);
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "input";
	}
	
	public String intoUpdate(){
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		question  = (Question) session.get(Question.class, question.getQid());
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		
		return "list";
	}
	
	
	public String add(){
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		Question q = new Question();
		q.setKind(question.getKind());
		q.setContent(question.getContent());
		q.setOptionA(question.getOptionA());
		q.setOptionB(question.getOptionB());
		q.setOptionC(question.getOptionC());
		q.setOptionD(question.getOptionD());
		q.setAnswer(question.getAnswer());
		q.setDifficulty(question.getDifficulty());
		q.setSubjectid(question.getSubjectid());
		q.setChapter(question.getChapter());
		q.setQuestionType(question.getQuestionType());
		
		session.save(q);
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "input";
	}
	
	
	
	public String delete(){
		
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		Question q =(Question) session.get(Question.class, question.getQid());
		session.delete(q);
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		
		
		return "delete";
	}
	
	public String questionList(){
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		list  = session.createCriteria(Question.class).list();
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		
		return "list";
	}
	
	public String list(){
		
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		list = session.createSQLQuery("select subjectId,count(questionType) as typeSize,questionType from question group by subjectId,questionType order by subjectId ").list();

		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		
		return "list";
	}
	
	public static void main(String[] args) {
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		List<Object[]> list = session.createSQLQuery("select subjectId,count(questionType) as typeSize,questionType from question group by subjectId,questionType order by subjectId ").list();
		for (Object[] objects : list) {
			System.out.println(objects[0]+" "+objects[1]+" "+objects[2]);
		}
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
	}
	
}
