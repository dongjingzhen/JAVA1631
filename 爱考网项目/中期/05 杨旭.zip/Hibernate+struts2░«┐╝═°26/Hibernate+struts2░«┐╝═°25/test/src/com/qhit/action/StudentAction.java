package com.qhit.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.domain.Classes;
import com.qhit.domain.Students;
import com.sun.org.apache.regexp.internal.recompile;

public class StudentAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	private List list;
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	
	 public String list(){
		 
			Session session = HibernateSessionFactory.getSession();
			
			Transaction transaction = session.beginTransaction();
			
			list  = session.createCriteria(Students.class).list();
			
			transaction.commit();
			
			HibernateSessionFactory.closeSession();
		 return "list";
	 }
}
