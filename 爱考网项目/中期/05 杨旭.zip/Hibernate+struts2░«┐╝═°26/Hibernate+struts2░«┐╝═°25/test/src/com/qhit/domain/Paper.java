package com.qhit.domain;

import java.util.HashSet;
import java.util.Set;

public class Paper {

	private int pid;
	private String kind;//类型
	private String title;//标题
	private String subjectid;//主题
	private String chapter;//第几章
	private String classNo;
	private String state;//状态
	
	private String testTime;//测试时间
	private String testHour;//考试时长
	private String totalScore;//一共多少分
	private String qnumber;//数
	
	private Set<Question> ques =new HashSet<Question>() ;
	

	public Set<Question> getQues() {
		return ques;
	}
	public void setQues(Set<Question> ques) {
		this.ques = ques;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getTestTime() {
		return testTime;
	}
	public void setTestTime(String testTime) {
		this.testTime = testTime;
	}
	public String getTestHour() {
		return testHour;
	}
	public void setTestHour(String testHour) {
		this.testHour = testHour;
	}
	public String getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(String totalScore) {
		this.totalScore = totalScore;
	}
	public String getQnumber() {
		return qnumber;
	}
	public void setQnumber(String qnumber) {
		this.qnumber = qnumber;
	}

	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubjectid() {
		return subjectid;
	}
	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}
	public String getChapter() {
		return chapter;
	}
	public void setChapter(String chapter) {
		this.chapter = chapter;
	}
	public String getClassNo() {
		return classNo;
	}
	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
