package dao;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;
import domain.Question;


public class QuestionDao {
	@SuppressWarnings("unchecked")
	public List<Question> list()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Question> questionList =(List<Question>) session.createCriteria(Question.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		
		return questionList;
		
	}
	

}
