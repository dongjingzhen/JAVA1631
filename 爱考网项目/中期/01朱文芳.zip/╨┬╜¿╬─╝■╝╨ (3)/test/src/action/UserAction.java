package action;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;

import domain.Admin;

public class UserAction implements Action{

	private Admin user;
	
	private String role;
	
	
	
	public Admin getUser() {
		return user;
	}

	public void setUser(Admin user) {
		this.user = user;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String login()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		//利用数据库查询登录
		transaction.commit();
		HibernateSessionFactory.closeSession();
		String result ="index";
		if("admin".equals(role))
		{
			String sql = "select * from admin";
			
		}
		
		if("student".equals(role))
		{
			String sql = "select *from student ";
			
		}
		
		if("teacher".equals(role))
		{
			String sql = "select *from teacher";
			
		}
		ServletActionContext.getRequest().getSession().setAttribute("user", user);
		return result;
		
		
		
	}
	
	

}
