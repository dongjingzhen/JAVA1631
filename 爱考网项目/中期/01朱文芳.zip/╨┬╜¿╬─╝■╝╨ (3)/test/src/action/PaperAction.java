package action;

import com.opensymphony.xwork2.Action;

public class PaperAction implements Action{

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String list() throws Exception{ 
		
		return "li";
		}
		
}
