package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;

import dao.TeacherDAO;
import domain.Question;
import domain.Subject;


public class QuestionAction implements Action{
	private List<Question> questionList;
	private List<Subject> subjectList = new ArrayList<Subject>();
	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	@Override
	public String execute() throws Exception {
		
		
		return "sql";
	}
	public String Question() {
	       Session session=HibernateSessionFactory.getSession();
		   Transaction transaction = session.beginTransaction();
		   //查询所有的object
		   subjectList=session.createCriteria(Subject.class).list();
		   for (Subject s : subjectList) {
			System.out.println(s.getDirection());
		}
		   String sql="select kind,count(kind),subjectid from question group by kind, subjectid";
		   System.out.println();
		   List<Object[]> questionObj=session.createSQLQuery(sql).list(); 
		   for (Object[] obj : questionObj) {
			 for (Subject sub : subjectList) {
				String a= (String)obj[2];
				
				if (a.equals(sub.getSubjectId())) {
					sub.getObjsub().add(obj);
				}
				
			}
			 System.out.println(questionObj.toString());
		}
		   for (Subject sub : subjectList) {
			Object[] ob = {"机",0,sub.getSubjectId()};
			Object[] obj= {"笔",0,sub.getSubjectId()};
			if (sub.getObjsub().size()==1) {
				Object[] ct = sub.getObjsub().get(0);
				String a = (String)ct[2];
				if (a.equals("机")) {
					sub.getObjsub().add(obj);
					
				}else {
					sub.getObjsub().add(ob);
					
				}
				
			}else if (sub.getObjsub().size()==0) {
				sub.getObjsub().add(ob);
				sub.getObjsub().add(obj);
				
			}
			System.out.println(sub);
		}
		return "quest";
	}

	public List<Subject> getSubjectList() {
		return subjectList;
	}

	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}
}