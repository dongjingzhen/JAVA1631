package domain;

import java.util.ArrayList;
import java.util.List;

public class Subject {
	private int id;
	private String direction;
	private String stage;
	private String subjectId;
	private List<Object[]> objsub=new ArrayList<Object[]>();
	public List<Object[]> getObjsub() {
		return objsub;
	}
	public void setObjsub(List<Object[]> objsub) {
		this.objsub = objsub;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	

}
