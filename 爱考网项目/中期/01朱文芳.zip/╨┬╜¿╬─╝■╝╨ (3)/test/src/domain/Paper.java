package domain;

import java.sql.Date;

public class Paper {
	private int pid;
	
	private String subjectName;
	private String kind;
	private String title;
	private String className;
	private Date testTime;
	private int testHour;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Date getTestTime() {
		return testTime;
	}
	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}
	public int getTestHour() {
		return testHour;
	}
	public void setTestHour(int testHour) {
		this.testHour = testHour;
	}
	

}
