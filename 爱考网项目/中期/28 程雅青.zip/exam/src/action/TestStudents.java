package action;

import java.util.List;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Paper;
import bean.Question;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class TestStudents  implements Action{
	private int id;
	private List<Question> questionLi;
	
	

	public List<Question> getQuestionLi() {
		return questionLi;
	}



	public void setQuestionLi(List<Question> questionLi) {
		this.questionLi = questionLi;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public String stu3(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		System.out.println(id);
		 
		String hql="select q from Paper p join p.question q where p.pid="+id;
		Query query=(Query)session.createQuery(hql);
		questionLi =query.list();
		transaction.commit();
		return "stu3";
		
		
		
	}	
		
	
	

}
