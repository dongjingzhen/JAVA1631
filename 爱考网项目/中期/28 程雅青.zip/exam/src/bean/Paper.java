package bean;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Paper {
	
private Set<Students> students = new HashSet<Students>();
	
public Set<Students> getStudents() {
		return students;
	}
	public void setStudents(Set<Students> students) {
		this.students = students;
	}
	//	private Set<Class> classs =new HashSet<Class>();
//	
//	
//	public Set<Class> getClasss() {
//		return classs;
//	}
//	public void setClasss(Set<Class> classs) {
//		this.classs = classs;
//	}
	private Set<Question> question=new HashSet<Question>();
	public Set<Question> getQuestion() {
		return question;
	}
	public void setQuestion(Set<Question> question) {
		this.question = question;
	}
	private int pid;  // �Ծ���pid
	private String subjectName; //���Ե�ѧ��
	private String kind;// ���Եķ���
	private String title;//���Եı���
	private String className;// ���Եİ༶
	private Date testTime;// ���Ե�ʱ��
	private int testHour;//  �ܿ��Ե�ʱ���
	private String totalScore;// �Ծ��ܷ�
	private int qnumber;// ��Ŀ����
	private String state;//  ״̬
	
	@Override
	public String toString() {
		return "Paper [className=" + className+ 
				 ", kind=" + kind + ", pid=" + pid + ", qnumber=" + qnumber
				+ ", question=" + question + ", state=" + state
				+ ", subjectName=" + subjectName + ", testHour=" + testHour
				+ ", testTime=" + testTime + ", title=" + title
				+ ", totalScore=" + totalScore + "]";
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Date getTestTime() {
		return testTime;
	}
	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}
	public int getTestHour() {
		return testHour;
	}
	public void setTestHour(int testHour) {
		this.testHour = testHour;
	}
	public String getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(String totalScore) {
		this.totalScore = totalScore;
	}
	public int getQnumber() {
		return qnumber;
	}
	public void setQnumber(int qnumber) {
		this.qnumber = qnumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	

}
