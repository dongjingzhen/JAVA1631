package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Paper;
import bean.Teacher;
import bean.Class;
public class testDao {
	
	
	
	public List<Paper> list(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		 List<Paper> paperList =session.createCriteria(Paper.class).list();
		 
		 transaction.commit();
		
		return paperList ;
		
		
	}
	
	public List<Class> namelist(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		 List<Class> nameList =session.createCriteria(Class.class).list();
		 
		 transaction.commit();
			HibernateSessionFactory.closeSession();
		return nameList;
		
		
	}

}
