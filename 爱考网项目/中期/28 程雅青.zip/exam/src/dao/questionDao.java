package dao;

import java.util.List;



import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Question;

public class questionDao {
	public List<Question> list(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String hql="SELECT new list(subjectId, count(kindType),kindType) from Question group by subjectId ,kindType order by subjectId,kindType";
		Query query=(Query)session.createQuery(hql);
		List<Question> questionList=query.list();
		return questionList;
		
		
		
	}
	
	
		
		
		
	
	

}
