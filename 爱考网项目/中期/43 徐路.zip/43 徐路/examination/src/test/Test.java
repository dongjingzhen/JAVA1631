package test;

import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;
import dao.PaperDAO;
import dao.QuestionDAO;
import beans.HibernateUtils;
import beans.Question;
import beans.paper;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
//			save();
//			ceshi();
//			list();
//			PaperDAO dao = new PaperDAO();
//			List<paper> paperlist = dao.list();
//			for (paper a : paperlist) {
//				System.out.println(a.getClassName());
//			}
			dajuan();
		
	}

	private static void dajuan() {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper p = new paper();
		p.setClassName("java");
		int id = 0;
		String sql="select top 5 qid, newId() from question where difficulty= '��'"+  
				"union "+"select top 5 qid, newId() from question where difficulty= '�е�' order by newid()";
		List<Object> qidlist = session.createSQLQuery(sql).list();
		for (Object q : qidlist) {
//		Question question = (Question)session.get(Question.class, (Serializable) q);
//		question.getPapers().add(p);
   		}
		session.save(p);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private static void list() {
		// TODO Auto-generated method stub
		String hql = "SELECT q FROM Question q  WHERE  q.types LIKE :quname ";
		List<Question> newlist = HibernateUtils.getSession().createQuery(hql).setString("quname","����").list();
		for (Question q : newlist) {
			System.out.println(q.getTypes()+q.getContent());
		}
	}

	private static void ceshi() {
		// TODO Auto-generated method stub
		String hql = "SELECT subject,types,count(types) FROM Question q GROUP BY subject,types";
		List<Object[]> questionList = HibernateUtils.getSession().createQuery(hql).list();
	}

	private static void save() {
		// TODO Auto-generated method stub
		Question q = new Question();
		q.setType("��ѡ");
		q.setContent("���м��������е���");
		q.setOptionA("��");
		q.setOptionB("�̹�");
		q.setOptionC("��");
		q.setOptionD("ɶ�����⣿��");
		q.setDifficulty("��");
		q.setAnswer("D");
		q.setSubject("java");
		q.setTypes("����");
		HibernateUtils.add(q);
		HibernateUtils.getSession().beginTransaction().commit();
	}

}
