package test;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;

import dao.QuestionDAO;
import beans.HibernateUtils;
import beans.Question;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
//			save();
//			ceshi();
//			list();
			QuestionDAO dao = new QuestionDAO();
			List<Question> newlist = dao.questionlist("����");
			for (Question a : newlist) {
				System.out.println(a.getContent());
			}
	}

	private static void list() {
		// TODO Auto-generated method stub
		String hql = "SELECT q FROM Question q  WHERE  q.types LIKE :quname ";
		List<Question> newlist = HibernateUtils.getSession().createQuery(hql).setString("quname","����").list();
		for (Question q : newlist) {
			System.out.println(q.getTypes()+q.getContent());
		}
	}

	private static void ceshi() {
		// TODO Auto-generated method stub
		String hql = "SELECT subject,types,count(types) FROM Question q GROUP BY subject,types";
		List<Object[]> questionList = HibernateUtils.getSession().createQuery(hql).list();
	}

	private static void save() {
		// TODO Auto-generated method stub
		Question q = new Question();
		q.setType("��ѡ");
		q.setContent("���м��������е���");
		q.setOptionA("��");
		q.setOptionB("�̹�");
		q.setOptionC("��");
		q.setOptionD("ɶ�����⣿��");
		q.setDifficulty("��");
		q.setAnswer("D");
		q.setSubject("java");
		q.setTypes("����");
		HibernateUtils.add(q);
		HibernateUtils.getSession().beginTransaction().commit();
	}

}
