package action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;

import beans.HibernateUtils;
import beans.Role;
import beans.UserLogin;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class LoginAction implements Action {
	private String loginName;
	private String loginPwd;
	private String rname;
	private List<Role> roleList;
	private List<UserLogin> userList;
	private UserLogin userLogin;
	private String ceshi;
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String login(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String hql = "SELECT s FROM UserLogin s  WHERE  s.loginName=loginName and s.loginPwd=loginPwd ";
		List<UserLogin> userList = HibernateUtils.getSession().createQuery(hql).list();
		int i = userList.size(); 
		String loginName = request.getParameter("loginName");
		String loginPwd = request.getParameter("loginPwd");
		String rname = request.getParameter("rname");
		System.out.println(loginName+loginPwd+rname);
		System.out.println(i);
			if (i>0) {
				System.out.println("�ж��û���/�����Ƿ���ȷ"+loginName+loginPwd+rname);
				if (rname.equals("gl")) {
					ceshi="GL";
				}
				if (rname.equals("ѧ��")) {
						ceshi="XS";
				}
				if (rname.equals("��ʦ")) {
					ceshi="JS";
				}
			}else {
				return "error";
			}
				
				HibernateUtils.getSession().beginTransaction().commit();
				return ceshi;
	}
	private int lists() {
		// TODO Auto-generated method stub
		String hql = "SELECT s FROM UserLogin s WHERE s.loginName LIKE? ";
		List<UserLogin> userList = HibernateUtils.getSession().createQuery(hql).setString(0,loginName).list();
		int i = userList.size();
		HibernateUtils.getSession().beginTransaction().commit();
		return i;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public List<Role> getRoleList() {
		return roleList;
	}
	public void setRoleList(List<Role> roleList) {
		this.roleList = roleList;
	}
	public List<UserLogin> getUserList() {
		return userList;
	}
	public void setUserList(List<UserLogin> userList) {
		this.userList = userList;
	}
	public UserLogin getUserLogin() {
		return userLogin;
	}
	public void setUserLogin(UserLogin userLogin) {
		this.userLogin = userLogin;
	}
	public String getCeshi() {
		return ceshi;
	}
	public void setCeshi(String ceshi) {
		this.ceshi = ceshi;
	}
}