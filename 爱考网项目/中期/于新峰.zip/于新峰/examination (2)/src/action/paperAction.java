package action;

import java.util.List;

import beans.paper;

import com.opensymphony.xwork2.Action;

import dao.PaperDAO;
public class paperAction implements Action {
	private List<paper> paperlist;
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String paperlist(){
		PaperDAO dao = new PaperDAO();
		paperlist = dao.list();
		return "paperlist";
	}
	
	/**
	 * get/set ����
	 */
	public List<paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<paper> paperlist) {
		this.paperlist = paperlist;
	}
}
