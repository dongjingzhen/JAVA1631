package dao;

import java.util.List;

import beans.HibernateUtils;
import beans.Question;
import beans.paper;

public class PaperDAO {
	public List<paper> list(){
		List<paper> list =(List<paper>) HibernateUtils.getSession().createCriteria(paper.class).list();
		HibernateUtils.getSession().beginTransaction().commit();
		return list;
	}
}
