package yundao;



import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;


import vo.Class;
import vo.Question;
import vo.TestQusertion;

import vo.ThePapers;

public class QuestionesDao {
	//��ѯ�༶������
	public List<Class> selectClassName(){
	
		Session session= HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		List<Class> classList= session.createQuery("from Class").list();
		for (Class class1 : classList) {
			System.out.println(class1.getClass());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return classList;
	}
	//����
	public void addPage_Class(ThePapers thePapers){                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		System.out.println(thePapers.getId());
		Class classes=(Class) session.get(Class.class,1);
		thePapers =(ThePapers) session.get(ThePapers.class, thePapers.getId());
		thePapers.getClassesList().add(classes);
		transaction.commit();
	}
	
	public void addThePapers(TestQusertion testQusertion,ThePapers thePapers,String duoxuan,int danJdan,int danKnan,
			int duoJdan,int duoKnan){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String hQl=" select id from (select top "+danJdan+" id from dbo.t_TestQusertion where" +
				" difficuLty='��' and diJiQi="+testQusertion.getDiJiQi()+" and keMu='"+testQusertion.getKeMu()+"' and " +
				" testType='"+testQusertion.getTestType()+"'  and  testTypeJOrB='"+testQusertion.getTestTypeJOrB()+"' order by newid()" +
				" union select top "+danKnan+" id from t_TestQusertion where" +
				" difficuLty='����' and diJiQi="+testQusertion.getDiJiQi()+"  and keMu='"+testQusertion.getKeMu()+"' " +
				" and  testType='"+testQusertion.getTestType()+"' and testTypeJOrB='"+testQusertion.getTestTypeJOrB()+"' order by newid() " +
				"union select top "+duoJdan+" id from dbo.t_TestQusertion where" +
				" difficuLty='��' and diJiQi="+testQusertion.getDiJiQi()+" and keMu='"+testQusertion.getKeMu()+"' and " +
				" testType='"+duoxuan+"'  and  testTypeJOrB='"+testQusertion.getTestTypeJOrB()+"' order by newid()" +
				" union select top "+duoKnan+" id from t_TestQusertion where" +
				" difficuLty='����' and diJiQi="+testQusertion.getDiJiQi()+"  and keMu='"+testQusertion.getKeMu()+"' and " +
				"testType='"+duoxuan+"' and testTypeJOrB='"+testQusertion.getTestTypeJOrB()+"' order by newid())as t";
		List obj=session.createSQLQuery(hQl).list();
		for (Object object : obj) {
			int id=Integer.parseInt( object.toString());
			System.out.println(id);
			TestQusertion tempTestq=(TestQusertion) session.get(TestQusertion.class,id);
			thePapers.getThePaperQusertion().add(tempTestq);
		}
		thePapers.setKeMu(testQusertion.getKeMu());
		session.save(thePapers);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	//ɾ���Ծ�
	public void deleteThePagers(int id){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String hql="from TestQusertion";
		ThePapers thePapers =(ThePapers)session.get(ThePapers.class,id);
		List<TestQusertion> testQusertion = session.createQuery(hql).list();
		for (TestQusertion testQusertion2 : testQusertion) {
			System.out.println(testQusertion2.getId());
			TestQusertion testQusertionq=(TestQusertion) session.get(TestQusertion.class,testQusertion2.getId());
			thePapers.getThePaperQusertion().remove(testQusertionq);
			
		}
		session.flush();
		session.delete(thePapers);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	//��ѯ����
	public List<ThePapers> selectThePapers(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String hql="from ThePapers";
		List<ThePapers> thePapersList=session.createQuery(hql).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return thePapersList;
	}
	//�����Ծ���
	public void addQuestion(TestQusertion testQusertion){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		TestQusertion tempTestQ = new TestQusertion();
		tempTestQ.setContent(testQusertion.getContent());
		tempTestQ.setTestType(testQusertion.getTestType());
		tempTestQ.setOptionA(testQusertion.getOptionA());
		tempTestQ.setOptionB(testQusertion.getOptionB());
		tempTestQ.setOptionC(testQusertion.getOptionC());
		tempTestQ.setOptionD(testQusertion.getOptionD());
		tempTestQ.setAnsWer(testQusertion.getAnsWer());
		tempTestQ.setDifficuLty(testQusertion.getDifficuLty());
		tempTestQ.setTestTypeJOrB(testQusertion.getTestTypeJOrB());
		tempTestQ.setChaPter(testQusertion.getChaPter());
		int id=0;
		String testHql="select q from Questiones q join q.fangXiang f  where q.fewQuest="+testQusertion.getDiJiQi()+" and f.fangName='"+testQusertion.getKeMu()+"'";
		List<Question> QuestionesList= session.createQuery(testHql).list();
//		for (Question questiones : QuestionesList) {
//			id=questiones.getId();
//		}
		for (Question question : QuestionesList) {
			id=question.getId();
		}
		Question questiones = (Question) session.get(Question.class, id);
//		tempTestQ.getQuestiones().getId();
		tempTestQ.setQuestiones(questiones);
		session.save(tempTestQ);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	//�޸���Ŀ
	public void testQ(TestQusertion testQusertion){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		int id =new Integer(ServletActionContext.getRequest().getParameter("cmd"));
		TestQusertion temTestQuers=(TestQusertion)session.get(TestQusertion.class, id);
		temTestQuers.setTestType(testQusertion.getTestType());
		temTestQuers.setContent(testQusertion.getContent());
		temTestQuers.setOptionA(testQusertion.getOptionA());
		temTestQuers.setOptionB(testQusertion.getOptionB());
		temTestQuers.setOptionC(testQusertion.getOptionC());
		temTestQuers.setOptionD(testQusertion.getOptionD());
		temTestQuers.setAnsWer(testQusertion.getAnsWer());
		temTestQuers.setDifficuLty(testQusertion.getDifficuLty());
		temTestQuers.setChaPter(testQusertion.getChaPter());
		session.update(temTestQuers);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	//��ѯ�����Լ�רҵ
	public List<Object[]> QuestionesCount(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		System.out.println("��ѯ�����Լ�רҵ");
		String hql="select t.keMu,c.fewQuest,t.testType,t.testTypeJOrB, count(t) from TestQusertion t join t.questiones c group by t.keMu,c.fewQuest,t.testType,t.testTypeJOrB";
		List<Object[]> liset=session.createQuery(hql).list();
		System.out.println("��ѯ�����Լ�רҵ222");
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return liset;
	}
	//��ѯרҵ�б��Ի��߻���T
	public List<TestQusertion> testQuset(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String keMu=ServletActionContext.getRequest().getParameter("keMu");
		String diJiQi= ServletActionContext.getRequest().getParameter("diJiQi");
		List<TestQusertion> testQuestionesList = new ArrayList<TestQusertion>();
		testQuestionesList=session.createQuery("from TestQusertion t where keMu='"+keMu+"' and diJiQi="+diJiQi+"  ").list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return testQuestionesList;
		}
	//��ѯ������������з���
	public TestQusertion modifySeleQuser(){
		int cmd= new Integer(ServletActionContext.getRequest().getParameter("id"));
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		TestQusertion testQusertion = (TestQusertion)session.get(TestQusertion.class, cmd);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return testQusertion;
	}
}
