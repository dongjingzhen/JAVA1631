package yundao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Class;
import dao.HibernateSessionFactory;

public class ClassDao {
	@SuppressWarnings("unchecked")
	public List<Class> list()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Class> classList =(List<Class>) session.createCriteria(Class.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return classList;
		
	}
}
