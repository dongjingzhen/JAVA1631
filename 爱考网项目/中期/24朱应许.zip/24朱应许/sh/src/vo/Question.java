package vo;

import java.util.ArrayList;
import java.util.List;

public class Question{
 
     private int id;
 	private int fewQuest;//�ڼ���
 	private FangXiang fangXiang;
 	private List<TestQusertion> testQusertionlist= new ArrayList<TestQusertion>();
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public int getFewQuest() {
		return fewQuest;
	}

	public void setFewQuest(int fewQuest) {
		this.fewQuest = fewQuest;
	}

	public FangXiang getFangXiang() {
		return fangXiang;
	}

	public void setFangXiang(FangXiang fangXiang) {
		this.fangXiang = fangXiang;
	}

	public List<TestQusertion> getTestQusertionlist() {
		return testQusertionlist;
	}

	public void setTestQusertionlist(List<TestQusertion> testQusertionlist) {
		this.testQusertionlist = testQusertionlist;
	}

 

}