package vo;

import java.util.ArrayList;
import java.util.List;
// default package



/**
 * Teacher entity. @author MyEclipse Persistence Tools
 */

public class Teacher{


    // Fields    

     private int id;
     private String taccount; //��ʦ���
     private String tpwd;   //����
     private String tname;  //����
     private String tsex;	//�Ա�
     private String tbirthday; //����
     private String teducation; //ѧ��
     private String ttelphone;  //�绰
     private String tjop;  //��λ
     private String remarks;//��ע
 	private List<Class> classList =new ArrayList<Class>();
	private List<Strudent> studentslsit =new ArrayList<Strudent>();
	
	
	

    // Constructors

    public List<Class> getClassList() {
		return classList;
	}

	public void setClassList(List<Class> classList) {
		this.classList = classList;
	}

	public List<Strudent> getStudentslsit() {
		return studentslsit;
	}

	public void setStudentslsit(List<Strudent> studentslsit) {
		this.studentslsit = studentslsit;
	}

	/** default constructor */
//    public Teacher() {
//    }
//
//    
//    /** full constructor */
//    public Teacher(String taccount, String tpwd, String tname, String tsex, String tbirthday, String teducation, String ttelphone, String tjop, String remarks) {
//        this.taccount = taccount;
//        this.tpwd = tpwd;
//        this.tname = tname;
//        this.tsex = tsex;
//        this.tbirthday = tbirthday;
//        this.teducation = teducation;
//        this.ttelphone = ttelphone;
//        this.tjop = tjop;
//        this.remarks = remarks;
//    }

   
    // Property accessors

    public int getId() {
        return this.id;
    }
    
    public void setId(int id) {
        this.id = id;
    }

    public String getTaccount() {
        return this.taccount;
    }
    
    public void setTaccount(String taccount) {
        this.taccount = taccount;
    }

    public String getTpwd() {
        return this.tpwd;
    }
    
    public void setTpwd(String tpwd) {
        this.tpwd = tpwd;
    }

    public String getTname() {
        return this.tname;
    }
    
    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getTsex() {
        return this.tsex;
    }
    
    public void setTsex(String tsex) {
        this.tsex = tsex;
    }

    public String getTbirthday() {
        return this.tbirthday;
    }
    
    public void setTbirthday(String tbirthday) {
        this.tbirthday = tbirthday;
    }

    public String getTeducation() {
        return this.teducation;
    }
    
    public void setTeducation(String teducation) {
        this.teducation = teducation;
    }

    public String getTtelphone() {
        return this.ttelphone;
    }
    
    public void setTtelphone(String ttelphone) {
        this.ttelphone = ttelphone;
    }

    public String getTjop() {
        return this.tjop;
    }
    
    public void setTjop(String tjop) {
        this.tjop = tjop;
    }

    public String getRemarks() {
        return this.remarks;
    }
    
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
   








}