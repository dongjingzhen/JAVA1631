package vo;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
/**
 * ������
 * @author gao
 *
 */ 
public class ThePapers {
	private int id;
	private String paperType;//�Ծ�����
	private String keMu;
	private String tiTtle;//����
	private int longExam;//����ʱ��
	private Date dateTime;//��ʼʱ��
	private int  totalScore;//�ܷ�
	private int totaZongT;//������
	private double  ccorePer;//ÿ�����
	private String examinState;//����״̬�������У����Խ�����δ����
	private Set<TestQusertion> thePaperQusertion = new HashSet<TestQusertion>();
	private Set<Class> classesList = new HashSet<Class>();
	
	public Set<Class> getClassesList() {
		return classesList;
	}
	public void setClassesList(Set<Class> classesList) {
		this.classesList = classesList;
	}
	public int getTotaZongT() {
		return totaZongT;
	}
	public void setTotaZongT(int totaZongT) {
		this.totaZongT = totaZongT;
	}
	public double getCcorePer() {
		return ccorePer;
	}
	public void setCcorePer(double ccorePer) {
		this.ccorePer = ccorePer;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public Set<TestQusertion> getThePaperQusertion() {
		return thePaperQusertion;
	}
	public void setThePaperQusertion(Set<TestQusertion> thePaperQusertion) {
		this.thePaperQusertion = thePaperQusertion;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getKeMu() {
		return keMu;
	}
	public void setKeMu(String keMu) {
		this.keMu = keMu;
	}
	public String getPaperType() {
		return paperType;
	}
	public void setPaperType(String paperType) {
		this.paperType = paperType;
	}
	public String getTiTtle() {
		return tiTtle;
	}
	public void setTiTtle(String tiTtle) {
		this.tiTtle = tiTtle;
	}
	
	public int getLongExam() {
		return longExam;
	}
	public void setLongExam(int longExam) {
		this.longExam = longExam;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public String getExaminState() {
		return examinState;
	}
	public void setExaminState(String examinState) {
		this.examinState = examinState;
	}
	
	
}
