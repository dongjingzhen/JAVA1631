package action;

import java.util.List;


import vo.Strudent;
import yundao.Strudentdao;
import yundao.TeacherDao;




import com.opensymphony.xwork2.Action;

public class StrudentAction implements Action{
	private List<Strudent> strudentList;
	public List<Strudent> getStrudentList() {
		return strudentList;
	}
	public void setStrudentList(List<Strudent> strudentList) {
		this.strudentList = strudentList;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String list() throws Exception {
		
		
		//TeacherDao teacherDao = new TeacherDao();
		Strudentdao strudentdao = new Strudentdao();
		//strudentList =teacherDao.list();
		strudentList = strudentdao.list();
		
		return "list";
	}

}
