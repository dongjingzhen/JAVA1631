package action;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import vo.Class;
import vo.TestQusertion;
import vo.ThePapers;
import com.opensymphony.xwork2.Action;

import yundao.QuestionesDao;

public class QuestionesAction implements Action {
	private TestQusertion testQusertion;
	private ThePapers thePapers;
	
	public ThePapers getThePapers() {
		return thePapers;
	}
	public void setThePapers(ThePapers thePapers) {
		this.thePapers = thePapers;
	}
	public TestQusertion getTestQusertion() {
		return testQusertion;
	}
	public void setTestQusertion(TestQusertion testQusertion) {
		this.testQusertion = testQusertion;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//�鿴�༶
	public String selectClass(){
		QuestionesDao dao = new QuestionesDao();
//		List<Class> classesList= dao.selectClassName();
		List<Class> classesList= dao.selectClassName();
		for (Class class1 : classesList) {
			System.out.println(class1.getClassName());
		}
//		for (Classes classes : classesList) {
//			System.out.println(classes.getClassName());
//		}
		System.out.println(thePapers.getId());
		ServletActionContext.getRequest().setAttribute("id", thePapers.getId());
		ServletActionContext.getRequest().setAttribute("classesList", classesList);
		return "selectClasses";
		
		
	}
	//
	public String addClassPagers(){
		int id =new Integer(ServletActionContext.getRequest().getParameter("classId"));
		System.out.println(id);
		QuestionesDao dao = new QuestionesDao();
		dao.addPage_Class(thePapers);
		
		return "addClassPagers";
	}
	//ɾ���Ծ�
	public String deleteThePagers(){
		int id=testQusertion.getId();
		System.out.println(testQusertion.getId());
		QuestionesDao dao = new QuestionesDao();
		dao.deleteThePagers(id);
		return "deleteThePagers";
		
	}
	//���ӿ���
	public String addThePage(){
		QuestionesDao dao = new QuestionesDao();
		String duoXuan=ServletActionContext.getRequest().getParameter("duoXuan");
		int  danJdan=new Integer(ServletActionContext.getRequest().getParameter("danJdan")) ;
		int danKnan=new Integer(ServletActionContext.getRequest().getParameter("danKnan"));
		int duoJdan=new Integer(ServletActionContext.getRequest().getParameter("duoJdan"));
		int duoKnan=new Integer(ServletActionContext.getRequest().getParameter("duoKnan"));
		testQusertion.setTestTypeJOrB("����");
		dao.addThePapers(testQusertion, thePapers,duoXuan,danJdan,danKnan,duoJdan,duoKnan);
		return "addThePage";
	}
	//�鿴�Ծ�
	public String selectThePapers(){
		QuestionesDao dao = new QuestionesDao();
		List<ThePapers> thePapersList= dao.selectThePapers();
		ServletActionContext.getRequest().setAttribute("thePapersList", thePapersList);
		return "selectThePapers";
	}
	//����
	public String addQuestion(){
		QuestionesDao dao = new QuestionesDao();
		System.out.println(ServletActionContext.getRequest().getParameter("diJiQi"));
		System.out.println(testQusertion.getKeMu());
		dao.addQuestion(testQusertion);
		return "addQuestion";
		
	}
	//�޸�
	public String modifyQuser(){
		QuestionesDao dao = new QuestionesDao();
		
		dao.testQ(testQusertion);
		ServletActionContext.getRequest().setAttribute("keMu","java");
		return "modifyQuser";
	}
	//�޸Ĳ�ѯ
	public String modifySeleQuser(){
		QuestionesDao dao = new QuestionesDao();
		TestQusertion testQusertion= dao.modifySeleQuser();
		ServletActionContext.getRequest().setAttribute("testQusertion", testQusertion);
		
		return "modifySeleQuser";
		
	}
	//��ѯ�����Լ��ڼ���
	public String selectQuest(){
		QuestionesDao dao = new QuestionesDao();
		System.out.println("��ѯ�����Լ��ڼ���");
		List<Object[]> List =dao.QuestionesCount();
		System.out.println("��ѯ�����Լ��ڼ���222");
		ServletActionContext.getRequest().setAttribute("objList", List);
		return "selectQuest";
		}
	//������ѯ����
	public String selectTestQuest(){
		QuestionesDao dao = new QuestionesDao();
		String keMu=null;
		int diJiQi=0;
		int questioneId=0;
		List<TestQusertion> testQusertionList = dao.testQuset();
		for (TestQusertion testQusertion : testQusertionList) {
//			questioneId=testQusertion.getQuestiones().getQId();
			questioneId=testQusertion.getQuestiones().getId();
			keMu=testQusertion.getKeMu();
			diJiQi=testQusertion.getDiJiQi();
		}
		System.out.println(ServletActionContext.getRequest().getParameter("keMu"));
		ServletActionContext.getRequest().setAttribute("questioneId",questioneId);
		ServletActionContext.getRequest().setAttribute("keMu",keMu);
		ServletActionContext.getRequest().setAttribute("diJiQi",diJiQi);
		ServletActionContext.getRequest().setAttribute("testQusertionList", testQusertionList);
		return "selectTestQuest";
		
	}
}
