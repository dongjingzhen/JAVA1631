package action;

import java.util.List;

import vo.Class;
import yundao.ClassDao;


import com.opensymphony.xwork2.Action;

public class ClassAction implements Action{

	private List<Class> classList;
	
	
	public List<Class> getClassList() {
		return classList;
	}
	public void setClassList(List<Class> classList) {
		this.classList = classList;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String list() throws Exception {
		
		ClassDao classDao = new ClassDao();
		classList = classDao.list();
//		TeacherDao teacherDao = new TeacherDao();
//		teacherList =teacherDao.list();
		return "list";
	}

}
