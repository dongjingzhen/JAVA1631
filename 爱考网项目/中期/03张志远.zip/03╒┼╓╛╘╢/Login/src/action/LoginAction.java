package action;

import org.apache.struts2.ServletActionContext;

import vo.Student;
import vo.T_Admin;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

public class LoginAction implements Action {
	private String name;
	private String pwd;
	private int role;
	@Override
	public String execute() throws Exception {
		// TODO 
		boolean flag=false;
		if (role==1) {//ѧ��.��ʦ.����Ա
			flag=dao.HibernateUtils.selectUser(Student.class,name, pwd);
		}else if (role==2){
			flag=dao.HibernateUtils.selectUser(Teacher.class,name, pwd);
		}else if (role==4){
			flag=dao.HibernateUtils.selectUser(T_Admin.class,name, pwd);
		}
		
		if (flag) {
			ServletActionContext.getRequest().getSession().setAttribute("userName", name);
			ServletActionContext.getRequest().getSession().setAttribute("auth", role);
			return "index";
		}else{
			return "login";
		}
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}

}
