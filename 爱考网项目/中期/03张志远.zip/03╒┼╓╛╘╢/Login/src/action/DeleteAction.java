package action;

import java.util.ArrayList;
import java.util.List;

import vo.Question;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

public class DeleteAction implements Action {
	private int id;
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String DeleteTeacher(){
		dao.HibernateUtils.delete(dao.HibernateUtils.get(Teacher.class, id));
		return SUCCESS;
	}
	public String DeleteQuestion(){
		dao.HibernateUtils.delete(dao.HibernateUtils.get(Question.class, id));
		return SUCCESS;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}


	
}
