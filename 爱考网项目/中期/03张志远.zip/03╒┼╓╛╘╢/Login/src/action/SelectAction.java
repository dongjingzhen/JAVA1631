package action;

import java.util.ArrayList;
import java.util.List;

import net.sf.cglib.core.ClassesKey;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.Paper;
import vo.Question;
import vo.SubjectType;
import vo.Teacher;
import vo.TeacherDept;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class SelectAction implements Action {
	private List tempList=new ArrayList();
	private final int    PAGESIZE        =  10;
	private final String TEACHER_SEARCH[]={"loginID","name","temp.deptName"};
	private final String STUDENT_SEARCH[]={"loginID","name","temp.className"};
	private final String CLASSES_SEARCH[]={"className","driection","headmaster","lecturer"};
	private String str[];
	private int pageNum=1;
	private int pageCount;

	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String SelectQusestion(){
		tempList.add(dao.HibernateUtils.get(SubjectType.class,Integer.parseInt(str[0])));
		return SUCCESS;
	}
	public String SelectPaper(){
//		tempList=(List<Paper>)dao.HibernateUtils.createCriteria_List(Paper.class);
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		tempList=(List<Paper>)session.createCriteria(Paper.class).setFetchMode("questionList", FetchMode.LAZY).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return SUCCESS;
	}

	
	public String SelectSub(){
		tempList=dao.HibernateUtils.selectSubjectType();
		for (Object[] o : (List<Object[]>)tempList) {
			System.out.println("������"+o[2]+"  id��"+o[1]+"   ��������"+o[0]);
		}
		return SUCCESS;
	}
	public String SelectTeacher(){
		ServletActionContext.getRequest().setAttribute("dept", dao.HibernateUtils.createCriteria_List(TeacherDept.class));
		select_option(vo.Teacher.class,TEACHER_SEARCH);
		return SUCCESS;
	}
	public String SelectStudent(){
		ServletActionContext.getRequest().setAttribute("dept", dao.HibernateUtils.createCriteria_List(vo.Classes.class));
		select_option(vo.Student.class,STUDENT_SEARCH);
		return SUCCESS;
	}
	public String SelectClasses(){
		ServletActionContext.getRequest().setAttribute("dept", dao.HibernateUtils.createCriteria_List(vo.TeacherDept.class));
		select_option(vo.Classes.class,CLASSES_SEARCH);
		return SUCCESS;
	}
	public void select(Class clazz){
		pageCount=0;
		tempList=dao.HibernateUtils.createCriteria_PageList(clazz, pageNum, PAGESIZE);
		for (Object o : tempList) {
			pageCount++;
		}
	}
	public void select_option(Class clazz,String[] s){
		pageCount=0;
		tempList=dao.HibernateUtils.createCriteria_OptionList(clazz,s,str, pageNum, PAGESIZE);
		for (Object o : tempList) {
			pageCount++;
			
		}
		if (pageCount%PAGESIZE==0) {
			pageCount=pageCount/PAGESIZE;
		}else{
			  pageCount=pageCount/PAGESIZE+1;
		}
		System.out.println(pageCount);
	}

	public int getPageCount() {
		return pageCount;
	}
	public List getTempList() {
		return tempList;
	}

	public void setTempList(List tempList) {
		this.tempList = tempList;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public String[] getStr() {
		return str;
	}
	public void setStr(String[] str) {
		this.str = str;
	}
	
}
