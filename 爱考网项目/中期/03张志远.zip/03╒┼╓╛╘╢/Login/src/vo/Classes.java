package vo;

import java.util.ArrayList;
import java.util.List;

public class Classes {
	private int id;
	private String className;
	private String headmaster;
	private String  lecturer;
	private String driection;
	private List<Student> studentList;
	private List<Paper_Classes> paperList=new ArrayList<Paper_Classes>();
	
	public Classes() {
	}
	public Classes(String className, String headmaster,
			String lecturer) {
		this.className = className;
		this.headmaster = headmaster;
		this.lecturer = lecturer;
	}

	
	
	
	
	
	
////////////////////////////////////////////////////////////////////////////
	
	public List<Student> getStudentList() {
		return studentList;
	}
	public List<Paper_Classes> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper_Classes> paperList) {
		this.paperList = paperList;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}
	public int getId() {
		return id;
	}
	public String getDriection() {
		return driection;
	}
	public void setDriection(String driection) {
		this.driection = driection;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getHeadmaster() {
		return headmaster;
	}
	public void setHeadmaster(String headmaster) {
		this.headmaster = headmaster;
	}
	public String getLecturer() {
		return lecturer;
	}
	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}
	
	
	
}
