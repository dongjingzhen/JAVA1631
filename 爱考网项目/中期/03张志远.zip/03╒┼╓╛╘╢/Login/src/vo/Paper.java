package vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Paper {
	private int id;
	private String kind ;//���Ի���
	private String title;//����

	private int testMinutes;
	private int totalSource;
	private String state="δ����";//δ������������
	
	private Subject subject;
	
	private List<Question> questionList=new ArrayList<Question>();//�Ծ��е��� ��Զ�
	private List<Paper_Classes> classesList;//����İ�  ʹ��ʱ����
	private List<Source> sourceList;

	
public Paper() {
	}
public Paper(Subject subject, String kind, String title,
			List<Paper_Classes> classesList,  int testMinutes,
			int totalSource, List<Question> questionList, String state) {
		this.subject = subject;
		this.kind = kind;
		this.title = title;
		this.classesList = classesList;
		this.testMinutes = testMinutes;
		this.totalSource = totalSource;
		this.questionList = questionList;
		this.state = state;
	}

//////////////////////////////////////////////////////////////////////////////	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Paper_Classes> getClassesList() {
		return classesList;
	}

	public void setClassesList(List<Paper_Classes> classesList) {
		this.classesList = classesList;
	}



	public int getTestMinutes() {
		return testMinutes;
	}

	public void setTestMinutes(int testMinutes) {
		this.testMinutes = testMinutes;
	}

	public int getTotalSource() {
		return totalSource;
	}

	public void setTotalSource(int totalSource) {
		this.totalSource = totalSource;
	}

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public List<Source> getSourceList() {
		return sourceList;
	}

	public void setSourceList(List<Source> sourceList) {
		this.sourceList = sourceList;
	}
	
	
}
