package vo;

import java.util.List;

public class TeacherDept {
	private int id;
	private String deptName;
	private List<Teacher> teacherList;

	public TeacherDept() {
	}
	public TeacherDept( String deptName) {
		this.deptName = deptName;
	}
	
	
	
	
	
	///////////////////////////////////////////////
	public int getId() {
		return id;
	}
	public List<Teacher> getTeacherList() {
		return teacherList;
	}
	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	
}
