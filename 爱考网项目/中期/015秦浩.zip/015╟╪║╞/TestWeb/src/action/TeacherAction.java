package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Students;
import vo.Teacher;



import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;


public class TeacherAction implements Action{

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String list() throws Exception{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		
		List<Teacher> teacherList =(List<Teacher>) session.createCriteria(Teacher.class).list();
		ServletActionContext.getRequest().getSession().setAttribute("teacherList", teacherList);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
	}

}
