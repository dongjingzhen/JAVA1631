package action;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Admin;
import vo.Classes;
import vo.Students;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class IndexAction implements Action {
	private String role;
	private String name;
	private String pwd;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		String retu="";
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		
//		Teacher tea = new Teacher();
//		tea.setTeaNo(100001);
//		tea.setTeaName("����ʦ");
//		tea.setTeaPwd("123");
//		tea.setTeaSex("��");
//		tea.setTeaJob("��ʦ");
//		tea.setTeaDucation("��ʿ");
//		tea.setTeaTel(12246545);
//		
//		Teacher tea1 = new Teacher();
//		tea1.setTeaNo(100002);
//		tea1.setTeaName("ţ��ʦ");
//		tea1.setTeaPwd("123");
//		tea1.setTeaSex("Ů");
//		tea1.setTeaJob("����");
//		tea1.setTeaDucation("��ʿ��");
//		tea1.setTeaTel(58746545);
//		
//		Teacher tea2 = new Teacher();
//		tea2.setTeaNo(100003);
//		tea2.setTeaName("����ʦ");
//		tea2.setTeaPwd("123");
//		tea2.setTeaSex("��");
//		tea2.setTeaJob("������");
//		tea2.setTeaDucation("��ѧ");
//		tea2.setTeaTel(546544);
//		
//		Classes classes = new Classes();
//		classes.setClassNo("QH1001");
//		classes.setClassName("java1631");
//		classes.setDirection("SCME");
//		classes.setHeadteacher("����ʦ");
//		classes.setLecturer("ţ��ʦ");
//		classes.setDate(new Date());
//		classes.setState("����");
//		
//		Students stu = new Students();
//		stu.setStuName("����");
//		stu.setStuPwd("123");
//		stu.setClasses(classes);
//		session.save(stu);
//		Students stu1 = new Students();
//		stu1.setStuName("����");
//		stu1.setStuPwd("123");
//		stu1.setClasses(classes);
//		session.save(stu1);
//		Students stu2 = new Students();
//		stu2.setStuName("����");
//		stu2.setStuPwd("123");
//		stu2.setClasses(classes);
//		session.save(stu2);
//		
//		Admin admin = new Admin();
//		admin.setAdminName("sa");
//		admin.setAdminPwd("123");
//		
//		
//		
//		classes.getStudents().add(stu);
//		classes.getStudents().add(stu1);
//		classes.getStudents().add(stu2);
//		session.save(classes);
//		session.save(tea);
//		session.save(tea1);
//		session.save(tea2);
//		
//		session.save(admin);
	
		
		if (role.equals("Students")) {
			String hql = "select s from Students s";
			Query query = session.createQuery(hql);
			List<Students> list = query.list();
			for (Students b : list) {
				if (b.getStuName().equals(name) && b.getStuPwd().equals(pwd)) {
					retu="index";
				}else {
					retu="login";
				}
			}
			
			
		}
		if (role.equals("admin")) {
			String hql = "select a from Admin a";
			Query query = session.createQuery(hql);
			List<Admin> list = query.list();
			for (Admin b : list) {
				if (b.getAdminName().equals(name) && b.getAdminPwd().equals(pwd)) {
					retu="index";
				}else {
					retu="login";
				}
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return retu;
	}

}
