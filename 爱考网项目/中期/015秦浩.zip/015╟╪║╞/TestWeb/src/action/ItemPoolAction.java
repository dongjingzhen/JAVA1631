package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Question;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class ItemPoolAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//����/��ʾ��������
	public String first() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		Question question = new Question();
//		question.setKind("��ѡ");
//		question.setContent("1+1=��");
//		question.setOptionA("1");
//		question.setOptionB("2");
//		question.setOptionC("3");
//		question.setOptionD("4");
//		question.setAnswer("B");
//		question.setSubject("HTML");
//		question.setQueClass("������");
//		question.setDifficulty("��");
//		question.setChapter("t01");
//		
//		Question question1 = new Question();
//		question1.setKind("��ѡ");
//		question1.setContent("è��Ӣ����");
//		question1.setOptionA("cat");
//		question1.setOptionB("dog");
//		question1.setOptionC("lion");
//		question1.setOptionD("tiger");
//		question1.setAnswer("A");
//		question1.setSubject("java");
//		question1.setQueClass("������");
//		question1.setDifficulty("����");
//		question.setChapter("t01");
//		
//		Question question2 = new Question();
//		question2.setKind("��ѡ");
//		question2.setContent("������Լ�˧��");
//		question2.setOptionA("˧");
//		question2.setOptionB("��˧");
//		question2.setOptionC("�ǳ�˧");
//		question2.setOptionD("˧������");
//		question2.setAnswer("A��B��C��D");
//		question2.setSubject("HTML");
//		question2.setQueClass("������");
//		question2.setDifficulty("����");
//		question.setChapter("t02");
//		
//		session.save(question);
//		session.save(question1);
//		session.save(question2);
//		
		
		//select queClass,count(queClass) as num,subject from question group by queClass,subject order by queClass
		
		String hql = "select q.queClass,COUNT(q.queClass) as num,q.subject from Question q group by q.queClass,q.subject order by q.queClass";
		Query query = session.createQuery(hql);
		List<Object[]> list = query.list();
		
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("list", list);
		return "ItemPool";
	}
	//��ʾ�Ծ�
	public String list() throws Exception {
		// TODO Auto-generated method stub
		String testtype = ServletActionContext.getRequest().getParameter("testtype");
		String testClass = ServletActionContext.getRequest().getParameter("testClass");
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		
		System.out.println(testtype.toString());
		System.out.println(testClass.toString());
		
		Criteria criteria = session.createCriteria(Question.class)
																  .add(Restrictions.eq("queClass", testtype.toString()))
																  .add(Restrictions.eq("subject",testClass.toString()));
//		for (Object object : criteria.list()) {
//			System.out.println(object);
//		}
		List<Question> listtest = criteria.list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("listtest", listtest);
		ServletActionContext.getRequest().getSession().setAttribute("testtype", testtype);
		ServletActionContext.getRequest().getSession().setAttribute("testClass", testClass);
		return "testlist";
	}
	//������޸ķ���
	public String update() throws Exception {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(ServletActionContext.getRequest().getParameter("id"));
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		
		
		Question ques = new Question();
		ques = (Question)session.get(Question.class, id);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("id", id);
		ServletActionContext.getRequest().getSession().setAttribute("ques", ques);
		
		return "testupdate";
	}
	//�����޸ĺ���ת
	public String updateSelect() throws Exception {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(ServletActionContext.getRequest().getParameter("id"));
		System.out.println(id);
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		
		Question ques = new Question();
		ques = (Question)session.get(Question.class, id);
		

		String kind = ServletActionContext.getRequest().getParameter("kind");
		String content = ServletActionContext.getRequest().getParameter("content");
		String optionA = ServletActionContext.getRequest().getParameter("optionA");
		String optionB = ServletActionContext.getRequest().getParameter("optionB");
		String optionC = ServletActionContext.getRequest().getParameter("optionC");
		String optionD = ServletActionContext.getRequest().getParameter("optionD");
		String answer = ServletActionContext.getRequest().getParameter("answer");
		String difficulty = ServletActionContext.getRequest().getParameter("difficulty");
		String chapter = ServletActionContext.getRequest().getParameter("chapter");
		
		ques.setKind(kind);
		ques.setContent(content);
		ques.setOptionA(optionA);
		ques.setOptionB(optionB);
		ques.setOptionC(optionC);
		ques.setOptionD(optionD);
		ques.setAnswer(answer);
		ques.setDifficulty(difficulty);
		ques.setChapter(chapter);
		
		session.update(ques);
		

		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("ques", ques);
		return "testlist";
	}
	//��������
	public String add() throws Exception {
		// TODO Auto-generated method stub
		String testtype = ServletActionContext.getRequest().getParameter("testtype");
		String testClass = ServletActionContext.getRequest().getParameter("testClass");
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("testtype", testtype);
		ServletActionContext.getRequest().getSession().setAttribute("testClass", testClass);
		return "testadd";
	}
	public String alladd() throws Exception {
		// TODO Auto-generated method stub
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		String testtype = ServletActionContext.getRequest().getParameter("testtype");
		String testClass = ServletActionContext.getRequest().getParameter("testClass");
		System.out.println(testtype);
		String kind = ServletActionContext.getRequest().getParameter("kind");
		String content = ServletActionContext.getRequest().getParameter("content");
		String optionA = ServletActionContext.getRequest().getParameter("optionA");
		String optionB = ServletActionContext.getRequest().getParameter("optionB");
		String optionC = ServletActionContext.getRequest().getParameter("optionC");
		String optionD = ServletActionContext.getRequest().getParameter("optionD");
		String answer = ServletActionContext.getRequest().getParameter("answer");
		String difficulty = ServletActionContext.getRequest().getParameter("difficulty");
		String chapter = ServletActionContext.getRequest().getParameter("chapter");
		
		Question ques = new Question();
		ques.setKind(kind);
		ques.setContent(content);
		ques.setOptionA(optionA);
		ques.setOptionB(optionB);
		ques.setOptionC(optionC);
		ques.setOptionD(optionD);
		ques.setAnswer(answer);
		ques.setDifficulty(difficulty);
		ques.setChapter(chapter);
		ques.setSubject(testClass);
		ques.setQueClass(testtype);
		
		session.save(ques);
		
		Criteria criteria = session.createCriteria(Question.class)
		  .add(Restrictions.eq("queClass", testtype.toString()))
		  .add(Restrictions.eq("subject",testClass.toString()));

		List<Question> listtest = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("listtest", listtest);
		return "testlist";
	}
	

}
