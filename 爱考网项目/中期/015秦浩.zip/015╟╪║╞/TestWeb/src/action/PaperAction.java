package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Paper;
import vo.Question;
import vo.Students;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class PaperAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//ȥ�Ծ�ҳ��
	public String topaper() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		Criteria criteria = session.createCriteria(Paper.class);
		List<Paper> paperlist = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("paperlist", paperlist);
		return "topaper";
	}
	//ȥ���ҳ��
	public String Gogrouppaper() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		
//		String hql = "select q.subject from Question q group by q.subject";
//		Query query = session.createQuery(hql);
//		List<Object[]> list = query.list();
		  
		transaction.commit();
		HibernateSessionFactory.closeSession();
//		ServletActionContext.getRequest().getSession().setAttribute("list", list);
		return "gopaper";
	}
	//���
	public String grouppaper() throws Exception {
		// TODO Auto-generated method stub
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		Paper paper = new Paper();
		String subject = ServletActionContext.getRequest().getParameter("subject");
		String testHour = ServletActionContext.getRequest().getParameter("testHour");
		String title = ServletActionContext.getRequest().getParameter("title");
		int easy = Integer.parseInt(ServletActionContext.getRequest().getParameter("easy"));
//		int between = Integer.parseInt(ServletActionContext.getRequest().getParameter("between"));
		int diff = Integer.parseInt(ServletActionContext.getRequest().getParameter("diff"));
		System.out.println(easy+diff);
		paper.setTitle(title);
		paper.setTestHour(testHour);
		paper.setSubjectName(subject);
		String sql="select queId from (select top "+easy+" queid from question where difficulty=" +
				" '��' order by newid() union " +
				"select top "+diff+" queId from question where difficulty= '����' " +
				"order by newid()) as t";
		List queId = session.createSQLQuery(sql).list();
		for (Object o : queId) {
			
			System.out.println(o);
			for (int i = 1; i <= easy; i++) {
				Question ques= new Question();
				ques = (Question)session.get(Question.class, Integer.parseInt(o.toString()));
				paper.getQuestion().add(ques);
			}
		}
		session.save(paper);
		Criteria criteria = session.createCriteria(Paper.class);
		List<Paper> paperlist = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("paperlist", paperlist);
		return "paper";
	}
	//��ʼ����
	public String start() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		String pid = ServletActionContext.getRequest().getParameter("pid");
		
		Criteria criteria = session.createCriteria(Classes.class);
		List<Classes> starttest = criteria.list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("starttest", starttest);
		ServletActionContext.getRequest().getSession().setAttribute("pid", pid);
		return "setclass";
	}
	//���ÿ����༶
	public String toTest() throws Exception {
		// TODO Auto-generated method stub
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		String className = ServletActionContext.getRequest().getParameter("className");
		int pid = Integer.parseInt(ServletActionContext.getRequest().getParameter("pid"));
		
		Paper paper = (Paper)session.get(Paper.class, pid);
		paper.setClassName(className);
		paper.setState("������");
		
		//������Ҫ���Ե�ѧ��
		String sql="select classId from class where className='"+className+"'";
		List claId = session.createSQLQuery(sql).list();
	    for (Object object : claId) {
	    	int i = Integer.parseInt(object.toString());
	    	System.out.println(i);
			String sql1="select stuId from students where classId="+object.toString()+"";
			List stuId = session.createSQLQuery(sql1).list();
			for (Object obj : stuId) {
				Students stus = new Students();
				stus = (Students)session.get(Students.class, Integer.parseInt(obj.toString()));
				paper.getStudents().add(stus);
			}
		}
	    session.saveOrUpdate(paper);
		
		
		//��ѯ�Ծ�
		Criteria criteria = session.createCriteria(Paper.class);
		List<Paper> paperlist = criteria.list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		ServletActionContext.getRequest().getSession().setAttribute("paperlist", paperlist);
		return "test";
	}
}
