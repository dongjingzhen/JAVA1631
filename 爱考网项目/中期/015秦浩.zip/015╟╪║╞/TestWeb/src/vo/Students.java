package vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Students {
	private int stuid;
	private String stuNo;
	private String stuName;
	private String stuPwd;
	private String stuSex;
	private long stuTel; 
	private long parentTel;
	private Date stuSchoolYear;
	private long stuIDCard;
	private Date stuBrithday;
	private String stuAddress;
	private String stuMajor;//רҵ
	private String stuParentName;
	private String stuDrom;//����¥
	private String stuDromNo;//�����
	private Classes classes;
	private Set<Paper> paper = new HashSet<Paper>();
	
	
	public Set<Paper> getPaper() {
		return paper;
	}
	public void setPaper(Set<Paper> paper) {
		this.paper = paper;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public int getStuid() {
		return stuid;
	}
	public void setStuid(int stuid) {
		this.stuid = stuid;
	}
	public String getStuNo() {
		return stuNo;
	}
	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuPwd() {
		return stuPwd;
	}
	public void setStuPwd(String stuPwd) {
		this.stuPwd = stuPwd;
	}
	public String getStuSex() {
		return stuSex;
	}
	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}
	public long getStuTel() {
		return stuTel;
	}
	public void setStuTel(long stuTel) {
		this.stuTel = stuTel;
	}
	public long getParentTel() {
		return parentTel;
	}
	public void setParentTel(long parentTel) {
		this.parentTel = parentTel;
	}
	public Date getStuSchoolYear() {
		return stuSchoolYear;
	}
	public void setStuSchoolYear(Date stuSchoolYear) {
		this.stuSchoolYear = stuSchoolYear;
	}
	public long getStuIDCard() {
		return stuIDCard;
	}
	public void setStuIDCard(long stuIDCard) {
		this.stuIDCard = stuIDCard;
	}
	public Date getStuBrithday() {
		return stuBrithday;
	}
	public void setStuBrithday(Date stuBrithday) {
		this.stuBrithday = stuBrithday;
	}
	public String getStuAddress() {
		return stuAddress;
	}
	public void setStuAddress(String stuAddress) {
		this.stuAddress = stuAddress;
	}
	public String getStuMajor() {
		return stuMajor;
	}
	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}
	public String getStuParentName() {
		return stuParentName;
	}
	public void setStuParentName(String stuParentName) {
		this.stuParentName = stuParentName;
	}
	public String getStuDrom() {
		return stuDrom;
	}
	public void setStuDrom(String stuDrom) {
		this.stuDrom = stuDrom;
	}
	public String getStuDromNo() {
		return stuDromNo;
	}
	public void setStuDromNo(String stuDromNo) {
		this.stuDromNo = stuDromNo;
	}

	
}
