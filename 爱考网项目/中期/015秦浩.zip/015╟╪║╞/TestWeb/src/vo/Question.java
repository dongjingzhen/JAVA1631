package vo;

import java.util.HashSet;
import java.util.Set;

public class Question {
	private int queId;
	private String kind;//ѡ��ʽ
	private String content;//��������
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String answer;
	private String subject;
	private String difficulty;
	private String chapter;//�½�
	private String queClass;//��������
	private Set<Paper> paper = new HashSet<Paper>();
	
	public Set<Paper> getPaper() {
		return paper;
	}
	public void setPaper(Set<Paper> paper) {
		this.paper = paper;
	}
	@Override
	public String toString() {
		return "Question [answer=" + answer + ", chapter=" + chapter
				+ ", content=" + content + ", difficulty=" + difficulty
				+ ", kind=" + kind + ", optionA=" + optionA + ", optionB="
				+ optionB + ", optionC=" + optionC + ", optionD=" + optionD
				+ ", queClass=" + queClass + ", queId=" + queId + ", subject="
				+ subject + "]";
	}
	public String getQueClass() {
		return queClass;
	}
	public void setQueClass(String queClass) {
		this.queClass = queClass;
	}
	public int getQueId() {
		return queId;
	}
	public void setQueId(int queId) {
		this.queId = queId;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
	public String getChapter() {
		return chapter;
	}
	public void setChapter(String chapter) {
		this.chapter = chapter;
	}
	
	

}
