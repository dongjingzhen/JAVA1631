package action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Paper;
import vo.Question;
import vo.Student;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class BeginTestAction implements Action {
	private Student student;
	private Set<Paper> paperSet = new HashSet<Paper>();
	private int id;
	private Paper paper;
	
	
	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public Set<Paper> getPaperSet() {
		return paperSet;
	}

	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * ��ʾ�Ծ�
	 * @return
	 */
	public String paper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		id = (Integer)ServletActionContext.getRequest().getSession().getAttribute("id");
		student =  (Student) session.get(Student.class, id);
		paperSet =  student.getPaperSet();
		for(Paper list:paperSet){
			System.out.println(list.getPid());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "paper";
		
	}
	/**
	 * ��ʼ����,��ʾ�Ծ�����
	 */
	public String showQuestion(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper)session.get(Paper.class,paper.getPid());
		Set<Question> q = paper.getQuestionSet();
		for (Question question : q) {
			System.out.println(question.getType());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "showQuestion";
	}

}
