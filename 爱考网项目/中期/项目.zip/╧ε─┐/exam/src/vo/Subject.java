package vo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Subject {
	
	private int id;
	
	private String direction; //����
	
	private String stage;  //�׶�
	
	private String subjectId; //��Ŀ
	
	private List<Object[]> questionobject = new ArrayList<Object[]>();
	
	private Set<Paper> paperSet = new HashSet<Paper>();
	
	private Paper paper;
	
	
	

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public Set<Paper> getPaperSet() {
		return paperSet;
	}

	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}

	public List<Object[]> getQuestionobject() {
		return questionobject;
	}

	public void setQuestionobject(List<Object[]> questionobject) {
		this.questionobject = questionobject;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	@Override
	public String toString() {
		return "Subject [direction=" + direction + ", id=" + id + ", stage="
				+ stage + ", subjectId=" + subjectId + "]";
	}
	
	

}
