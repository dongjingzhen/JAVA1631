package vo;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * �Ծ�ʵ����
 * @author Administrator
 *
 */
public class Paper {
	private int pid ;
	private String subjectName ;//ѧ��
	private String kind;//����
	private String title;//����
	private String className;//�༶
	private Date testTime;//��ʼʱ��
	private int testHour;//����ʱ�䳤��
	private float totalScore;//�ܷ�
	public void setTotalScore(float totalScore) {
		this.totalScore = totalScore;
	}
	public float getTotalScore() {
		return totalScore;
	}
	private int qnumber;//����
	private Set<Class> classset;
	private String state;//״̬
	private Set<Question> questionSet  = new HashSet<Question>();
	private Set<Student> studentSet = new HashSet<Student>();
	
	
	
	
	
	
	public Set<Student> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Student> studentSet) {
		this.studentSet = studentSet;
	}
	public Set<Class> getClassset() {
		return classset;
	}
	public void setClassset(Set<Class> classset) {
		this.classset = classset;
	}
	public Set<Question> getQuestionSet() {
		return questionSet;
	}
	public void setQuestionSet(Set<Question> questionSet) {
		this.questionSet = questionSet;
	}
	@Override
	public String toString() {
		return "Paper [�༶=" + className + ",����=" + kind + ", id="
				+ pid + ", ����=" + qnumber + ", ����=" + subjectName
				+ ", ʱ��=" + testHour + ", ��Ŀ=" + title + "]"+",״̬="+state;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Date getTestTime() {
		return testTime;
	}
	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}
	public int getTestHour() {
		return testHour;
	}
	public void setTestHour(int testHour) {
		this.testHour = testHour;
	}
	public int getQnumber() {
		return qnumber;
	}
	public void setQnumber(int qnumber) {
		this.qnumber = qnumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}


}
