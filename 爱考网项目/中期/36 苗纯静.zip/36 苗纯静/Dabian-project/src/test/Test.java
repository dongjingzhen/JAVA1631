package test;

import vo.Question;
import DBManger.HibernateUtils;
import action.ActionQuestion;

public class Test {

	public static void main(String[] args) {
		
	}
}
