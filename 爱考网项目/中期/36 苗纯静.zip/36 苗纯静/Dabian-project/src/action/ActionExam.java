package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Admin;

import vo.Student;
import vo.Teacher;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class ActionExam implements Action{
       private Student student;
       private Teacher teacher;
       private Admin admin;
       private Users user;
       private List list = new ArrayList();
       private String message;
     
       private List<Student> stuList =new ArrayList<Student>();
       private List<Teacher> reaList= new ArrayList<Teacher>();
       private List<Admin> admList = new ArrayList<Admin>();
     
	  
       
       
       
     //��½
  	 public String Login(){
  		    Session session=HibernateSessionFactory.getSession();
  			Transaction transaction = session.beginTransaction();
  			//����Ա
  			
  			if (user.getRole()== 3 ){
  				
  					String hql = "from Admin where aname = '"+user.getName()+"' and apwd = '"+user.getPwd()+"'";
  					admList= session.createQuery(hql).list();
  	  				transaction.commit();
  	  				HibernateSessionFactory.closeSession();
//  	  				
  	  				if (admList.size()==0) {
  	  				   message="loginnot";
  	  				}else {
  	  					ServletActionContext.getRequest().getSession().setAttribute("adname", user);
  	  					message="loginok3";
  	  					
  	  				}
  			}//ѧ��
  			else if (user.getRole()== 1){
  				String hql = "from Student where stuname = '"+user.getName()+"' and stupwd = '"+user.getPwd()+"'";
  				
  				stuList=  session.createQuery(hql).list();
  				transaction.commit();
  				HibernateSessionFactory.closeSession();
//  				
  				if (stuList.size()==0) {
  					message="loginnot";
  				}else {
  					ServletActionContext.getRequest().getSession().setAttribute("adname", user);
  					message="loginok1";
  				}
  			}//��ʦ
  			else if (user.getRole()== 2){
  				String hql = "from Teacher where tname = '"+user.getName()+"' and tpwd = '"+user.getPwd()+"'";
  				
  				reaList=  session.createQuery(hql).list();
  				transaction.commit();
  				HibernateSessionFactory.closeSession();
//  				
  				if (reaList.size()==0) {
  					message="loginnot";
  				}else {
  					message="loginok2";
  				}
  			}
			return message;
  			
  	 }
       
  	 //ע��
	 public String Zhuxiao(){
		 
		 ServletActionContext.getRequest().getSession().invalidate();
		return "zhuxiao";
	 }
	  public List<Student> getStuList() {
		return stuList;
	}


	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setStuList(List<Student> stuList) {
		this.stuList = stuList;
	}


	public Users getUser() {
		return user;
	}


	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public void setUser(Users user) {
		this.user = user;
	}


	public List<Teacher> getReaList() {
		return reaList;
	}


	public void setReaList(List<Teacher> reaList) {
		this.reaList = reaList;
	}


	public List<Admin> getAdmList() {
		return admList;
	}


	public void setAdmList(List<Admin> admList) {
		this.admList = admList;
	}


	
	

	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	public Teacher getTeacher() {
		return teacher;
	}


	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}


	public Admin getAdmin() {
		return admin;
	}


	public void setAdmin(Admin admin) {
		this.admin = admin;
	}


	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
