package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Student;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class ActionStudent implements Action {
    private Student student;
    private List<Student> studentList = new ArrayList<Student>();
	//������Ϣ
	public String Person() {
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		studentList=session.createCriteria(Student.class).list();
		
		return "person";
		
	}
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public List<Student> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}

}
