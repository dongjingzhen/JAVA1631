package vo;

public class Teacher {
	private int tid;//
	private String tNum;//�˺�,not-null
	private String tPwd;//����,not-null
	private String tName;//����,not-null
	private String tSex;//�Ա�,not-null
	
	private String tBirth;//����
	private String tEducation;//ѧ��
	private String tTel;//��ϵ�绹
	private String tJob;//��λ,not-null
	private String tNote;//��ע
	
	
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String gettNum() {
		return tNum;
	}
	public void settNum(String tNum) {
		this.tNum = tNum;
	}
	public String gettPwd() {
		return tPwd;
	}
	public void settPwd(String tPwd) {
		this.tPwd = tPwd;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public String gettSex() {
		return tSex;
	}
	public void settSex(String tSex) {
		this.tSex = tSex;
	}
	public String gettBirth() {
		return tBirth;
	}
	public void settBirth(String tBirth) {
		this.tBirth = tBirth;
	}
	public String gettEducation() {
		return tEducation;
	}
	public void settEducation(String tEducation) {
		this.tEducation = tEducation;
	}
	public String gettJob() {
		return tJob;
	}
	public void settJob(String tJob) {
		this.tJob = tJob;
	}
	public String gettTel() {
		return tTel;
	}
	public void settTel(String tTel) {
		this.tTel = tTel;
	}
	public String gettNote() {
		return tNote;
	}
	public void settNote(String tNote) {
		this.tNote = tNote;
	}
	

}
