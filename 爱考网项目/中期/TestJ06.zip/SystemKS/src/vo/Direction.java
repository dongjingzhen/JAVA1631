package vo;

public class Direction {
	private int dir_id;
	private String dir_name;
	public int getDir_id() {
		return dir_id;
	}
	public void setDir_id(int dirId) {
		dir_id = dirId;
	}
	public String getDir_name() {
		return dir_name;
	}
	public void setDir_name(String dirName) {
		dir_name = dirName;
	}
	

}
