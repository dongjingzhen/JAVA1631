package vo;

public class P_paper {
	private int pid;
	private String pWords;//��������
	private String pA;//��A
	private String pB;//��B
	private String pC;//��C
	private String pD;//��D
	private String pAnsware;//����
	private String pDiffi;
	public String getpDiffi() {
		return pDiffi;
	}
	public void setpDiffi(String pDiffi) {
		this.pDiffi = pDiffi;
	}
	private String pT;//�����½�
	private Subjectes subject;//��Ŀ,���һ
	
	public Subjectes getSubject() {
		return subject;
	}
	public void setSubject(Subjectes subject) {
		this.subject = subject;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpWords() {
		return pWords;
	}
	public void setpWords(String pWords) {
		this.pWords = pWords;
	}
	public String getpA() {
		return pA;
	}
	public void setpA(String pA) {
		this.pA = pA;
	}
	public String getpB() {
		return pB;
	}
	public void setpB(String pB) {
		this.pB = pB;
	}
	public String getpC() {
		return pC;
	}
	public void setpC(String pC) {
		this.pC = pC;
	}
	public String getpD() {
		return pD;
	}
	public void setpD(String pD) {
		this.pD = pD;
	}
	public String getpAnsware() {
		return pAnsware;
	}
	public void setpAnsware(String pAnsware) {
		this.pAnsware = pAnsware;
	}
	public String getpT() {
		return pT;
	}
	public void setpT(String pT) {
		this.pT = pT;
	}

	

}
