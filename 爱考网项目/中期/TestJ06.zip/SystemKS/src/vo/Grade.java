package vo;

import java.util.Date;

public class Grade {
	private int gid;//
	private String gNum;//�༶���
	private String gName;//�༶��
	private Teacher m_teacher;//�����Σ����
	private Teacher r_teacher;//��ʦ�����
	private Date begin_time;//����ʱ��
	private String gDirection;//����
	private String gState;//״̬
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getgNum() {
		return gNum;
	}
	public void setgNum(String gNum) {
		this.gNum = gNum;
	}
	public String getgName() {
		return gName;
	}
	public void setgName(String gName) {
		this.gName = gName;
	}
	public Teacher getM_teacher() {
		return m_teacher;
	}
	public void setM_teacher(Teacher mTeacher) {
		m_teacher = mTeacher;
	}
	public Teacher getR_teacher() {
		return r_teacher;
	}
	public void setR_teacher(Teacher rTeacher) {
		r_teacher = rTeacher;
	}
	public Date getBegin_time() {
		return begin_time;
	}
	public void setBegin_time(Date beginTime) {
		begin_time = beginTime;
	}
	public String getgDirection() {
		return gDirection;
	}
	public void setgDirection(String gDirection) {
		this.gDirection = gDirection;
	}
	public String getgState() {
		return gState;
	}
	public void setgState(String gState) {
		this.gState = gState;
	}
	
	

}
