package vo;

public class Student {
	private int sid;//
	private String sNum;//ѧ��
	private String sPwd;//����
	private String sName;//����
	private String sSex;//�Ա�
	private String sBirth;//����
	private int grade_id;//�����༶�����
	private String sNote;//��ע
	
	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getsNum() {
		return sNum;
	}
	public void setsNum(String sNum) {
		this.sNum = sNum;
	}
	public String getsPwd() {
		return sPwd;
	}
	public void setsPwd(String sPwd) {
		this.sPwd = sPwd;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsSex() {
		return sSex;
	}
	public void setsSex(String sSex) {
		this.sSex = sSex;
	}
	public String getsBirth() {
		return sBirth;
	}
	public void setsBirth(String sBirth) {
		this.sBirth = sBirth;
	}
	
	public int getGrade_id() {
		return grade_id;
	}
	public void setGrade_id(int gradeId) {
		grade_id = gradeId;
	}
	public String getsNote() {
		return sNote;
	}
	public void setsNote(String sNote) {
		this.sNote = sNote;
	}
	
	

}
