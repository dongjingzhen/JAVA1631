package action;

import java.util.List;

import vo.Admin;
import vo.Student;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.LoginDao;

public class LoginAction implements Action{
LoginDao ld = new LoginDao();
private Admin admin;
private String Num;
private String Pwd;
private String role;


	public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}

	public String getNum() {
	return Num;
}

public void setNum(String num) {
	Num = num;
}

public String getPwd() {
	return Pwd;
}

public void setPwd(String pwd) {
	Pwd = pwd;
}

	public Admin getAdmin() {
	return admin;
}

public void setAdmin(Admin admin) {
	this.admin = admin;
}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return "admin";
	}
	public String login(){
		System.out.println(Num+"     "+Pwd+"    "+role);
		//�ж����ݺ󣬵��ò�ͬ�ķ�������ת����ͬ�Ľ���
		if (role.equals("����Ա")) {
			List<Admin> admin_list = ld.adminLogin(Num, Pwd);
			if (admin_list.size() != 0) {
				return "admin";
			}
		}
		if (role.equals("��ʦ")) {
			List<Teacher> teacher_list = ld.teacherLogin(Num, Pwd);
			if (teacher_list.size() != 0) {
				return "teacher";
			}
		}
		if (role.equals("ѧ��")) {
			List<Student> student_list = ld.studentLogin(Num, Pwd);
			if (student_list.size() != 0) {
				return "student";
			}
		}
		
		
		return "login";
	}

}
