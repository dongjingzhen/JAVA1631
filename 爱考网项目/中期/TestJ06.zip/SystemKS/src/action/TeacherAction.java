package action;

import java.util.List;

import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.TeacherDao;

public class TeacherAction implements Action{
TeacherDao t = new TeacherDao();
private List<Teacher> t_list;

	public List<Teacher> getT_list() {
	return t_list;
}
public void setT_list(List<Teacher> tList) {
	t_list = tList;
}
	//��ѯ������ʦ
	public String allTeacher(){
		t_list = t.showAllTeacher();
		System.out.println("��ѯ����");
		return "showTeacher";
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
