package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Teacher;

public class TeacherDao {
	//��ѯ���е���ʦ
	public List<Teacher> showAllTeacher(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Teacher> t_list = session.createCriteria(Teacher.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("��ѯ���е���ʦ");
		return t_list;
	}
	
	
	public static void main(String[] args) {
		init();
//		showAllTeacher();
	}
	public static void init(){
	Session session = HibernateSessionFactory.getSession();
	Transaction transaction = session.beginTransaction();
	//��ʦ���ݳ�ʼ������
	Teacher t = new Teacher();
	t.settNum("t10001");
	t.settPwd("123");
	t.settName("�׷�");
	t.settSex("��");
	t.settJob("��ʦ");
	session.save(t);
	transaction.commit();
	HibernateSessionFactory.closeSession();
}

}
