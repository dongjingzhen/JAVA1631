package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.P_paper;

public class P_paperDao {
	public static void main(String[] args) {
//		show_paper(1);
	}
	public List<P_paper> show_paper(int sub_id){
		System.out.println("���ݿ�Ŀid��ѯ��Ӧ����");
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		List<P_paper> paperList = session.createCriteria(P_paper.class).add(Restrictions.eq("subject.sub_id", 1)).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		for (P_paper p : paperList) {
			
			System.out.println(p.getpWords()+p.getSubject().getSub_Name());
		}
		return paperList;
	}

}
