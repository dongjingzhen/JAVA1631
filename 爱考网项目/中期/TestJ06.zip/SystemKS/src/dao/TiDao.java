package dao;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Subjectes;

public class TiDao {
	
	//��ѯ���п�Ŀ���ѷ���
	public List<Subjectes> show_subject(){
		System.out.println("��ѯ��Ŀ���׶Σ���Ӧ����");
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		List<Subjectes> subject_list = session.createCriteria(Subjectes.class).list();
		String hql = "SELECT sub FROM Subjectes sub ";
		transaction.commit();
		HibernateSessionFactory.closeSession();
		for (Subjectes ss : subject_list) {
		System.out.println(ss.getSub_Name()+"\t"+ss.getPaper_set().size());
	}
		return subject_list;
	}

	public static void main(String[] args) {  
//		show_subject();
//		show();
	}
//	public static void show(){
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction =  session.beginTransaction();
//		Subjectes s = (Subjectes)session.get(Subjectes.class, 1);
//		List<Subjectes> sub = session.createCriteria(Subjectes.class).list();
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
//		System.out.println(s.getSub_Name()+"\n"+s.getDirection().getDir_name()+"\n"+s.getStage().getSta_name());
//		for (Subjectes ss : sub) {
//			System.out.println(ss.getSub_Name()+"\t");
//		}
//		
//	}

}
