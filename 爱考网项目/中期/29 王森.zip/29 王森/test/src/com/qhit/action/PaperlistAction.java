package com.qhit.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.domain.Paper;
import com.qhit.domain.Question;

public class PaperlistAction implements Action{
	private List<Paper> list;
	
	public List<Paper> getList() {
		return list;
	}

	public void setList(List<Paper> list) {
		this.list = list;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
public String list(){
		
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		list= session.createCriteria(Paper.class).list();
		System.out.println(list.size());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";

		
	}
	

}
