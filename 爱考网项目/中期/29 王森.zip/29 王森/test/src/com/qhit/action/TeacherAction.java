package com.qhit.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.qhit.dao.TeacherDAO;
import com.qhit.domain.Teacher;

public class TeacherAction implements Action {

	private List<Teacher> teacherList;
	public List<Teacher> getTeacherList() {
		return teacherList;
	}



	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}



	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	public String list() throws Exception {
		
		
		TeacherDAO teacherDao = new TeacherDAO();
		teacherList =teacherDao.list();
		return "list";
	}
	
	

}
