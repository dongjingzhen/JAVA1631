package com.qhit.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import tools.HibernateSessionFactory;
import com.opensymphony.xwork2.Action;
import com.qhit.domain.Question;

public class SubjectAction implements Action{
	
	private List<Question> question;
	private List<Question> list;
	

	public List<Question> getList() {
		return list;
	}
	public void setList(List<Question> list) {
		this.list = list;
	}



	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	


public List<Question> getQuestion() {
		return question;
	}



	public void setQuestion(List<Question> question) {
		this.question = question;
	}



public String list() throws Exception {
	String sql = null;
	sql="select subjectId,count(chapter) as typeSize,chapter from question group by subjectId,chapter order by subjectId";
	Session session=HibernateSessionFactory.getSession();
	Transaction transaction=session.beginTransaction();
	
	list= session.createSQLQuery(sql).list();
	
	transaction.commit();
	HibernateSessionFactory.closeSession();
	return "list";
	}
	
	
	

}
