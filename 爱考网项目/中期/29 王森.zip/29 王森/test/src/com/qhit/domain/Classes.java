package com.qhit.domain;

import java.util.Date;

/**
 * Classes entity. @author MyEclipse Persistence Tools
 */

public class Classes implements java.io.Serializable {

	// Fields

	private Integer id;
	private String classNo;
	private String className;
	private String direction;
	private String headteacher;
	private String lecturer;
	private Date date;
	private String state;

	// Constructors

	/** default constructor */
	public Classes() {
	}

	/** full constructor */
	public Classes(String classNo, String className, String direction,
			String headteacher, String lecturer, Date date, String state) {
		this.classNo = classNo;
		this.className = className;
		this.direction = direction;
		this.headteacher = headteacher;
		this.lecturer = lecturer;
		this.date = date;
		this.state = state;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getClassNo() {
		return this.classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getClassName() {
		return this.className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getDirection() {
		return this.direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getHeadteacher() {
		return this.headteacher;
	}

	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}

	public String getLecturer() {
		return this.lecturer;
	}

	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

}