package com.qhit.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Paper implements java.io.Serializable {

	// Fields

	private Integer pid;
	private String subjectName;
	private String kind;
	private String title;
	private String className;
	private Date testTime;
	private Integer testHour;
	private double totalScore;
	private Integer qnumber;
	private String state;
	private Set<Question> ques= new HashSet<Question>();
	private Subject subject;
	private Set<Subject> subjectSet = new HashSet<Subject>();
	
	
	// Constructors

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public Set<Subject> getSubjectSet() {
		return subjectSet;
	}

	public void setSubjectSet(Set<Subject> subjectSet) {
		this.subjectSet = subjectSet;
	}

	public Set<Question> getQues() {
		return ques;
	}

	public void setQues(Set<Question> ques) {
		this.ques = ques;
	}

	/** default constructor */
	public Paper() {
	}

	/** full constructor */
	public Paper(String subjectName, String kind, String title,
			String className, Date testTime, Integer testHour,
			double totalScore, Integer qnumber, String state) {
		this.subjectName = subjectName;
		this.kind = kind;
		this.title = title;
		this.className = className;
		this.testTime = testTime;
		this.testHour = testHour;
		this.totalScore = totalScore;
		this.qnumber = qnumber;
		this.state = state;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getSubjectName() {
		return this.subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getKind() {
		return this.kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getClassName() {
		return this.className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Date getTestTime() {
		return this.testTime;
	}

	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}

	public Integer getTestHour() {
		return this.testHour;
	}

	public void setTestHour(Integer testHour) {
		this.testHour = testHour;
	}

	public double getTotalScore() {
		return this.totalScore;
	}

	public void setTotalScore(double totalScore) {
		this.totalScore = totalScore;
	}

	public Integer getQnumber() {
		return this.qnumber;
	}

	public void setQnumber(Integer qnumber) {
		this.qnumber = qnumber;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

}