package com.qhit.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.domain.Question;

public class QuestionlistAction implements Action {
	private List<Question> list;
	

	public List<Question> getList() {
		return list;
	}
	public void setList(List<Question> list) {
		this.list = list;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public String list(){
		
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		list= session.createCriteria(Question.class).list();
		System.out.println(list.size());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";

		
	}

}
