package com.qhit.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.domain.Admin;
import com.qhit.domain.Question;

import tools.HibernateSessionFactory;


public class as {
	private List<Question> list;
	

	public List<Question> getList() {
		return list;
	}
	public void setList(List<Question> list) {
		this.list = list;
	}
	public static void main(String[] args) {
		as userdao=new as();
		userdao.Select();
		
		
	

}
	public  void Select(){
		String sql =null;
	
		sql="select subjectId,count(chapter) as typeSize,chapter from question group by subjectId,chapter order by subjectId";
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		list = session.createSQLQuery(sql).list();
		System.out.println(list.size());
		
		transaction.commit();
}
}