package com.qhit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.qhit.domain.Teacher;

public class TeacherDAO {
	
	
	
	@SuppressWarnings("unchecked")
	public List<Teacher> list()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Teacher> teacherList =(List<Teacher>) session.createCriteria(Teacher.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return teacherList;
		
	}

}
