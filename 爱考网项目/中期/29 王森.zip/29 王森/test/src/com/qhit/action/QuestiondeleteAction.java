package com.qhit.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.domain.Question;

public class QuestiondeleteAction implements Action {
	private int qid;
		
	


	public int getQid() {
		return qid;
	}

	public void setQid(int qid) {
		this.qid = qid;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String delete()
	{
		
		//删除书籍
		Session session  = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		session.delete(session.get(Question.class,qid));
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "success";
	}
	

}
