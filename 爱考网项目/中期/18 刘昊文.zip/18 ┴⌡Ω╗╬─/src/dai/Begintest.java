package dai;

import java.sql.Timestamp;

public class Begintest {
    private String className;
    private Timestamp testTime;
    private Integer testHour;
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Timestamp getTestTime() {
		return testTime;
	}
	public void setTestTime(Timestamp testTime) {
		this.testTime = testTime;
	}
	public Integer getTestHour() {
		return testHour;
	}
	public void setTestHour(Integer testHour) {
		this.testHour = testHour;
	}
    
    
}
