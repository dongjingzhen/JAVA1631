package dai;

import java.sql.Timestamp;

public class subpaper {
	 private String subjectName;
     private String kind;
     private String title;
     private String className;
     private Timestamp testTime;
     private Integer testHour;
     private int totalScore;
     private Integer qnumber;
     private String state;
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Timestamp getTestTime() {
		return testTime;
	}
	public void setTestTime(Timestamp testTime) {
		this.testTime = testTime;
	}
	public Integer getTestHour() {
		return testHour;
	}
	public void setTestHour(Integer testHour) {
		this.testHour = testHour;
	}

	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public Integer getQnumber() {
		return qnumber;
	}
	public void setQnumber(Integer qnumber) {
		this.qnumber = qnumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
}
