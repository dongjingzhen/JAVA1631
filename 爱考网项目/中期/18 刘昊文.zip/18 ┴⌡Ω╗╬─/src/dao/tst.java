package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Question;
import vo.Subject;

public class tst {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
	
	Question question=new Question();
		Subject subject=new Subject();
		question.setAnswer("asdad");
		subject.setDirection("sss");
		subject.getQuestion().add(question);
		session.save(subject);
		transaction.commit();
		HibernateSessionFactory.closeSession();

	}

}
