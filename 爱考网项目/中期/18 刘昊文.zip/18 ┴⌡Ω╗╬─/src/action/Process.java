package action;

import java.io.UnsupportedEncodingException;

import java.util.List;


import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.Action;

import dai.Levelnum;
import dai.Lguser;

import dao.Dao;
import dao.HibernateSessionFactory;
import vo.Teacher;

public class Process implements Action {
Dao dao =new Dao();
	
private Lguser lguser;
private String type;
private int qual;
private List<Object[]> list;
private Object[] obj;





public Object[] getObj() {
	return obj;
}
public void setObj(Object[] obj) {
	this.obj = obj;
}
public int getQual() {
	return qual;
}
public void setQual(int qual) {
	this.qual = qual;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}

	public List<Object[]> getList() {
	return list;
}
public void setList(List<Object[]> list) {
	this.list = list;
}

	public Lguser getLguser() {
	return lguser;
}
public void setLguser(Lguser lguser) {
	this.lguser = lguser;
}
	@Override
	public String execute() throws Exception {
		// TODO 
		return "yes";
	}

	public String login(){
		qual=dao.login(lguser);
		if(qual!=0){
			return "yes";
		}else{
			return "no";
			  }
		
	}
	
	public String list() {
		System.out.println("list");
		String retn="no";
		System.out.println(type);
		list=dao.daolist(type);
		if(type.equals("question")){
			retn="yesquestion";
		}else if(type.equals("teacher")){
			retn="yesteacher";
		}else if(type.equals("subjectadd")){
			retn="yesaddquestion";
		}else if(type.equals("subjectupd")){
			retn="yesupdatequestion";
		}else if(type.equals("paper")){
			retn="yespaper";
		}else if(type.equals("addpaper")){
			retn="yesaddpaper";
		}else if(type.equals("class")){
			retn="yesclass";
		}else if(type.equals("classadd")){
			retn="yesclassadd";
		}else if(type.equals("begintest")){
			retn="yesbegintest";
		}else if(type.equals("student")){
			retn="yesstudent";
		}
		return retn;
		
	}
	
	public String tiaojianlist(){
		System.out.println("tiaojianlist");
		System.out.println(type+""+qual);
		list=dao.tiaojianlist(qual, type);
		return "yes";
		
	}
	
public String dglist(){
	System.out.println("dglist");
		System.out.println(type+""+qual);
		obj=dao.dglist(qual,type);
		System.out.println(obj[4]);
		String tt="yes";
		if(type.equals("teacher")){
			tt="yesteacher";
		}else if(type.equals("question")){
			tt="yesquestion";
		}else if(type.equals("paper")){
			tt="yespaper";
		}else if(type.equals("class")){
			tt="yesclass";
		}else if(type.equals("student")){
			tt="yesstudent";
		}
		return tt;
		
	}

public String add(){
	System.out.println("add");
	System.out.println(type);
	if(type.equals("paper")){}
	return "yes";
	
}

public String tjlist(){
	System.out.println("tjlist");
list=dao.tjlist(type,qual);
	String tt="no";
	if(type.equals("teacher")){
		tt="yesteacher";
	}else if(type.equals("question")){
		tt="yesquestion";
	}else if(type.equals("paper")){
		tt="yespaper";
	}
	return tt;
}

public String testz(){
	System.out.println(type);
	
	String tt="no";
	if(type.equals("teacher")){
		tt="yesteacher";
	}else if(type.equals("question")){
		tt="yesquestion";
	}else if(type.equals("paper")){
		tt="yespaper";
	}
	return tt;
	
}


}
