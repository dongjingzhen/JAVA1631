package dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Students;

import com.opensymphony.xwork2.Action;

public class StudentAction implements Action{
	private int id;
	private String name;
	private String pwd;
	private List<Students> studentList;//���մ����ݿ��ѯ��Student����
	private int role;//����loginҳ�����������value
	
	
	
	
	
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public List<Students> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Students> studentList) {
		this.studentList = studentList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public String Login(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		switch (role) {
		
		case 1:
			studentList = session.createCriteria(Students.class).list();
			for (Students student : studentList) {
				if (student.getStuNo().equals(name) && student.getStuPwd().equals(pwd)) {
				System.out.println(student.getId());
					return SUCCESS;
				}
			}
		}
		// ��ʼ����
		transaction.commit();
		return "worry";
	}
	
	//������Ϣ��ѯ
	public String studentSelf(){
		// �������� ����session �Ự����
		Session session=HibernateSessionFactory.getSession();
		// ��session
		Transaction transaction=session.beginTransaction();
		
		Students students =  (Students) session.get(Students.class, id);
		System.out.println(id);
		
		// ��ʼ����
		transaction.commit();
		return SUCCESS;
		
		
	}
	
	
	

}
