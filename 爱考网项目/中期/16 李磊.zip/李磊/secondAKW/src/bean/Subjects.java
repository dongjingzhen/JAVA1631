package bean;

import java.util.HashSet;
import java.util.Set;

public class Subjects {
	private int id;//��Ŀid
	private String direction;//�Ͷ�����
	private String stage;//�׶�
	private String subjectId;//��Ŀ����
	private Set<Question> question = new HashSet<Question>();
	
	public Set<Question> getQuestion() {
		return question;
	}
	public void setQuestion(Set<Question> question) {
		this.question = question;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	
	
	
	

}
