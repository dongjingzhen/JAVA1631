package bean;

public class ChuanZhi {
	private int DJ;
	private int DK;
	private int DY;
	private int dj;
	private int dk;
	private int dy;
	public int getDJ() {
		return DJ;
	}
	public void setDJ(int dJ) {
		DJ = dJ;
	}
	public int getDK() {
		return DK;
	}
	public void setDK(int dK) {
		DK = dK;
	}
	public int getDY() {
		return DY;
	}
	public void setDY(int dY) {
		DY = dY;
	}
	public int getDj() {
		return dj;
	}
	public void setDj(int dj) {
		this.dj = dj;
	}
	public int getDk() {
		return dk;
	}
	public void setDk(int dk) {
		this.dk = dk;
	}
	public int getDy() {
		return dy;
	}
	public void setDy(int dy) {
		this.dy = dy;
	}
	
	

}
