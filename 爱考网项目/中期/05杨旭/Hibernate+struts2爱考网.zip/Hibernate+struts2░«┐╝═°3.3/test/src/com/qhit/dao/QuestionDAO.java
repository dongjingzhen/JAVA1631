package com.qhit.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.qhit.domain.Question;

public class QuestionDAO {

	   public static Object get(Class clazz, int id) {  
	        Session session = null;  
	        try {  
	            session = HibernateSessionFactory.getSession();  
	            Object obj = session.get(clazz, id);  
	            session.delete(obj);
	            return obj;  
	        } finally {  
	            if (session != null) {  
	                session.close();  
	            }  
	        }  
	    }
	   public static void main(String[] args) {
		
		   get(Question.class, 1);
	}
}
