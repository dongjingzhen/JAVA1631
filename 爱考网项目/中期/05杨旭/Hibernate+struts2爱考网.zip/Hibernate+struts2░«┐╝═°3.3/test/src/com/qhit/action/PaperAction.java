package com.qhit.action;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.domain.Classes;
import com.qhit.domain.Paper;
import com.qhit.domain.Question;
import com.qhit.domain.Students;

public class PaperAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	private Paper paper;
	private List list;
	
	
	private int simpleNum;
	private int ordinaryNum;
	private int difficultyNum;
	
	private Question question;
	
	private List<Object> kindList;
	private List<Object> subjectList;
	private List<Object> chaperList;
	
	private List<Object> classList;
	
	private List<Object[]> lists;
	

	public List<Object[]> getLists() {
		return lists;
	}
	public void setLists(List<Object[]> lists) {
		this.lists = lists;
	}
	public List<Object> getClassList() {
		return classList;
	}
	public void setClassList(List<Object> classList) {
		this.classList = classList;
	}
	public List<Object> getKindList() {
		return kindList;
	}
	public void setKindList(List<Object> kindList) {
		this.kindList = kindList;
	}
	public List<Object> getSubjectList() {
		return subjectList;
	}
	public void setSubjectList(List<Object> subjectList) {
		this.subjectList = subjectList;
	}
	public List<Object> getChaperList() {
		return chaperList;
	}
	public void setChaperList(List<Object> chaperList) {
		this.chaperList = chaperList;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public int getSimpleNum() {
		return simpleNum;
	}
	public void setSimpleNum(int simpleNum) {
		this.simpleNum = simpleNum;
	}
	public int getOrdinaryNum() {
		return ordinaryNum;
	}
	public void setOrdinaryNum(int ordinaryNum) {
		this.ordinaryNum = ordinaryNum;
	}
	public int getDifficultyNum() {
		return difficultyNum;
	}
	public void setDifficultyNum(int difficultyNum) {
		this.difficultyNum = difficultyNum;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	
	public String updateClass(){
		
		 
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		Paper pa = (Paper) session.get(Paper.class, paper.getPid());
		pa.setClassNo(paper.getClassNo());
		pa.setTestTime(paper.getTestTime());
		pa.setState("考试中");
		
		String sql ="select id from students where Classes_id in(select id from Classes where classNo ='"+paper.getClassNo()+"' )";
		List<Object> ob =  session.createSQLQuery(sql).list(); 
		for (Object objects : ob) {
			Students stu = (Students) session.get(Students.class, (Serializable) objects);
			pa.getStu().add(stu);
		}
		session.saveOrUpdate(pa);
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "input";
	}
	
	public String show(){
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		lists =session.createSQLQuery("select *from " +
				"question where qid " +
				"in(select qid from paper_question " +
				"where pid="+paper.getPid()+")").list();
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "list";
	}
	
	public String intostartExamWeb(){
		
		 
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		classList =  session.createSQLQuery("select distinct classNo from classes ").list();
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "input";
	}
	
	public String intoRandom(){
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		subjectList = session.createSQLQuery("select distinct subjectid from question").list();
		chaperList = session.createSQLQuery("select distinct chapter from question").list();
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "input";
	}
	

	public String suiji(){
		
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		Paper p =new Paper();
		p.setTitle(paper.getTitle());
		p.setKind("笔试");
		p.setSubjectid(paper.getSubjectid());
		p.setChapter(paper.getChapter());
		p.setState(paper.getState());
		p.setTestHour(paper.getTestHour());
		p.setTotalScore(paper.getTotalScore());
		p.setQnumber(paper.getQnumber());
		String sql ="select top "+simpleNum+" qid, newId() from question where difficulty='简单' "
		+" union all select top "+ordinaryNum+" qid, newId() from question where difficulty= '普通' "
		+" union all select top "+difficultyNum+" qid, newId() from question where difficulty= '困难' "
		+" order by newid()";
		
		List<Object[]> list =  session.createSQLQuery(sql).list();
		
		for (Object[] objects : list) {
			System.out.println(objects[0]);
			Question q= (Question) session.get(Question.class,(Serializable) objects[0] );
			p.getQues().add(q);
		}
		session.save(p);
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "list";
	}

	
	public String list(){
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		list = session.createCriteria(Paper.class).list();
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "list";
	}
	
	public static void main(String[] args) {
		
		
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		Paper pa = (Paper) session.get(Paper.class,1);
		pa.setClassNo("G1T01");
		pa.setTestTime("2018,01,01");
		pa.setState("考试中");
		
		String sql ="select id from students where Classes_id in(select id from classes where classNo = 'G1T01' )";
		List<Object> ob =  session.createSQLQuery(sql).list();

		
		for (Object objects : ob) {
			System.out.println(objects);
			Students stu = (Students) session.get(Students.class, (Serializable) objects);
			pa.getStu().add(stu);
		}
		session.saveOrUpdate(pa);
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
	}
}
