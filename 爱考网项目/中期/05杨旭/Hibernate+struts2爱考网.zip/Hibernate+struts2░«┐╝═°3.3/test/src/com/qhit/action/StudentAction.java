package com.qhit.action;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.domain.Classes;
import com.qhit.domain.Paper;
import com.qhit.domain.Students;
import com.sun.org.apache.regexp.internal.recompile;

public class StudentAction implements Action {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	private Students students;
	
	private Paper paper;
	
	
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public Students getStudents() {
		return students;
	}
	public void setStudents(Students students) {
		this.students = students;
	}
	
	private List<Object[]> lists;
	
	
	public List<Object[]> getLists() {
		return lists;
	}
	public void setLists(List<Object[]> lists) {
		this.lists = lists;
	}
	private List list;
	private List<Object[]> paperList;
	
	public List<Object[]> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Object[]> paperList) {
		this.paperList = paperList;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	
	public String stuQueExam(){
		
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		lists =session.createSQLQuery("select *from " +
				"question where qid " +
				"in(select qid from paper_question " +
				"where pid="+paper.getPid()+")").list();
		
		
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		return "input";
	}
	
	public String studentPaper(){
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		paperList = session.createSQLQuery("select *from paper where pid in(select pid from paper_students where id = "+students.getId()+")").list();
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
		
		return "list";
	}

	
	public String list(){
		 
			Session session = HibernateSessionFactory.getSession();
			
			Transaction transaction = session.beginTransaction();
			
			list  = session.createCriteria(Students.class).list();
			
			transaction.commit();
			
			HibernateSessionFactory.closeSession();
		 return "list";
	 }
	public static void main(String[] args) {
		Session session = HibernateSessionFactory.getSession();
		
		Transaction transaction = session.beginTransaction();
		
		
		
		
		transaction.commit();
		
		HibernateSessionFactory.closeSession();
	}
}
