package com.qhit.domain;

import java.util.HashSet;
import java.util.Set;

public class Classes {

	
	private int id;
	private String classNo;
	private String className;
	private String direction;//方向
	private String headteacher;//班主任
	private String lecturer;//讲师
	private String createTime;//班级创建时间
	private String state;//状态
	
	private Set<Students> stu = new HashSet<Students>();
	
	
	public Set<Students> getStu() {
		return stu;
	}
	public void setStu(Set<Students> stu) {
		this.stu = stu;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassNo() {
		return classNo;
	}
	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getHeadteacher() {
		return headteacher;
	}
	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}
	public String getLecturer() {
		return lecturer;
	}
	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
