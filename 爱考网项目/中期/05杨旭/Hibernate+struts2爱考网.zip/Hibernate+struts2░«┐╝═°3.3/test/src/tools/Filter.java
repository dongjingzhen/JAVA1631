package tools;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Filter implements javax.servlet.Filter {

	@Override
	public void destroy() {
		System.out.println("处理编码过滤器被销毁");
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse ServletResponse,
			FilterChain filterChain) throws IOException, ServletException {
		servletRequest.setCharacterEncoding("utf-8");
		filterChain.doFilter(servletRequest, ServletResponse);
		System.out.println("处理编码过滤器执行");

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("处理编码过滤器创建");
	}


}
