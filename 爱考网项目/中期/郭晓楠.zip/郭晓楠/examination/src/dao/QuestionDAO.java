package dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.extremecomponents.table.context.HttpServletRequestContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import beans.HibernateUtils;
import beans.Question;
import beans.Teacher;
import beans.UserLogin;

public class QuestionDAO {
	public List<Question> list(){
		List<Question> list =(List<Question>) HibernateUtils.getSession().createCriteria(Question.class).list();
		HibernateUtils.getSession().beginTransaction().commit();
		return list;
	}
	public List<Question> questionlist(String types){
		String hql = "SELECT q FROM Question q WHERE q.types LIKE :stdName ";
		List<Question> questionlist = HibernateUtils.getSession().createQuery(hql).setString("stdName",types).list();
		return questionlist;
	} 
	public List<Object[]> select(){
		
		String hql = "SELECT subject,types,count(types) FROM Question q GROUP BY subject,types";
		List<Object[]> questionList = HibernateUtils.getSession().createQuery(hql).list();
		
		return (List<Object[]>) questionList;
	}
}
