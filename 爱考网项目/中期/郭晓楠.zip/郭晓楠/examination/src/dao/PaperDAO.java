package dao;

import java.util.List;

import org.hibernate.Query;


import beans.Classes;
import beans.Count;
import beans.HibernateUtils;
import beans.Question;
import beans.paper;

public class PaperDAO {
	public List<paper> list(){
		List<paper> list =(List<paper>) HibernateUtils.getSession().createCriteria(paper.class).list();
		HibernateUtils.getSession().beginTransaction().commit();
		return list;
	}
	public List<Object[]> paperInsert(Count c,paper pa){
		String  sql ="select top  "+c.getCountJ()+"  qid, newId() from question where difficulty= '��' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all ";
		sql+=" select top  "+c.getCountZ()+"  qid, newId() from question where difficulty= '�е�' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all  ";
		sql+=" select top  "+c.getCountK()+"  qid, newId() from question where difficulty= '����' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all  ";
		sql+=" select top  "+c.getCountsJ()+" qid, newId() from question where difficulty= '��' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all  ";
		sql+=" select top  "+c.getCountsZ()+" qid, newId() from question where difficulty= '�е�' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all  ";
		sql+=" select top  "+c.getCountsK()+" qid, newId() from question where difficulty= '����' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" order by newid()";
		List<Object[]> qidlist = HibernateUtils.getSession().createSQLQuery(sql).list();
		return qidlist;
	}
	public List<Object[]> selectlist(int pid){
		String sql = "select distinct q.qid,q.type,q.content,q.optionA,q.optionB,q.optionC,q.optionD,p.subjectName,p.testHour,p.totalScore from question q,t_questions_paper t,paper p where t.paper_id="+pid+" and q.qid=t.question_id and p.pid=t.paper_id";
		List<Object[]> list = HibernateUtils.getSession().createSQLQuery(sql).list();
		return list;
	}
	public void update(int pid){
		String hql  = "update paper p  set p.className='java1631',p.testTime='2017-08-08',p.state=1 where p.pid="+pid;
		Query q = HibernateUtils.getSession().createQuery(hql);
		q.executeUpdate();
	}
	//�༶���Է���
	public List<Object[]> calsses(){
		String sql="select *from classes ";
		List<Object[]> classes =  HibernateUtils.getSession().createSQLQuery(sql).list();
		HibernateUtils.getSession().beginTransaction().commit();
		return classes;
		
	}
}
