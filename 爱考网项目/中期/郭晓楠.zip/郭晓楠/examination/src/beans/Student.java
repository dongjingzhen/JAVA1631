package beans;

public class Student {
	private int stuid;
	private String stuNo;
	private String stupwd;
	private String classId;
	private String stuname;
	private String stusex;
	private String stutel;
	private String stuyear;
	private String stuID;
	private String studay;
	private String stushengfen;//ʡ��
	private String stuzhuxiu;
	private String stuparent;//��������
	private String stusushe;
	private String stususheNO;
	private String stuguardian;//�໤��
	private String stuaddress;
	private String studiretion;//����
	private String stupolitical;//������ò
	private Classes classes ;
	private UserLogin users;
	
	public String getStutel() {
		return stutel;
	}
	public void setStutel(String stutel) {
		this.stutel = stutel;
	}
	public int getStuid() {
		return stuid;
	}
	public void setStuid(int stuid) {
		this.stuid = stuid;
	}
	public String getStuNo() {
		return stuNo;
	}
	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}
	public String getStupwd() {
		return stupwd;
	}
	public void setStupwd(String stupwd) {
		this.stupwd = stupwd;
	}
	public String getClassId() {
		return classId;
	}
	public void setClassId(String classId) {
		this.classId = classId;
	}
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}
	public String getStusex() {
		return stusex;
	}
	public void setStusex(String stusex) {
		this.stusex = stusex;
	}
	public String getStuyear() {
		return stuyear;
	}
	public void setStuyear(String stuyear) {
		this.stuyear = stuyear;
	}
	public String getStuID() {
		return stuID;
	}
	public void setStuID(String stuID) {
		this.stuID = stuID;
	}
	public String getStuday() {
		return studay;
	}
	public void setStuday(String studay) {
		this.studay = studay;
	}
	public String getStushengfen() {
		return stushengfen;
	}
	public void setStushengfen(String stushengfen) {
		this.stushengfen = stushengfen;
	}
	public String getStuzhuxiu() {
		return stuzhuxiu;
	}
	public void setStuzhuxiu(String stuzhuxiu) {
		this.stuzhuxiu = stuzhuxiu;
	}
	public String getStuparent() {
		return stuparent;
	}
	public void setStuparent(String stuparent) {
		this.stuparent = stuparent;
	}
	public String getStusushe() {
		return stusushe;
	}
	public void setStusushe(String stusushe) {
		this.stusushe = stusushe;
	}
	public String getStususheNO() {
		return stususheNO;
	}
	public void setStususheNO(String stususheNO) {
		this.stususheNO = stususheNO;
	}
	public String getStuguardian() {
		return stuguardian;
	}
	public void setStuguardian(String stuguardian) {
		this.stuguardian = stuguardian;
	}
	public String getStuaddress() {
		return stuaddress;
	}
	public void setStuaddress(String stuaddress) {
		this.stuaddress = stuaddress;
	}
	public String getStudiretion() {
		return studiretion;
	}
	public void setStudiretion(String studiretion) {
		this.studiretion = studiretion;
	}
	public String getStupolitical() {
		return stupolitical;
	}
	public void setStupolitical(String stupolitical) {
		this.stupolitical = stupolitical;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public UserLogin getUsers() {
		return users;
	}
	public void setUsers(UserLogin users) {
		this.users = users;
	}
	
}
