package action;

import java.util.List;



import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import beans.Teacher;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.TeacherDAO;

public class TeacherAction implements Action {
	private List<Teacher> teacherList;
	private Teacher teachers;
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String list(){
		TeacherDAO dao = new TeacherDAO();
		teacherList = dao.list();
		return "list";
	}
	public String update(){
		Session session  = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Teacher teacher = (Teacher) session.get(Teacher.class,teachers.getTid());
		session.update(teacher);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return SUCCESS;
		
	}
/*
 * get��set����
 */
	
	
	
	public List<Teacher> getTeacherList() {
		return teacherList;
	}
	public Teacher getTeachers() {
		return teachers;
	}
	public void setTeachers(Teacher teachers) {
		this.teachers = teachers;
	}
	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}
	
}
