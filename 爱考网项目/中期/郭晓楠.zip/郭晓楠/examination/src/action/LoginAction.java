package action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;

import beans.HibernateUtils;
import beans.Role;
import beans.Student;
import beans.UserLogin;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.StudentDAO;

public class LoginAction implements Action {
	private String loginName;
	private String loginPwd;
	private String stuname;
	private String stupwd;
	private String rname;
	private List<Role> roleList;
	private List<UserLogin> userList;
	private UserLogin userLogin;
	private String ceshi;
	private String role;
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String login(){
		HttpServletRequest request = ServletActionContext.getRequest();
		StudentDAO dao = new StudentDAO();
		String loginName = request.getParameter("loginName");
		String loginPwd = request.getParameter("loginPwd");
		String stuname = request.getParameter("loginName");
		String stupwd = request.getParameter("loginPwd");
		String rname = request.getParameter("rname");
		
		if (rname.equals("xs")) {
			int xs = dao.selectStudent(stuname,stupwd);
			if (xs>0) {
				ceshi="XS";
			}
		}
		if (rname.equals("gl")) {
			int gl = dao.selectAdmin(loginName,loginPwd);
			if (gl>0) {
				ceshi="GL";
			}
		}
		HibernateUtils.getSession().beginTransaction().commit();
		request.setAttribute("role", ceshi);
		System.out.println(ceshi);
		return ceshi;
	}
	private int lists() {
		// TODO Auto-generated method stub
		String hql = "SELECT s FROM UserLogin s WHERE s.loginName LIKE? ";
		List<UserLogin> userList = HibernateUtils.getSession().createQuery(hql).setString(0,loginName).list();
		int i = userList.size();
		HibernateUtils.getSession().beginTransaction().commit();
		return i;
	}

	
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public List<Role> getRoleList() {
		return roleList;
	}
	public void setRoleList(List<Role> roleList) {
		this.roleList = roleList;
	}
	public List<UserLogin> getUserList() {
		return userList;
	}
	public void setUserList(List<UserLogin> userList) {
		this.userList = userList;
	}
	public UserLogin getUserLogin() {
		return userLogin;
	}
	public void setUserLogin(UserLogin userLogin) {
		this.userLogin = userLogin;
	}
	public String getCeshi() {
		return ceshi;
	}
	public void setCeshi(String ceshi) {
		this.ceshi = ceshi;
	}
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}
	public String getStupwd() {
		return stupwd;
	}
	public void setStupwd(String stupwd) {
		this.stupwd = stupwd;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
}
