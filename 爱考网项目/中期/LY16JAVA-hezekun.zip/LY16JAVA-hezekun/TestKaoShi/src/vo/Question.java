package vo;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 98707
 *	����
 */
public class Question {
	private int q_id;//����
	private String q_type;//��ѡor��ѡ
	private String q_question;//����
	private String ansA;//ѡ��A
	private String ansB;//ѡ��B
	private String ansC;//ѡ��C
	private String ansD;//ѡ��D
	private String results;//�ύ�Ĵ�
	private String answer;//��ȷ��
	private String q_nandu;//�����Ѷ�
	private String q_testType;//��������  ����or����
	//���Ծ���Զ��ϵ
	private List<Paper> paperList = new ArrayList<Paper>();
	
	
	
	public String getResults() {
		return results;
	}

	public void setResults(String results) {
		this.results = results;
	}

	public String getQ_testType() {
		return q_testType;
	}

	public void setQ_testType(String qTestType) {
		q_testType = qTestType;
	}

	public int getQ_id() {
		return q_id;
	}

	public void setQ_id(int qId) {
		q_id = qId;
	}

	public String getQ_type() {
		return q_type;
	}

	public void setQ_type(String qType) {
		q_type = qType;
	}

	public String getQ_question() {
		return q_question;
	}

	public void setQ_question(String qQuestion) {
		q_question = qQuestion;
	}

	public String getAnsA() {
		return ansA;
	}

	public void setAnsA(String ansA) {
		this.ansA = ansA;
	}

	public String getAnsB() {
		return ansB;
	}

	public void setAnsB(String ansB) {
		this.ansB = ansB;
	}

	public String getAnsC() {
		return ansC;
	}

	public void setAnsC(String ansC) {
		this.ansC = ansC;
	}

	public String getAnsD() {
		return ansD;
	}

	public void setAnsD(String ansD) {
		this.ansD = ansD;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getQ_nandu() {
		return q_nandu;
	}

	public void setQ_nandu(String qNandu) {
		q_nandu = qNandu;
	}

	public List<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	
	
	
	
}
