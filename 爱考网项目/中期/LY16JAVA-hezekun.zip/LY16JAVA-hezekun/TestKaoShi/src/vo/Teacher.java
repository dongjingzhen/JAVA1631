package vo;
/**
 * @author 98707
 *	��ʦ��
 */
public class Teacher {
	private int t_id;//����
	private String t_accNo;//��ʦ����
	private String t_name;//��ʦ����
	private String t_pwd;//��ʦ����
	private String sex;//�Ա�
	private String t_tell;//��ʦ�绰
	private String t_job;//��ʦְҵ����ʦor�����Σ�
	
	
	
	
	public int getT_id() {
		return t_id;
	}
	public void setT_id(int tId) {
		t_id = tId;
	}
	public String getT_accNo() {
		return t_accNo;
	}
	public void setT_accNo(String tAccNo) {
		t_accNo = tAccNo;
	}
	public String getT_name() {
		return t_name;
	}
	public void setT_name(String tName) {
		t_name = tName;
	}
	public String getT_pwd() {
		return t_pwd;
	}
	public void setT_pwd(String tPwd) {
		t_pwd = tPwd;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getT_tell() {
		return t_tell;
	}
	public void setT_tell(String tTell) {
		t_tell = tTell;
	}
	public String getT_job() {
		return t_job;
	}
	public void setT_job(String tJob) {
		t_job = tJob;
	}
	
	
	
}
