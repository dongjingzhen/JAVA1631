package vo;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 98707
 *	�Ծ���
 */
public class Paper {
	private int p_id;//����
	private String p_title;//��������
	private String p_fangxiang;//רҵ����java����ʦ or����Ӫ��
	private String p_jieduan;//�׶�G1 G2 G3
	private String p_kemu;//Struts2��Hibernate��C++
	private String p_testType;
	private long beginTime;
	private long endTime;
	
	
	
	
	//�������Զ��ϵ
	private List<Question> questionList = new ArrayList<Question>();
	
	//��༶��Զ��ϵ
	private List<Classes> classesList = new ArrayList<Classes>();
	
	
	public String getP_testType() {
		return p_testType;
	}
	public void setP_testType(String pTestType) {
		p_testType = pTestType;
	}
	public long getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(long beginTime) {
		this.beginTime = beginTime;
	}
	public long getEndTime() {
		return endTime;
	}
	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}
	public List<Classes> getClassesList() {
		return classesList;
	}
	public void setClassesList(List<Classes> classesList) {
		this.classesList = classesList;
	}
	public List<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int pId) {
		p_id = pId;
	}
	public String getP_title() {
		return p_title;
	}
	public void setP_title(String pTitle) {
		p_title = pTitle;
	}
	public String getP_fangxiang() {
		return p_fangxiang;
	}
	public void setP_fangxiang(String pFangxiang) {
		p_fangxiang = pFangxiang;
	}
	public String getP_jieduan() {
		return p_jieduan;
	}
	public void setP_jieduan(String pJieduan) {
		p_jieduan = pJieduan;
	}
	public String getP_kemu() {
		return p_kemu;
	}
	public void setP_kemu(String pKemu) {
		p_kemu = pKemu;
	}
	
	
}
