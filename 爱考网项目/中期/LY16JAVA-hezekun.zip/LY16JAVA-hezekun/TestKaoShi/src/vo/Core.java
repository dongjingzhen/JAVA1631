package vo;
/**
 * @author 98707
 *	�ɼ���
 */
public class Core {
	private int c_id;
	private String c_stuNo;
	private String c_questionId;
	private int c_zongtishu;
	private int c_zhengqueshu;
	private double c_meitifenshu;
	private double c_zongfen;
}
