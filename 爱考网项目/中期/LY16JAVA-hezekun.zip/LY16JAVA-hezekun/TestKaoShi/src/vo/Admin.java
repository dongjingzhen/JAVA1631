package vo;
/**
 * @author 98707
 * ����Ա
 */
public class Admin {
	private int a_id;//����Աid
	private String a_acc;//����Ա�˺�
	private String a_pwd;//����Ա����
	public int getA_id() {
		return a_id;
	}
	public void setA_id(int aId) {
		a_id = aId;
	}
	public String getA_acc() {
		return a_acc;
	}
	public void setA_acc(String aAcc) {
		a_acc = aAcc;
	}
	public String getA_pwd() {
		return a_pwd;
	}
	public void setA_pwd(String aPwd) {
		a_pwd = aPwd;
	}
	
	
}
