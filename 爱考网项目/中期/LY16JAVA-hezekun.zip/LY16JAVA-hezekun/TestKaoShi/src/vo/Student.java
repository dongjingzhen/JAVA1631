package vo;
/**
 * @author 98707
 *	ѧ����
 */
public class Student {
	private int s_id;//ѧ��������
	private String s_stuNo;//ѧ��
	private String s_name;//ѧ������
	private String s_pwd;//����
	private String sex;//�Ա�
	private String s_tell;//ѧ���绰
	private Classes s_classesId;//�༶ID
	
	
	
	public Classes getS_classesId() {
		return s_classesId;
	}
	public void setS_classesId(Classes sClassesId) {
		s_classesId = sClassesId;
	}
	public int getS_id() {
		return s_id;
	}
	public void setS_id(int sId) {
		s_id = sId;
	}
	public String getS_stuNo() {
		return s_stuNo;
	}
	public void setS_stuNo(String sStuNo) {
		s_stuNo = sStuNo;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String sName) {
		s_name = sName;
	}
	public String getS_pwd() {
		return s_pwd;
	}
	public void setS_pwd(String sPwd) {
		s_pwd = sPwd;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getS_tell() {
		return s_tell;
	}
	public void setS_tell(String sTell) {
		s_tell = sTell;
	}
	
	
	
}
