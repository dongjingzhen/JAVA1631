package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Admin;
import vo.Student;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.Dao;
import dao.HibernateSessionFactory;

public class LoginAction implements Action {
@Override public String execute() throws Exception {return null;}
	
	private String tex;
	private List<Admin> adminList;
	private List<Teacher> teacherList;
	private List<Student> studentList;
	private String err;
	private String accNo;
	private String pwd;
	private String name;
	private int id;
	
	
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public int getId() {return id;}
	public void setId(int id) {this.id = id;}
	public String getTex(){return tex;}
	public void setTex(String tex){this.tex = tex;}
	public List<Admin> getAdminList(){return adminList;}
	public void setAdminList(List<Admin> adminList){this.adminList = adminList;}
	public List<Teacher> getTeacherList(){return teacherList;}
	public void setTeacherList(List<Teacher> teacherList){this.teacherList = teacherList;}
	public List<Student> getStudentList(){return studentList;}
	public void setStudentList(List<Student> studentList){this.studentList = studentList;}
	public String getErr(){return err;}
	public void setErr(String err){this.err = err;}
	public String getAccNo(){return accNo;}
	public void setAccNo(String accNo){this.accNo = accNo;}
	public String getPwd(){return pwd;}
	public void setPwd(String pwd){this.pwd = pwd;}
	
			
	/**
	 *	��¼����
	 */
	public String Login(){
		String result = "erro";
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		if (tex.equals("admin")) {
			adminList = session.createCriteria(Admin.class).list();
			for (Admin a : adminList) {
				if (a.getA_acc().equals(accNo)) {
					if (a.getA_pwd().equals(pwd)) {
						name=a.getA_acc();
						id=a.getA_id();
						ServletActionContext.getRequest().getSession().setAttribute("name",name);
						ServletActionContext.getRequest().getSession().setAttribute("id",id);
						result ="login";
					}
				}
			}
		}
		if (tex.equals("student")) {
			studentList = session.createCriteria(Student.class).list();
			for (Student s : studentList) {
				if (s.getS_stuNo().equals(accNo)) {
					if (s.getS_pwd().equals(pwd)) {
						name=s.getS_name();
						id=s.getS_id();
						ServletActionContext.getRequest().getSession().setAttribute("name",name);
						ServletActionContext.getRequest().getSession().setAttribute("id",id);
						result ="login";
					}
				}
			}
		}
		if (tex.equals("teacher")) {
			teacherList = session.createCriteria(Teacher.class).list();
			for (Teacher t : teacherList) {
				if (t.getT_accNo().equals(accNo)) {
					if (t.getT_pwd().equals(pwd)) {
						name = t.getT_name();
						id = t.getT_id();
						ServletActionContext.getRequest().getSession().setAttribute("name",name);
						ServletActionContext.getRequest().getSession().setAttribute("id",id);
						result ="login";
					}
				}
			}
		}
		err="�û�����������������������µ�½������";
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return result;
	}


}
