package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Paper;
import vo.Question;

import com.opensymphony.xwork2.Action;

import dao.Dao;
import dao.HibernateSessionFactory;

public class SubjectAction implements Action{
@Override public String execute() throws Exception {return null;}
	private List<Object[]> slist;
	private List<Question> qList;
	private String kemu;
	private String jieduan;
	private Question q;
	private List<Paper> paperList;
	private int paperId;
	private Paper paper;
	private List<Classes> clist;
	
	
	public List<Classes> getClist() {return clist;}
	public void setClist(List<Classes> clist) {this.clist = clist;}
	public Paper getPaper() {return paper;}
	public void setPaper(Paper paper) {this.paper = paper;}
	public int getPaperId() {return paperId;}
	public void setPaperId(int paperId) {this.paperId = paperId;}
	public List<Paper> getPaperList() {return paperList;}
	public void setPaperList(List<Paper> paperList) {this.paperList = paperList;}
	public Question getQ() {return q;}
	public void setQ(Question q) {this.q = q;}
	public String getKemu() {return kemu;}
	public void setKemu(String kemu) {this.kemu = kemu;}
	public String getJieduan() {return jieduan;}
	public void setJieduan(String jieduan) {this.jieduan = jieduan;}
	public List<Object[]> getSlist() {return slist;}
	public void setSlist(List<Object[]> slist) {this.slist = slist;}
	public List<Question> getqList() {return qList;}
	public void setqList(List<Question> qList) {this.qList = qList;}
	
	
	/*
	 * ��ѯ���
	 * ��Ŀ ��      �׶Σ�
	 * ���ԣ�0
	 * ���ԣ�0
	 */
	public String selectTiKu(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String hql = "select count(q.q_testType) as num,p.p_kemu,p.p_jieduan from Question q left join q.paperList p " +
//		"where q_testType="+testType+" and p.p_kemu="+keMu+" and p.p_jieduan="+jieDuan+
		"group by p_kemu,p_jieduan";
		slist =  session.createQuery(hql).list();
		ServletActionContext.getRequest().setAttribute("sList", "sList");
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "selectTi";
	}
	
	
	/*
	 * ��ѯ����
	 */
	public String selectQuestion(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		qList = session.createCriteria(Question.class)
													.setFetchMode("paperList",FetchMode.JOIN)
													.createAlias("paperList", "p")
													.add(Restrictions.eq("p.p_kemu",kemu))
													.add(Restrictions.eq("p.p_jieduan", jieduan))
													.list();
		ServletActionContext.getRequest().getSession().setAttribute("kemu",kemu);
		ServletActionContext.getRequest().getSession().setAttribute("jieduan",jieduan);
		ServletActionContext.getRequest().getSession().setAttribute("qList", qList);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "selectquestion";
	}
	
	
	
	
	/*
	 *	�������� 
	 */
	public String questionAdd(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Paper.class)
															.add(Restrictions.eq("p_kemu", kemu))
															.add(Restrictions.eq("p_jieduan", jieduan));
		ProjectionList projectionList = Projections.projectionList().add(Projections.property("p_id"));
		System.out.println(kemu.toString()+jieduan.toString());
		List<Object> list =(List<Object>) criteria.setProjection(projectionList).list();
		int i = (Integer)list.get(0);
		Paper p = (Paper)session.get(Paper.class, i);
		session.save(q);
		p.getQuestionList().add(q);
		session.saveOrUpdate(p);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "add";
	}
	
	
	
	
	/*
	 * ��ѯ�Ծ�
	 */
	public String selectPaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paperList = session.createCriteria(Paper.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "pap";
	}
	
	
	
	/*
	 *	�鿴������Ϣ
	 */
	public String selectTest(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		//�жϿ���״̬
		paper = (Paper)session.get(Paper.class, paperId);
		//���԰༶
		clist = session.createCriteria(Classes.class)
													.setFetchMode("paperList", FetchMode.JOIN)
													.createAlias("paperList", "p")
													.add(Restrictions.eq("p.p_title",kemu))
													.add(Restrictions.eq("p.p_jieduan",jieduan))
													.list();
		for (Classes c : clist) {
			System.out.println(c.getC_className());
			System.out.println(c.getC_classNo());
		}
		
		
		ServletActionContext.getRequest().getSession().setAttribute("paper",paper);
		ServletActionContext.getRequest().getSession().setAttribute("clist",clist);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "selTest";
	}
	
	
	
	
	
}
