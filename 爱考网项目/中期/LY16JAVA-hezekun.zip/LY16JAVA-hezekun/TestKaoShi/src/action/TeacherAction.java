package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class TeacherAction implements Action{
@Override public String execute() throws Exception {return null;}
	
	private int dId;
	private List<Teacher> tList;
	public List<Teacher> gettList() {return tList;}
	public void settList(List<Teacher> tList) {this.tList = tList;}
	public int getdId() {return dId;}
	public void setdId(int dId) {this.dId = dId;}
	
	
	/*
	 * ��ѯ��ʦ
	 */
	public String selectTeacher(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Teacher> tList;
		tList = (List<Teacher>)session.createCriteria(Teacher.class)
				.list();
		ServletActionContext.getRequest().getSession().setAttribute("tList", tList);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "tlist";
	}
	/*
	 * ɾ����ʦ 
	 */
	public String deleteTeacher(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		dId = (Integer) ServletActionContext.getRequest().getAttribute("dId");
		System.out.println(dId);
		Teacher teacher = (Teacher)session.get(Teacher.class, dId);
		session.delete(teacher);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "deleteT";
	}
	/*
	 * �޸Ľ�ʦ
	 */
	public String updateTeacher(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		List<Teacher> tList;
		tList = (List<Teacher>)session.createCriteria(Teacher.class)
																.list();
		ServletActionContext.getRequest().getSession().setAttribute("tList", tList);
		session.update(tList.get(dId));
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "updateT";
	}
	
	
}
