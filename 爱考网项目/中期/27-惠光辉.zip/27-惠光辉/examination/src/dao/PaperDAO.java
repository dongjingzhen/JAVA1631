package dao;

import java.util.List;

import beans.Count;
import beans.HibernateUtils;
import beans.Question;
import beans.paper;

public class PaperDAO {
	public List<paper> list(){
		List<paper> list =(List<paper>) HibernateUtils.getSession().createCriteria(paper.class).list();
		HibernateUtils.getSession().beginTransaction().commit();
		return list;
	}
	public List<Object[]> paperInsert(Count c,paper pa){
		String  sql ="select top  "+c.getCountJ()+"  qid, newId() from question where difficulty= '��' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all ";
		sql+=" select top  "+c.getCountZ()+"  qid, newId() from question where difficulty= '�е�' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all  ";
		sql+=" select top  "+c.getCountK()+"  qid, newId() from question where difficulty= '����' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all  ";
		sql+=" select top  "+c.getCountsJ()+" qid, newId() from question where difficulty= '��' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all  ";
		sql+=" select top  "+c.getCountsZ()+" qid, newId() from question where difficulty= '�е�' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" union all  ";
		sql+=" select top  "+c.getCountsK()+" qid, newId() from question where difficulty= '����' and type='��ѡ' and subject="+"'"+pa.getSubjectName()+"'"+" order by newid()";
		List<Object[]> qidlist = HibernateUtils.getSession().createSQLQuery(sql).list();
		return qidlist;
	}
	public List<Object[]> selectlist(int pid){
		String sql = "select *from question q,t_questions_paper t,paper p where t.paper_id="+pid+" and q.qid=t.question_id";
		List<Object[]> list = HibernateUtils.getSession().createSQLQuery(sql).list();
		return list;
	}
}
