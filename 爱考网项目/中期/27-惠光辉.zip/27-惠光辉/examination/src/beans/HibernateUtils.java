package beans;

import java.io.Serializable;

import org.hibernate.HibernateException;  
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.cfg.Configuration;  
  
public final class HibernateUtils {  
    private static SessionFactory factory;  
  
    public static Session getSession() {  
        return factory.openSession();  
    }  
  
    private HibernateUtils() { // ����ģʽ  
    }  
  
    static { // ���������ʱִ��һ��  
        // configureĬ�ϼ���hibernate.cfg.xml  
        // �������hibernate.cfg.xml����ָ���������֣����ļ���classpath����  
        Configuration config = new Configuration().configure();  
        factory = config.buildSessionFactory();  
    }  
  
    public static void add(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
            session.save(obj);  
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static void update(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
//            session.flush();
            session.update(obj);  
            
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static void delete(Object obj) {  
        Session session = null;  
        Transaction tx = null;  
        try {  
            session = HibernateUtils.getSession();  
            tx = session.beginTransaction();  
            session.delete(obj);  
            tx.commit();  
        } catch (HibernateException e) {  
            if (tx != null) { // �������������ع�  
                tx.rollback();  
            }  
            throw e; // �׳��쳣  
        } finally {  
            if (session != null) // ���session���ڣ���ر�  
                session.close();  
        }  
    }  
  
    public static Object get(Class clazz, Serializable id) {  
        Session session = null;  
        try {  
            session = HibernateUtils.getSession();  
            Object obj = session.get(clazz, id);  
            return obj;  
        } finally {  
            if (session != null) {  
                session.close();  
            }  
        }  
    }  
  
}  