package beans;

import java.util.HashSet;
import java.util.Set;

public class UserLogin {
	/**
	 * �����û�ʵ����-login
	 */
	private int uid;
	private String loginName;
	private String loginPwd;
	private Set<Role> roles = new HashSet<Role>();
	private Set<Teacher> teachers  = new HashSet<Teacher>();
	
	
	public Set<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(Set<Teacher> teachers) {
		this.teachers = teachers;
	}
	public Set<Role> getRoles() {
		return roles;
	}
	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	
	
}
