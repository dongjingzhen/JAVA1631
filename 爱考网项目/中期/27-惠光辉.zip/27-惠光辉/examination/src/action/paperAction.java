package action;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import beans.Count;
import beans.HibernateUtils;
import beans.Question;
import beans.paper;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.PaperDAO;
public class paperAction implements Action {
	private List<paper> paperlist;
	private List<Object[]> list;
	private paper pa;
	private Count c;
	private Question qu;
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String paperlist(){
		PaperDAO dao = new PaperDAO();
		paperlist = dao.list();
		return "paperlist";
	}
	public String paperInsert(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper paper = new paper();
		String java = qu.getSubject();
		pa.setSubjectName(java);
		paper.setSubjectName(java);
		paper.setTypes(qu.getTypes());
		paper.setTitle(pa.getTitle());
		paper.setTotalScore(pa.getTotalScore());
		paper.setTestHour(pa.getTestHour());
		paper.setQnumber(pa.getQnumber());
		System.out.println(pa.getType()+pa.getQnumber()+pa.getTitle());
		PaperDAO dao = new PaperDAO();
		list = dao.paperInsert(c, pa);
		for (Object[] q : list) {
			Question question = (Question)session.get(Question.class, (Serializable) q[0]);
			question.getPapers().add(paper);
			session.save(paper);
   		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "paperInsert";
	}
	
	/**
	 * get/set ����
	 */
	public List<paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<paper> paperlist) {
		this.paperlist = paperlist;
	}
	public paper getPa() {
		return pa;
	}
	public void setPa(paper pa) {
		this.pa = pa;
	}
	public List<Object[]> getList() {
		return list;
	}
	public void setList(List<Object[]> list) {
		this.list = list;
	}
	public Count getC() {
		return c;
	}
	public void setC(Count c) {
		this.c = c;
	}
	public Question getQu() {
		return qu;
	}
	public void setQu(Question qu) {
		this.qu = qu;
	}
	
}
