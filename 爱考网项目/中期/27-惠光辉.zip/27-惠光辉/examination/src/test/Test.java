package test;

import java.io.Serializable;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;
import dao.PaperDAO;
import dao.QuestionDAO;
import beans.Count;
import beans.HibernateUtils;
import beans.Question;
import beans.paper;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		PaperDAO dao = new PaperDAO();
		List<Object[]> list = dao.selectlist(25);
		System.out.println("qqqqqqqqqq");
		for (Object[] q : list) {
			System.out.println("sss");
			System.out.println(q[0]+" "+q[1]);
		}
		
//		// TODO Auto-generated method stub
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction = session.beginTransaction();
//		paper p = new paper();
//		p.setClassName("html");
//		int id = 0;
//		String sql="select top 5 qid, newId() from question where difficulty= '��'"+  
//				"union "+"select top 5 qid, newId() from question where difficulty= '�е�' order by newid()";
//		List<Object[]> qidlist = HibernateUtils.getSession().createSQLQuery(sql).list();
//		for (Object[] q : qidlist) {
//			Question question = (Question)session.get(Question.class,(Serializable) q[0]);
//			question.getPapers().add(p);
//			session.save(p);
//	   		}
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
//		
		
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction = session.beginTransaction();
//		PaperDAO dao = new PaperDAO();
//		Count c = new Count();
//		paper pa = new paper();
//		paper paper = new paper();
//		pa.setSubjectName("java");
//		
//
//
//		List<Object[]> list = dao.paperInsert(c, pa);
//		for (Object[] q : list) {
//			Question question = (Question)session.get(Question.class, (Serializable) q[0]);
//			question.getPapers().add(paper);
//			session.save(paper);
//   		}
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
//		
		
		
		
		
		
		
		
		
		
		
		
//			save();
//			ceshi();
//			list();
//			PaperDAO dao = new PaperDAO();
//			List<paper> paperlist = dao.list();
//			for (paper a : paperlist) {
//				System.out.println(a.getClassName());
//			}
//			dajuan();
		// TODO Auto-generated method stub
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction = session.beginTransaction();
//		paper p = new paper();
//		p.setClassName("java");
//		Question q = (Question)session.get(Question.class, 90);
//		q.getPapers().add(p);
//		session.save(p);
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
	} 

//	private static void dajuan(paper pa,Count c) {
//		// TODO Auto-generated method stub
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction = session.beginTransaction();
//		paper p = new paper();
//		p.setClassName("java");
//		String  sql ="select top  "+c.getCountJ()+"  qid, newId() from question where difficulty= '��' and type='��ѡ' and subject="+pa.getSubjectName()+" union ";
//				sql+="select top  "+c.getCountZ()+"  qid, newId() from question where difficulty= '�е�' and type='��ѡ' and subject="+pa.getSubjectName()+" union";
//				sql+="select top  "+c.getCountK()+"  qid, newId() from question where difficulty= '����' and type='��ѡ' and subject="+pa.getSubjectName()+" union";
//				sql+="select top  "+c.getCountsJ()+" qid, newId() from question where difficulty= '��' and type='��ѡ' and subject="+pa.getSubjectName()+" union";
//				sql+="select top  "+c.getCountsZ()+" qid, newId() from question where difficulty= '�е�' and type='��ѡ' and subject="+pa.getSubjectName()+" union";
//				sql+="select top  "+c.getCountsK()+" qid, newId() from question where difficulty= '����' and type='��ѡ' and subject="+pa.getSubjectName()+" order by newid()";
//		List<Object[]> qidlist = session.createSQLQuery(sql).list();
//		for (Object[] q : qidlist) {
//		Question question = (Question)session.get(Question.class, (Serializable) q[0]);
//		question.getPapers().add(p);
//   		}
//		session.save(p);
//		transaction.commit();
//		HibernateSessionFactory.closeSession();
//	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private static void list() {
		// TODO Auto-generated method stub
		String hql = "SELECT q FROM Question q  WHERE  q.types LIKE :quname ";
		List<Question> newlist = HibernateUtils.getSession().createQuery(hql).setString("quname","����").list();
		for (Question q : newlist) {
			System.out.println(q.getTypes()+q.getContent());
		}
	}

	private static void ceshi() {
		// TODO Auto-generated method stub
		String hql = "SELECT subject,types,count(types) FROM Question q GROUP BY subject,types";
		List<Object[]> questionList = HibernateUtils.getSession().createQuery(hql).list();
	}

	private static void save() {
		// TODO Auto-generated method stub
		Question q = new Question();
		q.setType("��ѡ");
		q.setContent("���м��������е���");
		q.setOptionA("��");
		q.setOptionB("�̹�");
		q.setOptionC("��");
		q.setOptionD("ɶ�����⣿��");
		q.setDifficulty("��");
		q.setAnswer("D");
		q.setSubject("java");
		q.setTypes("����");
		HibernateUtils.add(q);
		HibernateUtils.getSession().beginTransaction().commit();
	}

}
