package action;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class TestStudents  implements Action{
	

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
		
		
	
	

}
