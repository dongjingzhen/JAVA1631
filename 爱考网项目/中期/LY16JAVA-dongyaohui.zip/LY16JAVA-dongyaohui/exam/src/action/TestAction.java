package action;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Class;
import bean.Login;
import bean.Paper;
import bean.Question;
import bean.Students;
import bean.Teacher;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.questionDao;
import dao.teacherDao;
import dao.testDao;

public class TestAction implements Action {
	private List<Students> sLis	;
	
	public List<Students> getsLis() {
		return sLis;
	}

	public void setsLis(List<Students> sLis) {
		this.sLis = sLis;
	}

	private List<Students> sList;
	public List<Students> getsList() {
		return sList;
	}

	public void setsList(List<Students> sList) {
		this.sList = sList;
	}

	private List<Students> stuList;
	
	public List<Students> getStuList() {
		return stuList;
	}

	public void setStuList(List<Students> stuList) {
		this.stuList = stuList;
	}

//	private int nid;
//	public int getNid() {
//		return nid;
//	}
//
//	public void setNid(int nid) {
//		this.nid = nid;
//	}
	
	private String nid;
	
	

	public String getNid() {
		return nid;
	}

	public void setNid(String nid) {
		this.nid = nid;
	}

	private Class classs;
	
	public Class getClasss() {
		return classs;
	}

	public void setClasss(Class classs) {
		this.classs = classs;
	}

	private Set<Question> questListt;
	
	public Set<Question> getQuestListt() {
		return questListt;
	}

	public void setQuestListt(Set<Question> questListt) {
		this.questListt = questListt;
	}

	private List<Class> nameList;
	
	public List<Class> getNameList() {
		return nameList;
	}

	public void setNameList(List<Class> nameList) {
		this.nameList = nameList;
	}

	private Date testTime;
	
	

	public Date getTestTime() {
		return testTime;
	}

	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}
   
	

	private int jd1;
	private int zd1;
	private int kn1;
	private int jd2;
	private int zd2;
	private int kn2;
	private int onepaper;
	
	

	

	public int getJd1() {
		return jd1;
	}

	public void setJd1(int jd1) {
		this.jd1 = jd1;
	}

	public int getZd1() {
		return zd1;
	}

	public void setZd1(int zd1) {
		this.zd1 = zd1;
	}

	public int getKn1() {
		return kn1;
	}

	public void setKn1(int kn1) {
		this.kn1 = kn1;
	}

	public int getJd2() {
		return jd2;
	}

	public void setJd2(int jd2) {
		this.jd2 = jd2;
	}

	public int getZd2() {
		return zd2;
	}

	public void setZd2(int zd2) {
		this.zd2 = zd2;
	}

	public int getKn2() {
		return kn2;
	}

	public void setKn2(int kn2) {
		this.kn2 = kn2;
	}

	public int getOnepaper() {
		return onepaper;
	}

	public void setOnepaper(int onepaper) {
		this.onepaper = onepaper;
	}

	private Paper paper;
	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	private List<Paper> paperList;

	public List<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}

	private String kind;
	private String contentt;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String answer;
	private String difficulty;
	private String chapter;
	private String subjectIdd;
	private String kindTypee;

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getContentt() {
		return contentt;
	}

	public void setContentt(String contentt) {
		this.contentt = contentt;
	}

	public String getOptionA() {
		return optionA;
	}

	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	public String getOptionB() {
		return optionB;
	}

	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	public String getOptionC() {
		return optionC;
	}

	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	public String getOptionD() {
		return optionD;
	}

	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getChapter() {
		return chapter;
	}

	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	public String getSubjectIdd() {
		return subjectIdd;
	}

	public void setSubjectIdd(String subjectIdd) {
		this.subjectIdd = subjectIdd;
	}

	public String getKindTypee() {
		return kindTypee;
	}

	public void setKindTypee(String kindTypee) {
		this.kindTypee = kindTypee;
	}

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private Question question;

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	private List<Question> questList;

	public List<Question> getQuestList() {
		return questList;
	}

	public void setQuestList(List<Question> questList) {
		this.questList = questList;
	}

	private List<Question> questionList;

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	private List<Teacher> teacherList;

	public List<Teacher> getTeacherList() {
		return teacherList;
	}

	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}

	private Teacher teacher;

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	private int role;

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	private String aname;
	private String apwd;
	private String subjectId;
	private String kindType;

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	public String getKindType() {
		return kindType;
	}

	public void setKindType(String kindType) {
		this.kindType = kindType;
	}

	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getApwd() {
		return apwd;
	}

	public void setApwd(String apwd) {
		this.apwd = apwd;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public String login() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		switch (role) {
		case 1:
			List<Students> ssList = session.createCriteria(Students.class).list();
			
			for (Students s : ssList) {

				if (s.getStuNo().equals(aname)
						&& s.getStuPwd().equals(apwd)) {
                      sList=ssList;
                      
					return "studentsIndex";

				} else {
					return "Not";
				}

			}
		case 2:
			List<Teacher> list = session.createCriteria(Teacher.class).list();

			for (Teacher teacher : list) {

				if (teacher.getTaccount().equals(aname)
						&& teacher.getTpwd().equals(apwd)) {

					return "teacherIndex";

				} else {
					return "Not";
				}

			}

		case 3:
			List<Login> LoginList = session.createCriteria(Login.class).list();
			for (Login object : LoginList) {
				if (object.getAname().equals(aname)
						&& object.getApwd().equals(apwd)) {

					return "index";

				} else {

				}
			}
		}
	

		return "Not";

	}

	public String selectTeacher() {
		teacherDao dao = new teacherDao();
		teacherList = dao.list();

		return "selectTeacher";

	}

	public String selectQuestion() {
		questionDao dao = new questionDao();
		questionList = dao.list();

		return "selectQuestion";

	}

	// ��ѯ��ϸ�Ծ�
	public String selectquestion() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String hql = "Select q from Question q where q.subjectId='" + subjectId
				+ "' and q.kindType='" + kindType + "'";
		Query query = session.createQuery(hql);

		System.out.println(hql);
		questList = query.list();
		HibernateSessionFactory.closeSession();

		return "selectquestion";

	}

	// ��������
	public String addquestion() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		session.save(question);
		transaction.commit();
		HibernateSessionFactory.closeSession();

		return "addquestion";

	}

	// ɾ����Ŀ
	public String deletequestion() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Question qq = (Question) session.get(Question.class, id);

		session.delete(qq);
		transaction.commit();
		HibernateSessionFactory.closeSession();

		return "deletequestion";

	}

	// �޸�
	public String updatequestion() {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Question qq = (Question) session.get(Question.class, id);
		System.out.println(kind);
		qq.setKind(kind);
		qq.setContentt(contentt);
		qq.setOptionA(optionA);
		qq.setOptionB(optionB);
		qq.setOptionC(optionC);
		qq.setOptionD(optionD);
		qq.setAnswer(answer);
		qq.setDifficulty(difficulty);
		qq.setKindType(kindTypee);
		qq.setSubjectId(subjectIdd);

		session.update(qq);
		transaction.commit();
		HibernateSessionFactory.closeSession();

		return "updatequestion";

	}

	// �Ծ��б�
	public String selecttest() {
		testDao dao = new testDao();
		paperList = dao.list();

		return "selecttest";

	}
	public String addtest() {
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();		
		Paper p =new Paper();
		p.setSubjectName(paper.getSubjectName());
		p.setKind(paper.getKind());
		p.setTitle(paper.getTitle());
		p.setClassName(paper.getClassName());
		
		p.setTestHour(paper.getTestHour());
		p.setTotalScore(paper.getTotalScore());
		p.setQnumber(paper.getQnumber());
		p.setState(paper.getState());
		 
			
		String sql="select top "+jd1+" qid, newId() from question where difficulty= '��'  " +
		"union all " +
			"select top "+zd1+" qid, newId() from question where difficulty= 'һ��'" +
			"union all " +
			"select top "+kn1+" qid, newId() from question where difficulty= '����'" +
			"  order by newid()";
			 List qid =session.createSQLQuery(sql).list();
             for (Object object : qid) {
				System.out.println("111");
				Question question=(Question)session.get(Question.class, Integer.parseInt(object.toString())); 
				p.getQuestion().add(question);
			}			
				session.save(p);
				transaction.commit();
				HibernateSessionFactory.closeSession();
				return "add";
		
		  
		 
		

	}
	
	public String selectClassName(){
		testDao dao=new testDao();
		nameList=dao.namelist();
		return "start";
		
		
		
		
	}
	
	public String startt(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Paper pp=(Paper)session.get(Paper.class,id);
		
		
		
		
		String hql="select s from Students s where classId in("+Integer.parseInt(nid)+")";  
		
		
		Query query = session.createQuery(hql);
		 
		List<Students> stu=query.list(); 
		
		stuList=stu;
		for (Students students : stu) {
			System.out.println(hql);
			pp.getStudents().add(students);
			Class cc=(Class)session.get(Class.class,Integer.parseInt(nid.trim()));
			pp.setClassName(cc.getClassName());
			
		}
		
		
		
		pp.setTestTime(paper.getTestTime());
		session.update(pp);	
		System.out.println(pp.getClassName());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "startt";
		
		
		
		
	}
	
	

	public String paperquest(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Paper pp=(Paper)session.get(Paper.class, id);
		questListt=pp.getQuestion();
		System.out.println(questListt);
		transaction.commit();
		
		return "paperquest";
		
		
		
		
	}
	
	
	public String stu1(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Students sss=(Students)session.get(Students.class, id);
		System.out.println(id);
		 String hql="select ss from Students where id="+id ;
		 
		 Query query = session.createQuery(hql);
		 
			 sLis=query.list(); 
		return "stu1";
	}

	
}
