package bean;

import java.util.Date;

public class Score6 {
	private int id;  // �Ծ�id
	private Date beginTime;// ��ʼʱ��
	private Date endTime;// ����ʱ��
	private String  score;// �ɼ�
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	
	

}
