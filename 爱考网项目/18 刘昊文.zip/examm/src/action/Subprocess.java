package action;

import java.util.List;

import vo.Paper;
import vo.Question;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dai.Addteacher;
import dai.Auquestion;
import dai.Begintest;
import dai.Levelnum;
import dai.subclass;
import dai.subpaper;
import dai.substudent;
import dao.Dao;

public class Subprocess implements Action {
Dao dao =new Dao();

private Addteacher addteacher;
private String type;
private int id;
private Auquestion auquestion;
private Teacher teacher;
private Question question;
private Paper paper;
private Levelnum levelnum;
private List<Object[]> obj;
private subpaper subpaper;
private subclass subclass;
private Begintest begintest;
private substudent substudent;





	public substudent getSubstudent() {
	return substudent;
}

public void setSubstudent(substudent substudent) {
	this.substudent = substudent;
}

	public Begintest getBegintest() {
	return begintest;
}

public void setBegintest(Begintest begintest) {
	this.begintest = begintest;
}

	public subclass getSubclass() {
	return subclass;
}

public void setSubclass(subclass subclass) {
	this.subclass = subclass;
}

	public subpaper getSubpaper() {
	return subpaper;
}

public void setSubpaper(subpaper subpaper) {
	this.subpaper = subpaper;
}

	public Paper getPaper() {
	return paper;
}

public void setPaper(Paper paper) {
	this.paper = paper;
}

	public Levelnum getLevelnum() {
	return levelnum;
}

public void setLevelnum(Levelnum levelnum) {
	this.levelnum = levelnum;
}

public List<Object[]> getObj() {
	return obj;
}

public void setObj(List<Object[]> obj) {
	this.obj = obj;
}

	public Teacher getTeacher() {
	return teacher;
}

public void setTeacher(Teacher teacher) {
	this.teacher = teacher;
}

public Question getQuestion() {
	return question;
}

public void setQuestion(Question question) {
	this.question = question;
}

	public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}


	public Auquestion getAuquestion() {
	return auquestion;
}

public void setAuquestion(Auquestion auquestion) {
	this.auquestion = auquestion;
}



	public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

	public Addteacher getAddteacher() {
	return addteacher;
}

public void setAddteacher(Addteacher addteacher) {
	this.addteacher = addteacher;
}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String add() {
		// TODO Auto-generated method stub\
		System.out.println(type);
		System.out.println(subclass.getClassName());
		dao.add(type,addteacher,auquestion,levelnum,subpaper,subclass,id,substudent);
		String tt="yes";
		if(type.equals("teacher")){
			tt="yesteacher";
		}else if(type.equals("question")){
			tt="yesquestion";
		}else if(type.equals("paper")){
			tt="yespaper";
		}else if(type.equals("class")){
			tt="yesclass";
		}
		return tt;
		
	}


	public String update() {
		// TODO Auto-generated method stub
		dao.update(type,addteacher,auquestion,subclass,id,begintest,substudent);
		String tt="yes";
		if(type.equals("teacher")){
			tt="yesteacher";
		}else if(type.equals("question")){
			tt="yesquestion";
		}else if(type.equals("class")){
			tt="yesclass";
		}else if(type.equals("paper")){
			tt="yespaper";
		}
		return tt;
		
	}
	
	public String delete() {
		// TODO Auto-generated method stub
		System.out.println(type+""+id+auquestion.getSubjectid());
		
		dao.delete(type,id);
		String tt="yes";
		if(type.equals("teacher")){
			tt="yesteacher";
		}else if(type.equals("question")){
			tt="yesquestion";
		}
		return tt;
		
	}
}
