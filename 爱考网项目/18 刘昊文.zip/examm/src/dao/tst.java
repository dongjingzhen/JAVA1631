package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Question;
import vo.Score;
import vo.Scoredetails;
import vo.Subject;

public class tst {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
	Scoredetails scoredetails=new Scoredetails();
	scoredetails.setAnswer("aa");
		   Score score=new Score();
           score=(Score)session.get(Score.class,2);
           score.getScoredetails().add(scoredetails);
	    	   session.update(score);
		transaction.commit();
		HibernateSessionFactory.closeSession();

	}

}
