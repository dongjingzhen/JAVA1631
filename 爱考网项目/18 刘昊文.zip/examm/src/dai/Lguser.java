package dai;

public class Lguser {
	private String lgname;
	private String lgpwd;
	private String lgrole;

	public String getLgrole() {
		return lgrole;
	}
	public void setLgrole(String lgrole) {
		this.lgrole = lgrole;
	}
	public String getLgname() {
		return lgname;
	}
	public void setLgname(String lgname) {
		this.lgname = lgname;
	}
	public String getLgpwd() {
		return lgpwd;
	}
	public void setLgpwd(String lgpwd) {
		this.lgpwd = lgpwd;
	}

}
