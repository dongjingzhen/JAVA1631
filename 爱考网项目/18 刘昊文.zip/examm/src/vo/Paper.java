package vo;
// default package

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;


/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Paper  implements java.io.Serializable {


    // Fields    

     private Integer pid;
     private String subjectName;
     private String kind;
     private String title;
     private String className;
     private Timestamp testTime;
     private Integer testHour;
     private int totalScore;
     private Integer qnumber;
     private int fen;
     private String state;
     private Set<Question>  question =new HashSet<Question>();
     private Set<Student> student=new HashSet<Student>();
     
     
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Set<Student> getStudent() {
		return student;
	}
	public void setStudent(Set<Student> student) {
		this.student = student;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Timestamp getTestTime() {
		return testTime;
	}
	public void setTestTime(Timestamp testTime) {
		this.testTime = testTime;
	}
	public Integer getTestHour() {
		return testHour;
	}
	public void setTestHour(Integer testHour) {
		this.testHour = testHour;
	}

	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public Integer getQnumber() {
		return qnumber;
	}
	public void setQnumber(Integer qnumber) {
		this.qnumber = qnumber;
	}

	public int getFen() {
		return fen;
	}
	public void setFen(int fen) {
		this.fen = fen;
	}
	public Set<Question> getQuestion() {
		return question;
	}
	public void setQuestion(Set<Question> question) {
		this.question = question;
	}



    // Constructors

  
}