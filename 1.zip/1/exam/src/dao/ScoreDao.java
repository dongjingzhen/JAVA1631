package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Paper;
import vo.Question;
import vo.Score;
import vo.Scoredetails;
import vo.Student;
import vo.Subject;

public class ScoreDao {
	public Score addscore(Student student,Paper paper){
		Score score = new Score();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		student = (Student)session.get(Student.class, student.getId());
		Classes	classes =(Classes) session.get(Classes.class, Integer.parseInt(student.getClassId()));
		System.out.println(classes.getClassName());
		
		paper =(Paper)session.get(Paper.class, paper.getPid());
		List<Subject> subject = session.createCriteria(Subject.class).add(Restrictions.eq("subjectId", paper.getSubjectName())).list();
		score.setClasses(classes);
		score.setStudent(student);
		score.setPaper(paper);
		score.setSubject(subject.get(0));
		Date beginTime = new Date();
		Date endTime = new Date(beginTime.getTime()+paper.getTestHour()*60*1000);
		score.setBeginTime(beginTime);
		score.setEndTime(endTime);
		float s = 0;
		score.setScore(s);
		session.save(score);
		score = (Score)session.createCriteria(Score.class)
				.add(Restrictions.eq("student",student))
				.add(Restrictions.eq("paper", paper)).list().get(0);
		System.out.println(score.getPaper().getTotalScore());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return score;
	}
	
	public List<Scoredetails> allquestions(Score score){
		List<Scoredetails> scoredetailss = new ArrayList<Scoredetails>();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		score = (Score)session.get(Score.class,score.getId());
		Set<Question> questions = new HashSet<Question>();
		questions = score.getPaper().getQuestionSet();
		for (Question question : questions) {
			Scoredetails scoredetails = new Scoredetails();
			scoredetails.setScore(score);
			scoredetails.setQuestion(question);
			scoredetails.setAnswer("0");
			scoredetails.setResult("0");
			session.save(scoredetails);
		}
		
		scoredetailss =session.createCriteria(Scoredetails.class).add(Restrictions.eq("score", score)).list();
		for (Scoredetails scoredetails : scoredetailss) {
			System.out.println(scoredetails.getQuestion().getContent());
			break;
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		
		return scoredetailss;
		
		
	}
	public void tijiao(List<Scoredetails> scoredetailss,Score score){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		for (Scoredetails scoredetails : scoredetailss) {
			
			Scoredetails scoredetail = (Scoredetails) session.get(Scoredetails.class, scoredetails.getId());
			if (scoredetails.getAnswer() ==null || scoredetails.getAnswer().equals("")) {
				
			}else {
				scoredetail.setAnswer(scoredetails.getAnswer());
				if(scoredetail.getQuestion().getAnswer().equals(scoredetails.getAnswer())){
					System.out.println(scoredetail.getAnswer());
					System.out.println(scoredetails.getAnswer());
					scoredetail.setResult("1");
				}
			}
			session.saveOrUpdate(scoredetail);
			
		}
		score = (Score) session.get(Score.class, score.getId());
		float i = session.createCriteria(Scoredetails.class)
		.add(Restrictions.eq("score", score))
		.add(Restrictions.eq("result", "1")).list().size();
		score.setScore(i*(score.getPaper().getTotalScore()/score.getPaper().getQnumber()));
		session.saveOrUpdate(score);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public Score getscore(Score score){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		score = (Score)session.get(Score.class, score.getId());
		Set<Scoredetails> ss = score.getScoredetalilSet();
		for (Scoredetails scoredetails : ss) {
			System.out.println(scoredetails.getQuestion().getAnswer()+scoredetails.getQuestion().getContent());
		}
		System.out.println(score.getStudent().getStuName());
		System.out.println(score.getPaper().getTotalScore());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return score;
	}
}
