package vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Score {
	
	private int id;
	
	private Classes classes;
	
	private Student student;
	
	private Subject subject;
	
	private Paper paper;
	
	private Date beginTime;
	
	private Date endTime;
	
	private float score;
	
	private Set<Scoredetails> scoredetalilSet = new HashSet<Scoredetails>();
	
	

	public Set<Scoredetails> getScoredetalilSet() {
		return scoredetalilSet;
	}

	public void setScoredetalilSet(Set<Scoredetails> scoredetalilSet) {
		this.scoredetalilSet = scoredetalilSet;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}
	
	
	

}
