package action;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Question;
import vo.Subject;
import vo.Teacher;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.HibernateUtils;

public class QuestionAction implements Action {
	private String[] ss = {"A","B","C","D"};
	private String[] nan = {"��","һ��","����"};
	private Question question;
	private List<Question> questionList = new ArrayList<Question>();
	private List<String> attrList = new ArrayList<String>();
	private String subjectId;
	private List<Question> penTestList = new ArrayList<Question>();
	private List<Question> computerTestList = new ArrayList<Question>();
	List<Subject> subject = new ArrayList<Subject>();
	
	
	

	public String[] getSs() {
		return ss;
	}

	public void setSs(String[] ss) {
		this.ss = ss;
	}

	public String[] getNan() {
		return nan;
	}

	public void setNan(String[] nan) {
		this.nan = nan;
	}

	public List<Subject> getSubject() {
		return subject;
	}

	public void setSubject(List<Subject> subject) {
		this.subject = subject;
	}

	public List<Question> getPenTestList() {
		return penTestList;
	}

	public void setPenTestList(List<Question> penTestList) {
		this.penTestList = penTestList;
	}

	public List<Question> getComputerTestList() {
		return computerTestList;
	}

	public void setComputerTestList(List<Question> computerTestList) {
		this.computerTestList = computerTestList;
	}

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	public List<String> getAttrList() {
		return attrList;
	}

	public void setAttrList(List<String> attrList) {
		this.attrList = attrList;
	}



	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public List<Question> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String question(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		subject = session.createCriteria(Subject.class).list();
		
		String sql = "select kind,count(kind),subjectId from question  group by kind,subjectId";
		List<Object[]> strings = session.createSQLQuery(sql).list();
		for (Object[] strings2 : strings) {
			for (Subject s : subject) {
				String a = (String) strings2[2];
				
				if (a.equals(s.getSubjectId())) {
					s.getQuestionobject().add(strings2);
				}
			}
		}
		for (Subject s : subject) {
			Object[] o = {"����",0,s.getSubjectId()};
			Object[] oo = {"����",0,s.getSubjectId()};
			if (s.getQuestionobject().size()==1) {
				Object[] ooo = s.getQuestionobject().get(0);
				String a = (String) ooo[2];	
				if (a.equals("����")) {
					
					s.getQuestionobject().add(oo);
				}else {
					s.getQuestionobject().add(o);
				}
			}else if (s.getQuestionobject().size()==0) {
				
				s.getQuestionobject().add(o);
				s.getQuestionobject().add(oo);
			}
		}
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		
		return "next";
	}
	//��ѯ�������б���ʾ
	public String penTest(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		penTestList = session.createCriteria(Question.class)
		.add(Restrictions.eq("kind", question.getKind()))
		.add(Restrictions.eq("subjectId", question.getSubjectId()))
		.list();
		for (Question list1 : penTestList) {
			System.out.println(list1.toString());
		}
		System.out.println(question.getKind());
		System.out.println( question.getSubjectId());
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "penTest";
	}
	
	/**
	 * ����
	 */
	public String showAdd(){
		
		return "showAdd";
	}
	public String addQuestion(){
		
		HibernateUtils.add(question);
		return "addQuestion";
		
	}
	/**
	 * �޸Ĵ�ֵ
	 */
	
	public String showUpdate(){
		question = (Question) HibernateUtils.get(Question.class, question.getQid());
		
		return "showUpdate";
		
	}
	/**
	 * ɾ��
	 */
	public String delete(){
		HibernateUtils.delete(question);
		return "delete";
		
	}
	/**
	 * �޸ĳɹ�
	 */
	public String updateOK(){
		HibernateUtils.update(question);
		return "updateOK";
		
	}

}
