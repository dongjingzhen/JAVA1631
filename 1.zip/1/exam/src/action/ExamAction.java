package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vo.Admin;
import vo.Student;
import vo.Teacher;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;

public class ExamAction implements Action{
	private Admin admin = new Admin();
	private String message;
	
	private Users user = new Users();
	private Teacher teacher = new Teacher();
	private Student student = new Student();
	
	

	private List<Admin> adminlist = new ArrayList<Admin>();
	private List<Teacher> teacherlist = new ArrayList<Teacher>();
	private List<Student> studentlist = new ArrayList<Student>();
	
	
	
	

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public List<Teacher> getTeacherlist() {
		return teacherlist;
	}

	public void setTeacherlist(List<Teacher> teacherlist) {
		this.teacherlist = teacherlist;
	}

	public List<Student> getStudentlist() {
		return studentlist;
	}

	public void setStudentlist(List<Student> studentlist) {
		this.studentlist = studentlist;
	}

	

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public List<Admin> getAdminlist() {
		return adminlist;
	}

	public void setAdminlist(List<Admin> adminlist) {
		this.adminlist = adminlist;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * ע�� �رյ�ǰ�Ի�
	 */
	public String zhuxiao(){
		ServletActionContext.getRequest().getSession().invalidate();
		return "zhuxiao";
	}
	/**
	 * ��¼
	 * @return
	 */
	public String login(){
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		if(user.getRole()==3){
			String hql = "from Admin where aname = '"+user.getName()+"' and apwd = '"+user.getPwd()+"'";
			adminlist= session.createQuery(hql).list();
			transaction.commit();
			//HibernateSessionFactory.closeSession();
			if(adminlist.size()==0){
				 message= "error";
			}else{
				ServletActionContext.getRequest().getSession().setAttribute("user", user);
				message= "suc";
			}
			
		}else if(user.getRole()==2){
				String hql2 = "from Teacher where tname = '"+user.getName()+"' and tpwd = '"+user.getPwd()+"'";
				teacherlist= session.createQuery(hql2).list();
				transaction.commit();
				//HibernateSessionFactory.closeSession();
				if(teacherlist.size()==0){
					message= "error";
				}else{
					ServletActionContext.getRequest().getSession().setAttribute("user", user);

					message= "teacher";
				}
			
		}else if(user.getRole()==1){
					String hql1 = "from Student where stuName = '"+user.getName()+"' and stuPwd = '"+user.getPwd()+"'";
					studentlist= session.createQuery(hql1).list();
					student = studentlist.get(0);
					transaction.commit();
					//HibernateSessionFactory.closeSession();
					if(studentlist.size()==0){
						message="error";
					}else{
						ServletActionContext.getRequest().getSession().setAttribute("user", user);
						ServletActionContext.getRequest().getSession().setAttribute("id", student.getId());
						ServletActionContext.getRequest().getSession().setAttribute("stuName", student.getStuName());
						message= "student";
					}
			 
		}else{
			message="error";
		}
		return message;
	}
	
	/**
	 * ��ʦ�б�
	 */
	public String teacherlist(){
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		teacherlist =(List<Teacher>) session.createCriteria(Teacher.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "teacherlist";
	}
		

}
