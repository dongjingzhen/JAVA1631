package action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import vo.Classes;
import vo.Paper;
import vo.Question;
import vo.Student;
import vo.Subject;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.HibernateUtils;

public class PaperAction implements Action {
	private Question question = new Question();
	private Paper paper = new Paper();
	private List<Paper> paperList = new ArrayList<Paper>();
	private List<Subject> subjectList = new ArrayList<Subject>();
	private int jianDan;
	private int yiBan;
	private int kunNan;
	
	private Subject subject;
	private int id;
	private Classes classes;
	private List<Classes> classList = new ArrayList<Classes>();
	
	private List<Student> studentList = new ArrayList<Student>();
	private Student student;
	private List<Question> questionList = new ArrayList<Question>();
	private int cid;
	private Question tquestion;
	
	
	public Question getTquestion() {
		return tquestion;
	}
	public void setTquestion(Question tquestion) {
		this.tquestion = tquestion;
	}
	public List<Question> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Question> questionList) {
		this.questionList = questionList;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public List<Student> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}
	public int getId() {
		return id;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public List<Classes> getClassList() {
		return classList;
	}
	public void setClassList(List<Classes> classList) {
		this.classList = classList;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public int getJianDan() {
		return jianDan;
	}
	public void setJianDan(int jianDan) {
		this.jianDan = jianDan;
	}
	public int getYiBan() {
		return yiBan;
	}
	public void setYiBan(int yiBan) {
		this.yiBan = yiBan;
	}
	public int getKunNan() {
		return kunNan;
	}
	public void setKunNan(int kunNan) {
		this.kunNan = kunNan;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public List<Subject> getSubjectList() {
		return subjectList;
	}
	public void setSubjectList(List<Subject> subjectList) {
		this.subjectList = subjectList;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * ��ʾ�����Ծ�
	 * @return
	 */
	public String paper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		paperList = session.createCriteria(Paper.class).list();
		for (Paper object : paperList) {
			System.out.println(object.toString());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		
		return "paper";
		
	}
	/**
	 * �������򣬽׶Σ���Ŀ��������
	 */
	public void subjectList(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		//list = session.createCriteria(Books.class).list();
		subjectList = session.createCriteria(Subject.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
	}
	/**
	 * ����������
	 */
	public String random(){
		subjectList();
		return "random";
		
	}
	/**
	 * �������ύ
	 */
	public String randomOK(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		//subject = (Subject)HibernateUtils.get(Subject.class, subject.getId());
		
		System.out.println();
		Paper p = new Paper();
		p.setTitle(paper.getTitle());
		p.setKind("����");
		p.setTestHour(paper.getTestHour());
		p.setState("0");
		p.setTotalScore(paper.getTotalScore());
		
		p.setSubjectName(subject.getDirection()
				+" "+subject.getStage()
				+" "+subject.getSubjectId());
		
		String sql="select top "+jianDan+" qid, newId() from question where difficulty= '��'  " +
					"union all " +
						"select top "+yiBan+" qid, newId() from question where difficulty= 'һ��'" +
						"union all " +
						"select top "+kunNan+" qid, newId() from question where difficulty= '����'" +
						"  order by newid()";
		paperList = (List<Paper>) session.createSQLQuery(sql).list();
		for (Paper list : paperList) {
			System.out.println(list);
			question = (Question) session.get(Question.class, (Serializable) list);
			p.getQuestionSet().add(question);
		}
		session.save(p);
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "randomOK";
		
	}
	/**
	 * ���뿪ʼ���Խ���
	 */
	public String showBeginTest(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		classList = session.createCriteria(Classes.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "showBeginTest";
	}
	/**
	 * ��ʼ���Ժ���༶���༶ ����δ����״̬�ĳ����ڿ��Ի��߸��ݿ���ʱ��δ������δ����
	 */
	public String addClass(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Paper p = (Paper) session.get(Paper.class, paper.getPid());
		String hql = "select * from Student where classId="+cid;
		studentList = session.createQuery(hql).list();
		for (Student studen : studentList) {
			System.out.println(studen);
			p.getStudentSet().add(studen);
			Classes cla = (Classes) session.get(Student.class, cid);
			p.setClassName(cla.getClassName());
		}
		p.setTestTime(paper.getTestTime());
		session.update(p);
		System.out.println(p.getClassName());
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "addClass";
		
	}
	
	/**
	 * �鿴�Ծ�
	 */
	public String selectPaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper)session.get(Paper.class,paper.getPid());
		Set<Question> q = paper.getQuestionSet();
		for (Question question : q) {
			System.out.println(question.getType());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "selectPaper";
	}
	/**
	 * ����滻����ʾ��������
	 */
	public String anotherQuestion(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper) session.get(Paper.class, paper.getPid());
		Criteria criteria=session.createCriteria(Question.class);
		for (Question question : paper.getQuestionSet()) {
			criteria.add(Restrictions.ne("qid", question.getQid()));
		}
			criteria.add(Restrictions.eq("kind", paper.getKind()));
			criteria.add(Restrictions.eq("subjectId", paper.getSubjectName()));
			questionList = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "anotherQuestion";
	}
	/**
	 * �ύ�滻
	 * @return
	 */
	public String tiHuanOK(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper) session.get(Paper.class, paper.getPid());
		question = (Question) session.get(Question.class, question.getQid());
		tquestion = (Question) session.get(Question.class, tquestion.getQid());
		paper.getQuestionSet().remove(question);
		session.flush();
		paper.getQuestionSet().add(tquestion);
		session.saveOrUpdate(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "tiHuanOK";
	}

}
