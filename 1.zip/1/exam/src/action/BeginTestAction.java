package action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import vo.Paper;
import vo.Question;
import vo.Score;
import vo.Scoredetails;
import vo.Student;
import vo.Subject;
import vo.Users;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import dao.ScoreDao;

public class BeginTestAction implements Action {
	private Student student;
	private Set<Paper> paperSet = new HashSet<Paper>();
	private int id;
	private Paper paper;
	
	private ScoreDao dao = new ScoreDao();
	private List<Scoredetails> scoredetailss = new ArrayList<Scoredetails>();
	private Subject subject;
	private Score score;
	List<Score> scoreList = new ArrayList<Score>();
	
	
	public List<Score> getScoreList() {
		return scoreList;
	}

	public void setScoreList(List<Score> scoreList) {
		this.scoreList = scoreList;
	}

	public ScoreDao getDao() {
		return dao;
	}

	public void setDao(ScoreDao dao) {
		this.dao = dao;
	}

	public List<Scoredetails> getScoredetailss() {
		return scoredetailss;
	}

	public void setScoredetailss(List<Scoredetails> scoredetailss) {
		this.scoredetailss = scoredetailss;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public Score getScore() {
		return score;
	}

	public void setScore(Score score) {
		this.score = score;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public Set<Paper> getPaperSet() {
		return paperSet;
	}

	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * ��ʾ�Ծ�
	 * @return
	 */
	public String paper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		id = (Integer)ServletActionContext.getRequest().getSession().getAttribute("id");
		student =  (Student) session.get(Student.class, id);
		paperSet =  student.getPaperSet();
		for(Paper list:paperSet){
			System.out.println(list.getPid());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession(); 
		return "paper";
		
	}
//	/**
//	 * ��ʼ����,��ʾ�Ծ�����
//	 */
//	public String showQuestion(){
//		Session session = HibernateSessionFactory.getSession();
//		Transaction transaction = session.beginTransaction();
//		paper = (Paper)session.get(Paper.class,paper.getPid());
//		Set<Question> q = paper.getQuestionSet();
//		for (Question question : q) {
//			System.out.println(question.getType());
//		}
//		transaction.commit();
//		HibernateSessionFactory.closeSession(); 
//		return "showQuestion";
//	}
	
	
	/**
	 * ��ʾ�Ծ�
	 */
	public String showQuestion(){
		score = dao.addscore(student, paper);
		scoredetailss = dao.allquestions(score);
		return "showQuestion";
	}
	/**
	 * �ύ�Ծ�  
	 */
	public String tijiao(){
		dao.tijiao(scoredetailss,score);
		return "tijiao";
	}
	/**
	 * ���Գɼ��鿴����
	 * @return
	 */
	public String details(){
		score = dao.getscore(score);
		return "details";
	}
	/**
	 * ���Գɼ���ʾ�б�
	 * @return
	 */
	public String ScorePaper(){
		
		id = (Integer)ServletActionContext.getRequest().getSession().getAttribute("id");
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		student =(Student) session.get(Student.class, id);
		scoreList= session.createCriteria(Score.class).add(Restrictions.eq("student", student)).list();
		for (Score score2 : scoreList) {
			System.out.println(score2.getPaper().getTitle());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "next";
	}

}
