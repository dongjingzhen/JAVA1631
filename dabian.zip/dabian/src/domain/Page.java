package domain;



import java.util.List;


public class Page {
		
	private int pagesize = 5;
	private int currentPage;
	private int pagecount;
	private int datacount;
	private List<Teacher> list;
	public int getPagesize() {
		return pagesize;
	}
	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getPagecount() {
		return pagecount;
	}
	public void setPagecount(int datacount) {
		if (datacount % pagesize == 0) {
			this.pagecount=datacount / pagesize;
		}else {
			this.pagecount=datacount / pagesize + 1;
		}
	}
	public int getDatacount() {
		return datacount;
	}
	public void setDatacount(int datacount) {
		this.datacount = datacount;
	}
	public List<Teacher> getList() {
		return list;
	}
	public void setList(List<Teacher> list) {
		this.list = list;
	}
	
	
	
	
}
